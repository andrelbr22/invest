param(
    [switch]$ValidateOnly
)

$ErrorActionPreference = "Stop"
$sourceRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$repositoryUrl = "https://github.com/andrelbr22/invest.git"
$repositoryName = "andrelbr22/invest"
$backupBranch = "backup-versao-anterior"

function Stop-Publication([string]$message) {
    Write-Host ""
    Write-Host "PUBLICACAO INTERROMPIDA: $message" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot "app.py"))) {
    Stop-Publication "app.py nao foi encontrado na pasta extraida."
}
if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot "requirements.txt"))) {
    Stop-Publication "requirements.txt nao foi encontrado na pasta extraida."
}
if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot "investment_engine"))) {
    Stop-Publication "a pasta investment_engine nao foi encontrada."
}

$packageRoot = Join-Path $sourceRoot "investment_engine"
$nestedProjectIndicators = @(
    (Join-Path $packageRoot "app.py"),
    (Join-Path $packageRoot "requirements.txt"),
    (Join-Path $packageRoot "pyproject.toml"),
    (Join-Path $packageRoot ".github")
) | Where-Object { Test-Path -LiteralPath $_ }
if ($nestedProjectIndicators) {
    Stop-Publication "foi encontrada uma copia completa do projeto dentro da pasta investment_engine. Use o pacote completo em uma pasta nova e limpa."
}

$forbiddenDirectories = Get-ChildItem -LiteralPath $sourceRoot -Directory -Recurse -Force |
    Where-Object { $_.Name -in @(".git", ".venv", "__pycache__") }
if ($forbiddenDirectories) {
    Stop-Publication "a pasta contem arquivos internos que nao devem ser publicados. Extraia novamente o ZIP oficial."
}

$sensitiveFiles = Get-ChildItem -LiteralPath $sourceRoot -File -Recurse -Force |
    Where-Object {
        $lowerName = $_.Name.ToLowerInvariant()
        # Arquivos de exemplo fazem parte do pacote e contêm somente marcadores.
        # Qualquer variante real de .env (inclusive worker.env e .env.local) deve
        # interromper a publicação, mesmo que uma regra do .gitignore a ocultasse.
        $isExample = $lowerName.EndsWith(".example")
        $looksLikeEnvironmentConfig = (-not $isExample) -and (
            ($lowerName -eq ".env") -or
            $lowerName.StartsWith(".env.") -or
            $lowerName.EndsWith(".env") -or
            ($lowerName -match "\.env\.")
        )
        $looksLikeSecretConfig = (
            ($lowerName -like "*secret*") -and
            ($lowerName -match "\.(toml|json|ya?ml|ini|conf|config)(\.(save|bak|backup|old))?$")
        ) -and (-not $isExample)
        ($_.Name -in @(".env", ".env.production", "secrets.toml")) -or
        $looksLikeEnvironmentConfig -or
        $looksLikeSecretConfig -or
        ($_.Extension -in @(".key", ".pem", ".pfx", ".p12", ".db", ".sqlite", ".sqlite3"))
    }
if ($sensitiveFiles) {
    Stop-Publication "foi encontrado um arquivo de senha ou chave. Nenhum arquivo foi enviado."
}

$gitCommand = Get-Command git -ErrorAction SilentlyContinue
if ($gitCommand) {
    $gitPath = $gitCommand.Source
} else {
    $bundledGit = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe"
    if (-not (Test-Path -LiteralPath $bundledGit)) {
        Stop-Publication "Git nao foi encontrado neste computador."
    }
    $gitPath = $bundledGit
}

if ($ValidateOnly) {
    Write-Host "Pacote validado. Nenhum arquivo foi enviado." -ForegroundColor Green
    exit 0
}

Write-Host ""
Write-Host "SEGURANCA DA PRIMEIRA MIGRACAO" -ForegroundColor Yellow
Write-Host "Confirme que o fluxo antigo de atualização direta da produção permanece parado."
$stagingConfirmation = Read-Host "Se o timer investment-github-update.timer ja foi parado na Oracle, digite SIM"
if ($stagingConfirmation.Trim().ToUpperInvariant() -ne "SIM") {
    Stop-Publication "pare o timer antigo na Oracle e execute a publicacao novamente."
}

& $gitPath credential-manager configure | Out-Null

$publicationRoot = Join-Path ([IO.Path]::GetTempPath()) ("investment-engine-publicacao-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $publicationRoot | Out-Null

Write-Host "Preparando uma copia temporaria segura do repositorio..."
& $gitPath clone $repositoryUrl $publicationRoot
if ($LASTEXITCODE -ne 0) {
    Stop-Publication "nao foi possivel acessar $repositoryName. Conclua o login do GitHub e tente novamente."
}

Push-Location $publicationRoot
try {
    & $gitPath switch main
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "a branch main nao foi encontrada."
    }

    & $gitPath ls-remote --exit-code --heads origin $backupBranch | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "o backup $backupBranch nao foi localizado no GitHub."
    }

    & $gitPath rm -r --quiet .
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "nao foi possivel preparar a substituicao dos arquivos."
    }

    Get-ChildItem -LiteralPath $sourceRoot -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $publicationRoot $_.Name) -Recurse -Force
    }

    & $gitPath add --all
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "nao foi possivel preparar os novos arquivos."
    }

    # Preserva a correcao operacional introduzida na V1.20.3 R8.
    # O Windows não conserva o bit executável do Unix ao copiar o pacote.
    # Registre os scripts de implantação como executáveis no índice do Git
    # para que a Oracle possa chamá-los diretamente após o próximo pull.
    $shellScripts = Get-ChildItem -LiteralPath $publicationRoot -File -Filter "*.sh" -Recurse
    foreach ($shellScript in $shellScripts) {
        # Compatível com o Windows PowerShell 5.1, que não possui Path.GetRelativePath.
        $relativeShellPath = $shellScript.FullName.Substring($publicationRoot.Length).TrimStart("\", "/").Replace("\", "/")
        & $gitPath update-index --chmod=+x -- $relativeShellPath
        if ($LASTEXITCODE -ne 0) {
            Stop-Publication "nao foi possivel preservar a permissao de execucao de $relativeShellPath."
        }
    }

    $configuredName = & $gitPath config user.name
    if (-not $configuredName) {
        & $gitPath config user.name "andrelbr22"
    }
    $configuredEmail = & $gitPath config user.email
    if (-not $configuredEmail) {
        & $gitPath config user.email "andrelbr22@users.noreply.github.com"
    }

    & $gitPath diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-Host "A pasta ja corresponde a versao publicada. Nenhum arquivo precisava ser enviado." -ForegroundColor Green
        return
    }

    & $gitPath commit -m "Estabiliza promocao, proxy e worker na V1.23.0 R2 em teste"
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "nao foi possivel criar a atualizacao local."
    }

    Write-Host "Enviando a nova versao ao GitHub..."
    & $gitPath push origin main
    if ($LASTEXITCODE -ne 0) {
        Stop-Publication "o GitHub recusou o envio. Verifique o login e tente novamente."
    }
} finally {
    Pop-Location
}

Write-Host ""
Write-Host "PUBLICACAO CONCLUIDA." -ForegroundColor Green
Write-Host "A versao foi enviada ao ambiente de teste. A producao depende de aprovacao manual."
Write-Host "Depois da atualizacao automatica, valide a V1.23.0 R2 no endereco /testefdi antes de promover."
