"use strict";

const BASE_PATH = location.pathname === "/testefdi" || location.pathname.startsWith("/testefdi/") ? "/testefdi" : "";
const LANDING_PATH = `${BASE_PATH}/`;
const PLATFORM_PATH = `${BASE_PATH}/plataforma/`;
const ANALYSIS_CACHE_TTL_MS = 300000;

const state = {
  session: null,
  view: "dashboard",
  tabs: { dashboard: "overview", analysis: "stocks", analysisMode: "list", portfolio: "positions", finances: "monthly", backtests: "history", admin: "levels" },
  market: null,
  marketEnvelope: null,
  comparison: null,
  comparisonLoading: false,
  comparisonYears: 5,
  comparisonCustom: false,
  comparisonCustomFrom: "",
  comparisonCustomTo: "",
  comparisonSelected: ["CDI","IBOV","IFIX"],
  comparisonBaseMode: "common",
  analysisRows: [],
  analysisPreset: "default",
  analysisCatalog: {},
  analysisLoadedType: null,
  analysisCustom: [],
  analysisCustomCache: {},
  analysisCustomUsageCache: {},
  analysisCustomUsage: {used:0,limit:0},
  currentCustomFilter: null,
  analysisLimit: 50,
  analysisResultCache: new Map(),
  analysisRequestSerial: 0,
  analysisUpdateCheckedAt: 0,
  analysisEnsureSentAt: 0,
  readCache: new Map(),
  readRequests: new Map(),
  curveYears: 10,
  curveHistory: [],
  curveHistoryCount: 1,
  curveHistoryLoading: false,
  curveHistoryLoaded: false,
  visibleColumns: JSON.parse(localStorage.getItem("fdi-visible-columns") || "{}"),
  portfolios: [],
  portfolioId: null,
  portfolioNewsMode: "portfolio",
  recommendationCategory: "all",
  newsRefreshTimer: null,
  alertCatalog: null,
  alertData: null,
  adminUsersOffset: 0,
  adminUsersQuery: "",
  adminUsersStatus: "",
  adminUsersLevel: "",
  financeMonth: new Date().toISOString().slice(0,7),
  officialBacktestJobs: new Map(),
  backtestCatalog: null,
  requestControllers: new Map(),
  emailLoginAddress: "",
  portalAdmin: null,
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = (value) => String(value ?? "").replace(/[&<>'"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[char]);
const nullable = (value) => value === null || value === undefined || value === "";
const number = (value, digits = 2) => nullable(value) || Number.isNaN(Number(value)) ? "—" : Number(value).toLocaleString("pt-BR", { minimumFractionDigits: digits, maximumFractionDigits: digits });
const money = (value, currency = "BRL") => nullable(value) ? "—" : Number(value).toLocaleString("pt-BR", { style: "currency", currency, maximumFractionDigits: currency === "BRL" ? 2 : 2 });
const pct = (value, signed = false) => nullable(value) ? "—" : `${signed && Number(value) > 0 ? "+" : ""}${number(value, 2)}%`;
const dateTime = (value) => nullable(value) ? "—" : new Date(value).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
const dateOnly = (value) => nullable(value) ? "—" : new Date(`${String(value).slice(0,10)}T12:00:00`).toLocaleDateString("pt-BR");
const variationClass = (value) => nullable(value) ? "" : Number(value) >= 0 ? "positive" : "negative";

function toast(message, type = "") {
  const node = document.createElement("div");
  node.className = `toast ${type}`;
  node.textContent = message;
  $("#toast-region").append(node);
  setTimeout(() => node.remove(), 5200);
}

function readableApiError(detail,status){
  const code=typeof detail==="string"?detail:"";
  const messages={
    permission_required:"Este recurso não está liberado para a sua conta.",
    portfolio_not_found:"A carteira solicitada não foi encontrada.",
    custom_investment_not_found:"O investimento não foi encontrado ou já foi arquivado.",
    finance_transaction_not_found:"O lançamento não foi encontrado ou já foi arquivado.",
    invalid_finance_category:"A categoria não corresponde ao tipo de lançamento escolhido.",
    invalid_finance_status:"A situação não corresponde ao tipo de lançamento escolhido.",
    invalid_competence_month:"O mês informado é inválido.",
    unsupported_or_duplicate_ticker:"Use o código principal do ativo. Mercados fracionários e códigos temporários não são cadastrados separadamente.",
    active_personal_backtest_exists:"Já existe uma análise em processamento. Aguarde a conclusão.",
    invalid_secondary_email:"Informe um segundo e-mail válido ou deixe o campo vazio.",
    price_alert_limit_not_granted:"Sua conta ainda não possui uma quantidade de ativos liberada para alertas.",
    price_alert_requires_condition:"Preencha ao menos uma condição para este ativo.",
    unsupported_market_alert_symbol:"Escolha um dos ativos disponíveis no catálogo de mercados.",
    b3_alert_asset_not_found:"Este código não está disponível no catálogo principal da B3.",
    alert_email_delivery_not_configured:"O envio de e-mails ainda não foi configurado pelo administrador.",
    price_alert_not_found:"Este alerta não existe mais ou pertence a outra conta.",
    access_level_not_found:"O nível de acesso selecionado não foi encontrado.",
    access_level_is_inactive:"Este nível está inativo e não pode receber novos usuários.",
    access_level_already_exists:"Já existe um nível com esse identificador.",
    owner_permissions_are_permanent:"As permissões do proprietário são permanentes.",
    owner_access_level_is_permanent:"O nível do proprietário é permanente.",
    access_level_required_for_overrides:"Atribua um nível antes de criar ajustes individuais.",
    background_job_not_found:"Este trabalho não está mais disponível na fila.",
    email_login_rate_limited:"Aguarde um minuto antes de solicitar um novo código.",
    email_login_temporarily_limited:"Foram solicitados muitos códigos nesta conexão. Aguarde alguns minutos e tente novamente.",
    email_login_code_invalid_or_expired:"O código é inválido, expirou ou já foi utilizado. Solicite outro se necessário.",
    email_login_delivery_not_configured:"O acesso por e-mail ainda não foi configurado pelo administrador.",
    email_login_delivery_failed:"Não foi possível enviar o código agora. Tente novamente em instantes.",
    portal_page_revision_conflict:"A página foi alterada em outra sessão. Recarregue esta área antes de salvar novamente.",
    portal_book_slug_exists:"Já existe um livro com esse identificador.",
    portal_book_not_found:"Este livro não foi encontrado.",
    portal_media_not_found:"A imagem selecionada não foi encontrada.",
    portal_media_in_use:"Esta imagem ainda está vinculada a um livro.",
    portal_sales_link_limit:"Cada livro aceita no máximo três links de venda.",
    portal_https_url_invalid:"Os links de venda devem começar com https:// e não podem conter credenciais.",
    portal_image_size_invalid:"A imagem deve ter no máximo 4 MB.",
    portal_image_signature_invalid:"O conteúdo da imagem não corresponde ao tipo PNG, JPG ou WebP informado.",
  };
  if(typeof detail==="object"&&detail?.permission_required)return messages.permission_required;
  if(typeof detail==="object"&&detail?.price_alert_limit_reached)return `O limite de ${detail.price_alert_limit_reached} ativo(s) com alerta foi atingido.`;
  if(typeof detail==="object"&&detail?.alert_conditions_not_granted)return "Uma das condições escolhidas não está liberada para sua conta.";
  if(messages[code])return messages[code];
  if(status>=500)return "O serviço está temporariamente indisponível. Seus dados foram preservados; tente novamente em instantes.";
  if(status===404)return "A informação solicitada não foi encontrada.";
  if(status===422)return "Revise os campos informados e tente novamente.";
  return code||`Não foi possível concluir a solicitação (HTTP ${status}).`;
}

async function api(path, options = {}) {
  const requestOptions = {...options};
  const cacheTtlMs = Math.max(0, Number(requestOptions.cacheTtlMs || 0));
  const bypassCache = Boolean(requestOptions.bypassCache);
  const invalidateCache = requestOptions.invalidateCache !== false;
  delete requestOptions.cacheTtlMs;
  delete requestOptions.bypassCache;
  delete requestOptions.invalidateCache;
  const method = String(requestOptions.method || "GET").toUpperCase();
  if (method === "GET" && cacheTtlMs > 0 && !bypassCache) {
    const cached = state.readCache.get(path);
    if (cached && Date.now() - cached.savedAt < cacheTtlMs) return cached.body;
  }
  const key = requestOptions.requestKey;
  const coalesceKey = method === "GET" && cacheTtlMs > 0 && !bypassCache && !key ? path : null;
  if (coalesceKey && state.readRequests.has(coalesceKey)) return state.readRequests.get(coalesceKey);
  let controller = null;
  if (key) {
    state.requestControllers.get(key)?.abort();
    controller = new AbortController();
    state.requestControllers.set(key, controller);
    requestOptions.signal = controller.signal;
    delete requestOptions.requestKey;
  }
  const request = { credentials: "same-origin", ...requestOptions };
  request.headers = { "Content-Type": "application/json", ...(requestOptions.headers || {}) };
  const pending = (async()=>{
    let response;
    try {
      response = await fetch(`${BASE_PATH}${path}`, request);
    } finally {
      if (key && state.requestControllers.get(key) === controller) state.requestControllers.delete(key);
    }
    if (response.status === 401) {
      showLogin();
      throw new Error("Sua sessão expirou. Entre novamente.");
    }
    let body = null;
    try { body = await response.json(); } catch (_) { body = null; }
    if (!response.ok) {
      const detail = body?.detail;
      const readable = readableApiError(detail,response.status);
      throw new Error(readable);
    }
    if (method === "GET" && cacheTtlMs > 0) state.readCache.set(path, {savedAt:Date.now(),body});
    else if (method !== "GET" && invalidateCache) state.readCache.clear();
    return body;
  })();
  if (coalesceKey) state.readRequests.set(coalesceKey,pending);
  try { return await pending; }
  finally { if(coalesceKey&&state.readRequests.get(coalesceKey)===pending)state.readRequests.delete(coalesceKey); }
}

function safeExternalUrl(value) {
  try { const url=new URL(String(value||"")); return ["http:","https:"].includes(url.protocol)?url.href:"#"; }
  catch (_) { return "#"; }
}

function showLogin() {
  $("#app-shell").classList.add("hidden");
  $("#login-view").classList.remove("hidden");
}

function showApp() {
  $("#login-view").classList.add("hidden");
  $("#app-shell").classList.remove("hidden");
}

function configureAccess() {
  const { user, access } = state.session;
  $("#profile-name").textContent = user.name || user.email;
  $("#profile-role").textContent = access.is_owner ? "Administrador master" : access.access_level_name || (access.access_inheritance?"Acesso por nível":"Acesso personalizado");
  const avatar = $("#profile-avatar");
  avatar.textContent = (user.name || user.email || "U").slice(0, 1).toUpperCase();
  if (user.picture) avatar.innerHTML = `<img src="${esc(user.picture)}" alt="">`;
  $$(".owner-only").forEach(node => node.classList.toggle("hidden", !access.is_owner));
  $$(".permission-study").forEach(node => node.classList.toggle("hidden", !access.can_view_backtest_studies));
  const canAdmin=Boolean(access.is_owner||access.can_manage_users||access.can_sync_market||access.can_manage_portal);
  const navRules = {
    analysis: access.can_view_market,
    portfolio: access.can_view_portfolio,
    finances: access.can_view_finances,
    backtests: access.can_view_backtests,
    admin: canAdmin,
  };
  Object.entries(navRules).forEach(([view, allowed]) => {
    const item = $(`.nav-item[data-view="${view}"]`);
    if (item) item.classList.toggle("hidden", !allowed);
  });
  const adminItem=$('.nav-item[data-view="admin"]');
  if(adminItem)adminItem.classList.toggle("hidden",!canAdmin);
  for(const tab of ["levels","users"]){const node=$(`.tabs[data-tabs="admin"] [data-tab="${tab}"]`);if(node)node.classList.toggle("hidden",!(access.is_owner||access.can_manage_users));}
  for(const tab of ["data","quality"]){const node=$(`.tabs[data-tabs="admin"] [data-tab="${tab}"]`);if(node)node.classList.toggle("hidden",!(access.is_owner||access.can_sync_market));}
  const portalTab=$('.tabs[data-tabs="admin"] [data-tab="portal"]');
  if(portalTab)portalTab.classList.toggle("hidden",!(access.is_owner||access.can_manage_portal));
  for(const tab of ["jobs","operations","system"]){const node=$(`.tabs[data-tabs="admin"] [data-tab="${tab}"]`);if(node)node.classList.toggle("hidden",!access.is_owner);}
  if(!access.is_owner&&!access.can_manage_users){
    state.tabs.admin=access.can_manage_portal?"portal":"data";
    activateTab("admin",state.tabs.admin,false);
  }
}

function emailLoginMessage(message,type=""){
  const node=$("#email-login-message");
  if(!node)return;
  node.textContent=message;
  node.className=`login-message${type?` ${type}`:""}`;
}

async function requestEmailLogin(form){
  const button=form.querySelector('button[type="submit"]');
  const email=String(new FormData(form).get("email")||"").trim().toLowerCase();
  button.disabled=true;
  try{
    await api("/auth/email/request",{method:"POST",body:JSON.stringify({email,next:PLATFORM_PATH}),invalidateCache:false});
    state.emailLoginAddress=email;
    $("#email-login-verify-form")?.classList.remove("hidden");
    emailLoginMessage("Código enviado. Ele vale por 10 minutos e o envio de um novo código invalida o anterior.");
    $("#email-login-code")?.focus();
    let remaining=60;
    const original=button.textContent;
    button.textContent=`Reenviar em ${remaining}s`;
    const timer=setInterval(()=>{
      remaining-=1;
      button.textContent=remaining>0?`Reenviar em ${remaining}s`:"Enviar novo código";
      if(remaining<=0){clearInterval(timer);button.disabled=false;button.textContent="Enviar novo código";}
    },1000);
    setTimeout(()=>{if(!button.isConnected)clearInterval(timer);},61000);
  }catch(error){button.disabled=false;emailLoginMessage(error.message,"error");}
}

async function verifyEmailLogin(form){
  const button=form.querySelector('button[type="submit"]');
  const code=String(new FormData(form).get("code")||"").replace(/\D/g,"");
  const email=state.emailLoginAddress||String($("#email-login-address")?.value||"").trim().toLowerCase();
  button.disabled=true;
  try{
    const result=await api("/auth/email/verify",{method:"POST",body:JSON.stringify({email,code,next:PLATFORM_PATH}),invalidateCache:false});
    emailLoginMessage("Código confirmado. Abrindo a plataforma…");
    location.assign(result.destination||PLATFORM_PATH);
  }catch(error){button.disabled=false;emailLoginMessage(error.message,"error");$("#email-login-code")?.select();}
}

function setView(view, tab = null) {
  state.view = view;
  if (tab) state.tabs[view] = tab;
  $$(".view").forEach(node => node.classList.toggle("active", node.id === `view-${view}`));
  $$(".nav-item").forEach(node => node.classList.toggle("active", node.dataset.view === view));
  document.body.classList.remove("mobile-nav-open");
  if (tab) activateTab(view, tab, false);
  loadCurrentView();
}

function activateTab(group, tab, load = true) {
  state.tabs[group] = tab;
  $$(`.tabs[data-tabs="${group}"] .tab`).forEach(node => node.classList.toggle("active", node.dataset.tab === tab));
  if (load) loadCurrentView();
}

function loadingCards(count = 4) {
  return `<div class="loading-grid">${Array.from({length: count}, () => '<div class="skeleton"></div>').join("")}</div>`;
}

function errorState(error, retry = "") {
  return `<div class="data-card error-state"><strong>Não foi possível carregar este painel.</strong><span>${esc(error?.message || error)}</span>${retry ? `<div style="margin-top:14px"><button class="button secondary" data-retry="${esc(retry)}">Tentar novamente</button></div>` : ""}</div>`;
}

function metricCard(label, value, meta = "", variation = null) {
  return `<article class="metric-card"><div class="metric-label"><span>${esc(label)}</span>${nullable(variation) ? "" : `<span class="${variationClass(variation)}">${pct(variation, true)}</span>`}</div><strong class="metric-value">${value}</strong><span class="metric-meta">${esc(meta)}</span></article>`;
}

function marketMetric(data, label) {
  return Object.values(data?.quoted || {}).flat().find(item => item.label === label) || null;
}

function renderMarketSummary() {
  const data = state.market || {};
  const ibov = marketMetric(data, "IBOV");
  const ipca = (data.inflation || []).find(item => item.label === "IPCA");
  const dolar = (data.fx || []).find(item => item.label === "Dólar / Real");
  const selic = data.selic || {};
  $("#market-summary").innerHTML = [
    metricCard("IBOV", ibov ? `${number(ibov.current, 0)} pts` : "—", "Brasil", ibov?.variations?.["1d"]),
    metricCard("IPCA • 12 meses", pct(ipca?.value_12m), `Referência ${dateOnly(ipca?.as_of)} • IBGE`),
    metricCard("Dólar / Real", dolar ? money(dolar.current) : "—", "Câmbio", dolar?.variations?.["1d"]),
    metricCard("Selic atual", pct(selic.current), "Meta anual • Banco Central"),
  ].join("");
  const generated = data.generated_at || state.marketEnvelope?.finished_at;
  $("#market-updated").textContent = generated ? `Atualização mais recente em ${dateTime(generated)}` : "Atualização em segundo plano";
}

const updateStatusLabels={updated:"Atualizado",partial:"Atualização parcial",stale:"Desatualizado",queued:"Na fila",running:"Atualizando",failed:"Falhou",unavailable:"Aguardando dados"};
function marketUpdatePanel(keys, title="Atualizações deste painel") {
  const updates=state.marketEnvelope?.updates||{};
  const rows=keys.map(key=>updates[key]).filter(Boolean);
  if(!rows.length)return "";
  const completed=rows.map(row=>row.last_updated_at).filter(Boolean).sort();
  const next=rows.map(row=>row.next_update_at).filter(Boolean).sort();
  const active=rows.some(row=>["queued","running"].includes(row.status));
  const failed=rows.some(row=>row.status==="failed");
  const partial=rows.some(row=>row.status==="partial");
  const status=active?"Atualizando em segundo plano":failed||partial?"Uma fonte requer atenção":"Dados disponíveis";
  const details=rows.map(row=>`<div class="update-detail-row"><span><strong>${esc(row.label)}</strong><small>${esc(row.source||"")}${row.warnings?.length?` • ${row.warnings.length} item(ns) preservado(s) da atualização anterior`:""}</small></span><span><span class="pill ${["failed","stale","partial"].includes(row.status)?"warning":""}">${esc(updateStatusLabels[row.status]||row.status)}</span><small>${row.last_updated_at?dateTime(row.last_updated_at):"Ainda não atualizada"}${row.next_update_at?` • próxima ${dateTime(row.next_update_at)}`:""}</small></span></div>`).join("");
  return `<div class="update-panel"><div class="update-summary"><span><strong>${esc(title)}</strong><small>${completed.length?`Mais recente: ${dateTime(completed[completed.length-1])}`:"Primeira atualização pendente"}${next.length?` • próxima rodada: ${dateTime(next[0])}`:""}</small></span><span><small>${esc(status)}</small><button class="button secondary compact" data-refresh-groups="${esc(keys.join(","))}" ${active?"disabled":""}>Atualizar agora</button></span></div><details class="update-details"><summary>Detalhes das fontes</summary>${details}</details></div>`;
}
function recordedUpdatePanel(title,lastUpdated,description="") {
  return `<div class="update-panel"><div class="update-summary"><span><strong>${esc(title)}</strong><small>${lastUpdated?`Atualização mais recente: ${dateTime(lastUpdated)}`:"Ainda sem atualização registrada"}${description?` • ${esc(description)}`:""}</small></span></div></div>`;
}

function marketTable(items, columns) {
  if (!items?.length) return '<div class="empty-state"><strong>Dados ainda indisponíveis</strong>A atualização ocorre em segundo plano. Os outros painéis continuam utilizáveis.</div>';
  return `<div class="table-scroll"><table><thead><tr>${columns.map(col => `<th>${esc(col.label)}</th>`).join("")}</tr></thead><tbody>${items.map(item => `<tr>${columns.map(col => `<td class="${col.className ? col.className(item) : ""}">${col.render(item)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

const marketColumns = [
  {label:"Indicador", render: row => `<strong>${esc(row.label)}</strong>${row.proxy ? '<br><span class="pill warning">Proxy transparente</span>' : ""}`},
  {label:"Atual", render: row => nullable(row.current) ? "—" : `${number(row.current, row.unit === "pontos" ? 0 : 2)} ${esc(row.unit || "")}`},
  ...[["1d","1 dia"],["1w","1 semana"],["1m","1 mês"],["1y","1 ano"]].map(([key,label]) => ({label, className: row => variationClass(row.variations?.[key]), render: row => pct(row.variations?.[key], true)})),
];

function sectionCard(title, body, subtitle = "", source = null) {
  return `<section class="data-card"><div class="card-section"><div class="card-heading"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ""}</div>${source?.url ? `<a class="source-link" target="_blank" rel="noopener" href="${esc(source.url)}">${esc(source.label || "Fonte")}</a>` : ""}</div>${body}</div></section>`;
}

function renderDashboardTab() {
  const root = $("#dashboard-tab-content");
  const data = state.market;
  if (!data) { root.innerHTML = loadingCards(6); return; }
  const tab = state.tabs.dashboard;
  if (tab === "overview") {
    const inflation = marketTable(data.inflation || [], [
      {label:"Indicador",render:r=>`<strong>${esc(r.label)}</strong>`},
      {label:"Acumulado 12 meses",render:r=>pct(r.value_12m),className:r=>variationClass(r.value_12m)},
      {label:"Referência",render:r=>dateOnly(r.as_of)},
    ]);
    root.innerHTML = `${marketUpdatePanel(["global_markets","macro","fx","selic_current"])}<div class="panel-grid">${sectionCard("Brasil", marketTable(data.quoted?.brazil, marketColumns), "Índices e variações")}${sectionCard("Inflação", inflation, "Brasil e Estados Unidos")}</div>`;
  } else if (tab === "rates") {
    const selic = data.selic || {};
    const projections = [selic.current_year, selic.next_year].filter(Boolean);
    const selicCards = `<div class="metric-grid">${metricCard("Selic atual", pct(selic.current), `Referência ${dateOnly(selic.current_as_of)}`)}${projections.map(item => metricCard(`Selic projetada • ${item.reference_year || ""}`, pct(item.value), `Focus de ${dateOnly(item.survey_date)}`)).join("")}</div><div class="notice info" style="margin-top:13px">${esc(selic.projection_note || "As projeções são medianas do Relatório Focus.")}</div>`;
    const fixed = marketTable(data.fixed_income || [], [
      {label:"Indicador",render:r=>`<strong>${esc(r.label)}</strong>${r.proxy ? `<br><small>${esc(r.proxy_label || "Proxy")}</small>`:""}`},
      {label:"Rentabilidade anual",render:r=>pct(r.annual_return_pct),className:r=>variationClass(r.annual_return_pct)},
      {label:"Rentabilidade mensal",render:r=>pct(r.monthly_return_pct),className:r=>variationClass(r.monthly_return_pct)},
      {label:"Referência",render:r=>dateOnly(r.as_of)},
    ]);
    const rates = data.us_rates || {};
    const yields = marketTable(rates.yields || [], [{label:"Prazo",render:r=>esc(r.maturity)},{label:"Yield anual",render:r=>pct(r.yield_pct)}]);
    const bonds = marketTable(rates.bond_returns || [], [
      {label:"T-Bonds",render:r=>`<strong>${esc(r.label)}</strong><br><small>${esc(r.proxy_label || "")}</small>`},
      {label:"1 mês",render:r=>pct(r.monthly_return_pct,true),className:r=>variationClass(r.monthly_return_pct)},
      {label:"1 ano",render:r=>pct(r.annual_return_pct,true),className:r=>variationClass(r.annual_return_pct)},
    ]);
    root.innerHTML = `${marketUpdatePanel(["selic_current","selic_focus","macro","rates_calendar"])}<div class="panel-grid">${sectionCard("Selic e projeções Focus", selicCards, "Taxas anuais")}${sectionCard("Renda fixa brasileira", fixed, "Somente rentabilidades anual e mensal")}${sectionCard("Treasuries dos EUA", yields, `Spread 10a − 2a: ${pct(rates.spread_10y_2y)}`, {url:rates.url,label:rates.source})}${sectionCard("Rentabilidade de T-Bonds", bonds, "ETFs usados como proxies líquidos")}</div><div class="notice info" style="margin-top:16px"><strong>Para que serve o spread?</strong> ${esc(rates.spread_explanation || "Compara juros longos e curtos e ajuda a interpretar a inclinação da curva americana.")}</div>`;
  } else if (tab === "global") {
    root.innerHTML = `${marketUpdatePanel(["global_markets"])}<div class="global-market-layout"><div class="global-market-main">${sectionCard("Bolsas globais", marketTable(data.quoted?.global, marketColumns))}</div><div class="global-market-stack">${sectionCard("Risco e dólar", marketTable(data.quoted?.risk, marketColumns))}${sectionCard("Commodities", marketTable(data.quoted?.commodities, marketColumns))}</div></div>`;
  } else if (tab === "crypto") {
    const crypto = marketTable(data.crypto || [], [
      {label:"Ativo",render:r=>`<strong>${esc(r.label)}</strong>`}, {label:"Em dólar",render:r=>money(r.value_usd,"USD")},
      {label:"Em real",render:r=>`${money(r.value_brl,"BRL")}${r.brl_derived_from_fx ? '<br><small>Convertido pelo câmbio atual</small>':""}`},
      ...[["1d","1 dia"],["1w","1 semana"],["1m","1 mês"],["1y","1 ano"]].map(([key,label])=>({label,render:r=>pct(r.variations?.[key],true),className:r=>variationClass(r.variations?.[key])})),
    ]);
    root.innerHTML = `${marketUpdatePanel(["crypto","fx"])}<div class="panel-grid">${sectionCard("Criptoativos", crypto)}${sectionCard("Resumo de câmbio", marketTable(data.fx, marketColumns), "Cotações orientadas conforme o nome do par")}</div>`;
  } else if (tab === "curve") {
    root.innerHTML = marketUpdatePanel(["rates_calendar"])+renderCurve(data.curve || {});
    if(!state.curveHistoryLoading&&!state.curveHistoryLoaded)loadCurveHistory();
  } else if (tab === "comparison") {
    if (state.comparison) renderComparison(); else loadComparison();
  } else if (tab === "calendar") {
    loadOfficialCalendar();
  } else if (tab === "headlines") {
    loadHeadlines();
  } else if (tab === "facts") {
    loadRelevantFacts();
  }
}

async function loadOfficialCalendar(){
  const root=$("#dashboard-tab-content");root.innerHTML=loadingCards(5);
  try{
    const payload=await api("/investor-events/calendar",{requestKey:"official-calendar",cacheTtlMs:60000,bypassCache:true});
    if(state.tabs.dashboard!=="calendar")return;
    const rows=payload.items||[];
    const table=rows.length?marketTable(rows,[
      {label:"Data",render:r=>`<strong>${dateOnly(r.date)}</strong>`},
      {label:"Evento",render:r=>`<strong>${esc(r.title)}</strong>${r.metadata?.conditional?'<br><span class="pill warning">CONDICIONAL</span>':""}`},
      {label:"Categoria",render:r=>esc(r.category)},{label:"Região",render:r=>esc(r.region||"—")},{label:"Horário",render:r=>esc(r.time||"—")},
      {label:"Fonte",render:r=>r.source_url?`<a href="${esc(safeExternalUrl(r.source_url))}" target="_blank" rel="noopener noreferrer">${esc(r.source||"Consultar")}</a>`:esc(r.source||"—")},
    ]):'<div class="empty-state"><strong>Agenda oficial sendo preparada</strong>A atualização ocorre em segundo plano e os dados anteriores nunca são apagados por uma falha de fonte.</div>';
    root.innerHTML=marketUpdatePanel(["official_calendar"])+sectionCard("Agenda oficial do investidor",table,"Eventos econômicos, feriados e eleições renovados anualmente");
  }catch(error){root.innerHTML=errorState(error,"market");}
}

async function loadRelevantFacts(){
  const root=$("#dashboard-tab-content");root.innerHTML=loadingCards(5);
  try{
    const payload=await api("/investor-events/relevant-facts?limit=100",{requestKey:"relevant-facts",cacheTtlMs:60000,bypassCache:true});
    if(state.tabs.dashboard!=="facts")return;
    const rows=payload.items||[];
    const content=rows.length?`<div class="headline-list"><div class="headline headline-header"><span>#</span><span>Companhia • assunto • ativos</span><span>Entrega</span></div>${rows.map((item,index)=>`<a class="headline" href="${esc(safeExternalUrl(item.document_url))}" target="_blank" rel="noopener noreferrer"><span class="headline-number">${String(index+1).padStart(2,"0")}</span><span><strong>${esc(item.issuer_name)}</strong><small>${esc(item.subject||"Fato relevante")}${(item.tickers||[]).length?` • ${item.tickers.map(esc).join(", ")}`:""}</small></span><small>${dateTime(item.delivered_at)}</small></a>`).join("")}</div>`:'<div class="empty-state"><strong>Fatos relevantes sendo sincronizados</strong>A fonte oficial da CVM será consultada em segundo plano.</div>';
    root.innerHTML=marketUpdatePanel(["cvm_relevant_facts"])+sectionCard("Fatos relevantes oficiais",content,"Metadados e documentos publicados no sistema IPE da CVM",{url:"https://dados.cvm.gov.br/dataset/cia_aberta-doc-ipe",label:"CVM • Dados Abertos"});
  }catch(error){root.innerHTML=errorState(error,"market");}
}

function renderCurve(curve) {
  const current={reference_date:curve.as_of,points:curve.points||[],curve_type:curve.curve_type,title:curve.title,source:curve.source,url:curve.url};
  if(!current.points.length)return errorState("A fonte oficial ainda não retornou os pontos da curva.","market");
  const history=(state.curveHistory||[]).filter(item=>String(item.reference_date)!==String(current.reference_date));
  const requested=Math.max(1,Number(state.curveHistoryCount||1));
  const series=[current,...history.slice(0,requested-1)].map(item=>({...item,points:(item.points||[]).filter(p=>Number(p.years)<=20&&(!state.curveYears||Number(p.years)<=state.curveYears)&&!nullable(p.nominal_rate))})).filter(item=>item.points.length);
  if(!series.length)return errorState("Não há vértices disponíveis para esse horizonte.","market");
  const width=900,height=320,padLeft=68,padRight=22,padTop=18,padBottom=58;
  const allPoints=series.flatMap(item=>item.points),maxX=Math.max(...allPoints.map(p=>Number(p.years)||0),1);
  const values=allPoints.map(p=>Number(p.nominal_rate)).filter(Number.isFinite),minY=Math.min(...values),maxY=Math.max(...values);
  const x=p=>padLeft+(Number(p.years)/maxX)*(width-padLeft-padRight),y=value=>height-padBottom-((Number(value)-minY)/Math.max(maxY-minY,.1))*(height-padTop-padBottom);
  const colors=["#0b5d4b","#c79b3b","#2775b6","#8c5aa6"],paths=series.map((item,index)=>`<path d="${item.points.map((p,i)=>`${i?"L":"M"}${x(p).toFixed(1)},${y(p.nominal_rate).toFixed(1)}`).join(" ")}" fill="none" stroke="${colors[index]}" stroke-width="${index?2:3}" ${index?'stroke-dasharray="7 4"':""}/>`).join("");
  const currentPoints=series[0].points;
  const circles=currentPoints.map(p=>`<circle cx="${x(p)}" cy="${y(p.nominal_rate)}" r="3" fill="${colors[0]}"><title>${esc(p.contract||`${number(p.years,2)} anos`)} • ${pct(p.nominal_rate)}</title></circle>`).join("");
  const labels=currentPoints.filter((_,i)=>i%Math.max(1,Math.ceil(currentPoints.length/10))===0).map(p=>`<text x="${x(p)}" y="${height-padBottom+19}" font-size="11" text-anchor="middle" fill="#67756f">${number(p.years,1)}a</text>`).join("");
  const yTicks=Array.from({length:5},(_,i)=>minY+(maxY-minY)*(i/4));
  const yGrid=yTicks.map(value=>`<line x1="${padLeft}" x2="${width-padRight}" y1="${y(value)}" y2="${y(value)}" stroke="#e3eae7" stroke-width="1"/><text x="${padLeft-9}" y="${y(value)+4}" font-size="11" text-anchor="end" fill="#67756f">${number(value,2)}%</text>`).join("");
  const axes=`<line x1="${padLeft}" x2="${padLeft}" y1="${padTop}" y2="${height-padBottom}" stroke="#8b9993"/><line x1="${padLeft}" x2="${width-padRight}" y1="${height-padBottom}" y2="${height-padBottom}" stroke="#8b9993"/><text x="${(padLeft+width-padRight)/2}" y="${height-12}" text-anchor="middle" font-size="12" font-weight="700" fill="#46534e">Prazo até o vencimento (anos)</text><text transform="translate(16 ${(padTop+height-padBottom)/2}) rotate(-90)" text-anchor="middle" font-size="12" font-weight="700" fill="#46534e">Taxa anual (%)</text>`;
  const svg=`<svg class="chart-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Curvas de juros: prazo em anos no eixo horizontal e taxa anual no eixo vertical">${yGrid}${axes}${paths}${circles}${labels}</svg>`;
  const periods=[[1,"1 ano"],[2,"2 anos"],[5,"5 anos"],[10,"10 anos"],[20,"20 anos"],[0,"Máximo"]];
  const controls=`<div class="curve-controls"><div class="chart-periods" role="group" aria-label="Horizonte da curva">${periods.map(([years,label])=>`<button class="button ${state.curveYears===years?"primary":"secondary"}" data-curve-years="${years}">${label}</button>`).join("")}</div><div class="chart-periods" role="group" aria-label="Comparar curvas anteriores">${[[1,"Somente atual"],[2,"+ 1 anterior"],[4,"+ 3 anteriores"]].map(([count,label])=>`<button class="button ${requested===count?"primary":"secondary"}" data-curve-history-count="${count}">${label}</button>`).join("")}</div></div>`;
  const curveLegend=series.map((item,index)=>`<span><i class="legend-dot" style="background:${colors[index]}"></i>${index?"Curva anterior":"Curva atual"} • ${dateOnly(item.reference_date)}</span>`).join("");
  const method=curve.curve_type==="di_pre"?"Taxa de ajuste DI1 • efetiva anual, base 252 dias úteis":"Taxa prefixada nominal • ETTJ ANBIMA";
  const historyNote=state.curveHistory.length?"As referências diárias ficam preservadas para comparação.":"O histórico começará a ser formado após esta versão registrar as próximas atualizações.";
  return sectionCard(curve.title || "Curva de juros brasileira",`${controls}<div class="chart">${svg}</div><div class="chart-legend">${curveLegend}</div><div class="notice info"><strong>${esc(method)}.</strong> ${esc(historyNote)} ${esc(curve.methodology||"Nenhum vértice é extrapolado.")}</div>`,`Curva de juros futuros • horizonte dos contratos e deslocamento entre datas`,{url:curve.url,label:curve.source});
}

async function loadCurveHistory(){
  state.curveHistoryLoading=true;
  try{state.curveHistory=await api("/market-dashboard/interest-curve/history?limit=12");if(state.tabs.dashboard==="curve")renderDashboardTab();}
  catch(_){state.curveHistory=[];}
  state.curveHistoryLoaded=true;
  state.curveHistoryLoading=false;
}

const comparisonColors = ["#0b5d4b","#c79b3b","#2775b6","#8c5aa6","#d0614c","#3d9a78","#9b7d31","#5267a5","#c24f86","#69766f","#df8437","#3999a3","#7c655c","#22577a","#9a031e","#386641","#7b2cbf","#bc6c25","#0077b6","#6a994e","#ef476f","#118ab2","#8338ec","#fb8500","#495057","#2a9d8f"];

function comparisonDateBounds() {
  const timestamps=(state.comparison?.series||[]).flatMap(item=>(item.points||[]).map(point=>new Date(`${point.date}T12:00:00Z`).getTime())).filter(Number.isFinite);
  if(!timestamps.length)return null;
  return {min:new Date(Math.min(...timestamps)),max:new Date(Math.max(...timestamps))};
}

function isoDay(value) { return value instanceof Date&&!Number.isNaN(value.getTime())?value.toISOString().slice(0,10):""; }

function ensureComparisonCustomDates() {
  const bounds=comparisonDateBounds();
  if(!bounds)return;
  if(!state.comparisonCustomTo)state.comparisonCustomTo=isoDay(bounds.max);
  if(!state.comparisonCustomFrom){
    const start=new Date(bounds.max);
    start.setUTCFullYear(start.getUTCFullYear()-Math.max(1,Number(state.comparisonYears)||5));
    state.comparisonCustomFrom=isoDay(start<bounds.min?bounds.min:start);
  }
}

function comparisonWindow() {
  const bounds=comparisonDateBounds();
  if(!bounds)return null;
  if(state.comparisonCustom){
    const start=new Date(`${state.comparisonCustomFrom}T00:00:00Z`),end=new Date(`${state.comparisonCustomTo}T23:59:59Z`);
    if(!state.comparisonCustomFrom||!state.comparisonCustomTo||Number.isNaN(start.getTime())||Number.isNaN(end.getTime())||start>end)return {...bounds,error:"A data inicial deve ser anterior ou igual à data final."};
    if(state.comparisonCustomFrom<isoDay(bounds.min)||state.comparisonCustomTo>isoDay(bounds.max))return {...bounds,error:`Escolha datas entre ${dateOnly(isoDay(bounds.min))} e ${dateOnly(isoDay(bounds.max))}.`};
    return {min:start,max:end};
  }
  const end=new Date(bounds.max),start=new Date(bounds.max);
  if(state.comparisonYears===.5)start.setUTCMonth(start.getUTCMonth()-6);
  else start.setUTCFullYear(start.getUTCFullYear()-Math.floor(state.comparisonYears));
  return {min:start,max:end};
}

function comparisonTimeTicks(minX,maxX) {
  const day=86400000,spanYears=(maxX-minX)/(365.25*day),ticks=[];
  if(spanYears<=5.1){
    const stepMonths=spanYears<=1.1?1:spanYears<=3.1?3:6;
    const start=new Date(minX),cursor=new Date(Date.UTC(start.getUTCFullYear(),start.getUTCMonth(),1));
    while(cursor.getTime()<minX)cursor.setUTCMonth(cursor.getUTCMonth()+stepMonths);
    while(cursor.getTime()<=maxX){
      const label=cursor.toLocaleDateString("pt-BR",{month:"short",year:"2-digit",timeZone:"UTC"}).replace(".","");
      ticks.push({value:cursor.getTime(),label});cursor.setUTCMonth(cursor.getUTCMonth()+stepMonths);
    }
  }else{
    const stepYears=spanYears>15?2:1,start=new Date(minX),cursor=new Date(Date.UTC(start.getUTCFullYear()+1,0,1));
    while(cursor.getTime()<=maxX){ticks.push({value:cursor.getTime(),label:String(cursor.getUTCFullYear())});cursor.setUTCFullYear(cursor.getUTCFullYear()+stepYears);}
  }
  if(!ticks.length){
    const start=new Date(minX),end=new Date(maxX),format=value=>value.toLocaleDateString("pt-BR",{month:"short",year:"2-digit",timeZone:"UTC"}).replace(".","");
    ticks.push({value:minX,label:format(start)});
    if(maxX-minX>7*day)ticks.push({value:maxX,label:format(end)});
  }
  return ticks;
}

function visibleComparisonSeries() {
  const window=comparisonWindow();
  if(!window||window.error)return [];
  let rows=(state.comparison?.series || []).filter(item=>state.comparisonSelected.includes(item.code)).map(item=>({...item,points:(item.points||[]).filter(point=>{const observed=new Date(`${point.date}T12:00:00Z`);return observed>=window.min&&observed<=window.max;})}));
  if(state.comparisonBaseMode==="common"){
    const starts=rows.filter(item=>item.points.length).map(item=>new Date(`${item.points[0].date}T12:00:00Z`).getTime());
    if(starts.length){const commonStart=Math.max(...starts);rows=rows.map(item=>({...item,points:item.points.filter(point=>new Date(`${point.date}T12:00:00Z`).getTime()>=commonStart)}));}
  }
  return rows.map(item=>{
    const points=item.points;
    if(!points.length)return {...item,points:[]};
    const base=Number(points[0].value)||100;
    return {...item,points:points.map(point=>({...point,value:Number(point.value)/base*100}))};
  });
}

function annualizedVolatility(points){
  if(!points||points.length<3)return null;const returns=[],spans=[];
  for(let index=1;index<points.length;index+=1){const before=Number(points[index-1].value),after=Number(points[index].value);if(before>0&&after>0)returns.push(after/before-1);spans.push(Math.max(1,(new Date(`${points[index].date}T12:00:00Z`)-new Date(`${points[index-1].date}T12:00:00Z`))/86400000));}
  if(returns.length<2)return null;const mean=returns.reduce((sum,value)=>sum+value,0)/returns.length,variance=returns.reduce((sum,value)=>sum+(value-mean)**2,0)/(returns.length-1);const sorted=[...spans].sort((a,b)=>a-b),median=sorted[Math.floor(sorted.length/2)]||1;return Math.sqrt(variance)*Math.sqrt(365/median)*100;
}

function renderComparison() {
  if(state.tabs.dashboard!=="comparison")return;
  const root=$("#dashboard-tab-content"), payload=state.comparison||{}, all=payload.series||[];
  if(!all.length){root.innerHTML=errorState("As séries históricas ainda estão sendo preparadas.");return;}
  const periods=[[.5,"6 meses"],[1,"1 ano"],[2,"2 anos"],[3,"3 anos"],[5,"5 anos"],[10,"10 anos"],[15,"15 anos"],[20,"20 anos"]];
  if(state.comparisonCustom)ensureComparisonCustomDates();
  const bounds=comparisonDateBounds(),minDate=bounds?isoDay(bounds.min):"",maxDate=bounds?isoDay(bounds.max):"";
  const customDates=state.comparisonCustom?`<div class="comparison-date-range"><div class="field"><label for="comparison-from">De</label><input id="comparison-from" type="date" data-comparison-date="from" value="${esc(state.comparisonCustomFrom)}" min="${minDate}" max="${maxDate}"></div><div class="field"><label for="comparison-to">Até</label><input id="comparison-to" type="date" data-comparison-date="to" value="${esc(state.comparisonCustomTo)}" min="${minDate}" max="${maxDate}"></div></div>`:"";
  const selectors=`<div class="comparison-controls"><div class="chart-periods">${periods.map(([years,label])=>`<button class="button ${!state.comparisonCustom&&state.comparisonYears===years?"primary":"secondary"}" data-comparison-years="${years}">${label}</button>`).join("")}<button class="button ${state.comparisonCustom?"primary":"secondary"}" data-comparison-custom="true">Personalizar</button></div>${customDates}<div class="comparison-refresh-row"><span class="chart-periods"><button class="button ${state.comparisonBaseMode==="common"?"primary":"secondary"}" data-comparison-base="common">Início comum</button><button class="button ${state.comparisonBaseMode==="own"?"primary":"secondary"}" data-comparison-base="own">Histórico próprio</button></span><button class="button secondary" data-comparison-refresh="true">Atualizar séries</button></div><div class="series-picker" role="group" aria-label="Indicadores para comparação">${all.map((item,index)=>`<label class="check" title="${esc(item.note||item.source||item.label)}"><input type="checkbox" data-comparison-series="${esc(item.code)}" ${state.comparisonSelected.includes(item.code)?"checked":""} ${item.points?.length?"":"disabled"}><i class="legend-dot" style="background:${comparisonColors[index%comparisonColors.length]}"></i><span>${esc(item.label)}${item.proxy?" <small>proxy</small>":""}</span></label>`).join("")}</div></div>`;
  const selectedWindow=comparisonWindow();
  if(selectedWindow?.error){root.innerHTML=sectionCard("Comparador histórico",selectors+`<div class="notice danger">${esc(selectedWindow.error)}</div>`);return;}
  const selected=visibleComparisonSeries().filter(item=>item.points.length);
  if(!selected.length){root.innerHTML=sectionCard("Comparador histórico",selectors+'<div class="empty-state"><strong>Selecione ao menos uma série disponível</strong>Os dados ausentes não impedem o uso das demais séries.</div>');return;}
  const width=1000,height=360,padX=48,padTop=25,padBottom=42,plotBottom=height-padBottom;
  const timestamps=selected.flatMap(item=>item.points.map(point=>new Date(`${point.date}T12:00:00Z`).getTime()));
  const values=selected.flatMap(item=>item.points.map(point=>Number(point.value))).filter(Number.isFinite);
  const minX=Math.min(...timestamps),maxX=Math.max(...timestamps),minY=Math.min(...values),maxY=Math.max(...values);
  const x=value=>padX+((value-minX)/Math.max(maxX-minX,1))*(width-padX*2);
  const y=value=>plotBottom-((value-minY)/Math.max(maxY-minY,.1))*(plotBottom-padTop);
  const paths=selected.map(item=>{
    const originalIndex=all.findIndex(row=>row.code===item.code),color=comparisonColors[originalIndex%comparisonColors.length];
    const d=item.points.map((point,index)=>`${index?"L":"M"}${x(new Date(`${point.date}T12:00:00Z`).getTime()).toFixed(1)},${y(Number(point.value)).toFixed(1)}`).join(" ");
    return `<path d="${d}" fill="none" stroke="${color}" stroke-width="2.6"/>`;
  }).join("");
  const grid=[0,.25,.5,.75,1].map(position=>{const value=maxY-(maxY-minY)*position,yy=padTop+(plotBottom-padTop)*position;return `<line x1="${padX}" x2="${width-padX}" y1="${yy}" y2="${yy}" stroke="#dfe6e2" stroke-dasharray="5 5"/><text x="${padX-7}" y="${yy+4}" text-anchor="end" font-size="11" fill="#67756f">${number(value,0)}</text>`;}).join("");
  const timeline=comparisonTimeTicks(minX,maxX).map(tick=>`<line x1="${x(tick.value)}" x2="${x(tick.value)}" y1="${padTop}" y2="${plotBottom}" stroke="#edf1ef"/><text x="${x(tick.value)}" y="${height-10}" text-anchor="middle" font-size="11" fill="#67756f">${esc(tick.label)}</text>`).join("");
  const svg=`<svg class="chart-svg comparison-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Comparação histórica rebaseada em 100">${grid}${timeline}<line x1="${padX}" x2="${width-padX}" y1="${plotBottom}" y2="${plotBottom}" stroke="#bfcac5"/>${paths}</svg>`;
  const legend=selected.map(item=>{const originalIndex=all.findIndex(row=>row.code===item.code),points=item.points,last=points[points.length-1],result=Number(last.value)-100;return `<span><i class="legend-dot" style="background:${comparisonColors[originalIndex%comparisonColors.length]}"></i>${esc(item.label)} <strong class="${variationClass(result)}">${pct(result,true)}</strong></span>`;}).join("");
  const unavailable=all.filter(item=>!item.points?.length).map(item=>item.label);
  const periodLabel=state.comparisonCustom?`de ${dateOnly(state.comparisonCustomFrom)} até ${dateOnly(state.comparisonCustomTo)}`:state.comparisonYears===.5?"6 meses":`${state.comparisonYears} ano(s)`;
  const metrics=marketTable(selected.map(item=>{const points=item.points,last=points[points.length-1];return {label:item.label,start:points[0]?.date,end:last?.date,return_pct:Number(last?.value)-100,volatility_pct:annualizedVolatility(points),observations:points.length};}),[{label:"Indicador",render:r=>`<strong>${esc(r.label)}</strong>`},{label:"Início efetivo",render:r=>dateOnly(r.start)},{label:"Fim",render:r=>dateOnly(r.end)},{label:"Retorno",render:r=>pct(r.return_pct,true),className:r=>variationClass(r.return_pct)},{label:"Volatilidade anual",render:r=>pct(r.volatility_pct)},{label:"Observações",render:r=>number(r.observations,0)}]);
  root.innerHTML=marketUpdatePanel(["comparison"])+sectionCard("Comparador histórico",`${selectors}<div class="chart comparison-chart-wrap">${svg}</div><div class="chart-legend">${legend}</div>${sectionCard("Retorno e risco no período",metrics,"Volatilidade anualizada conforme a frequência de cada série")}${unavailable.length?`<div class="notice">Sem dados nesta atualização: ${esc(unavailable.join(", "))}.</div>`:""}<div class="notice info">${esc(payload.note||"Base 100 no início do período selecionado.")} ${state.comparisonBaseMode==="common"?"Todas as linhas começam na primeira data disponível em comum.":"Cada linha usa seu próprio primeiro dado disponível."}</div>`,`Desempenho acumulado • base R$ 100 • ${periodLabel}`);
}

async function loadComparison(force=false,attempt=0,baselineGeneratedAt=null) {
  if(state.comparisonLoading&&attempt===0)return;
  if(attempt===0&&baselineGeneratedAt===null)baselineGeneratedAt=state.comparison?.generated_at||null;
  state.comparisonLoading=true;
  const root=$("#dashboard-tab-content");
  if(!state.comparison)root.innerHTML=`${loadingCards(6)}<div class="notice info" style="margin-top:14px">Preparando as séries históricas em segundo plano. Você pode continuar usando os outros painéis.</div>`;
  try{
    let payload=await api(force?"/market-dashboard/comparison/refresh":"/market-dashboard/comparison",{method:force?"POST":"GET",requestKey:"comparison"});
    if(payload.update){state.marketEnvelope=state.marketEnvelope||{};state.marketEnvelope.updates={...(state.marketEnvelope.updates||{}),comparison:payload.update};}
    const hasSnapshot=Boolean(payload.data?.series?.length);
    if(hasSnapshot){state.comparison=payload.data;renderComparison();}
    if((payload.refreshing||payload.scheduled)&&attempt<120){
      state.comparisonLoading=false;
      setTimeout(()=>loadComparison(false,attempt+1,baselineGeneratedAt),3000);
      return;
    }
    if(hasSnapshot){state.comparisonLoading=false;return;}
    if(state.comparison){renderComparison();state.comparisonLoading=false;return;}
    root.innerHTML=errorState(payload.error||"As séries históricas ainda não possuem uma atualização válida.");
  }catch(error){
    if(error.name!=="AbortError"){
      if(state.comparison)renderComparison();
      else root.innerHTML=errorState(error);
    }
  }
  state.comparisonLoading=false;
}

async function loadMarket(force = false) {
  if (!state.market) {
    $("#market-summary").innerHTML = loadingCards(4);
    $("#dashboard-tab-content").innerHTML = loadingCards(6);
  }
  try {
    const envelope = await api("/market-dashboard", {requestKey:"market-get"});
    state.marketEnvelope = envelope;
    if (envelope?.data && Object.keys(envelope.data).length) state.market = envelope.data;
    renderMarketSummary(); renderDashboardTab();
    const endpoint = force ? "/market-dashboard/refresh" : "/market-dashboard/ensure";
    const queued = await api(endpoint, {method:"POST",invalidateCache:false});
    if (queued.scheduled || ["queued","running"].includes(queued.refresh_status)) pollMarket();
    else if (queued.data && Object.keys(queued.data).length) { state.marketEnvelope=queued; state.market=queued.data; renderMarketSummary(); renderDashboardTab(); }
  } catch (error) {
    if (!state.market) $("#dashboard-tab-content").innerHTML = errorState(error, "market");
    toast(`Dados de mercado: ${error.message}`, "error");
  }
}

async function pollMarket(attempt = 0) {
  if (attempt > 35) return;
  await new Promise(resolve => setTimeout(resolve, 2500));
  try {
    const envelope = await api("/market-dashboard");
    if (envelope.data && Object.keys(envelope.data).length) { state.marketEnvelope=envelope; state.market=envelope.data; renderMarketSummary(); renderDashboardTab(); }
    if (["queued","running"].includes(envelope.refresh_status)) pollMarket(attempt+1);
    else if (envelope.refresh_status === "completed") toast("Painel de mercado atualizado.", "success");
  } catch (_) { /* keep stale data visible */ }
}

async function loadHeadlines() {
  const root = $("#dashboard-tab-content");
  root.innerHTML = loadingCards(5);
  try {
    let payload = await api("/market-dashboard/headlines", {requestKey:"headlines"});
    if (payload.data?.items?.length) renderHeadlines(payload);
    else if (payload.refreshing || payload.scheduled) {
      root.innerHTML = `${loadingCards(5)}<div class="notice info" style="margin-top:14px">Buscando as principais manchetes em segundo plano. O restante do site continua disponível.</div>`;
      setTimeout(async () => { try { payload=await api("/market-dashboard/headlines"); renderHeadlines(payload); } catch (_) {} }, 2500);
    } else renderHeadlines(payload);
  } catch (error) { root.innerHTML = errorState(error); }
}

function renderHeadlines(payload) {
  if (state.tabs.dashboard !== "headlines") return;
  const items = payload.data?.items || [];
  const list = items.length ? `<div class="headline-list"><div class="headline headline-header"><span>#</span><span>Manchete e fonte</span><span>Publicada em</span></div>${items.slice(0,10).map((item,index)=>`<a class="headline" href="${esc(item.url)}" target="_blank" rel="noopener"><span class="headline-number">${String(index+1).padStart(2,"0")}</span><span><strong>${esc(item.title)}</strong><small>${esc(item.source)}</small></span><small>${item.published_at ? dateTime(item.published_at) : "Horário não informado"}</small></a>`).join("")}</div>` : '<div class="empty-state"><strong>Nenhuma manchete disponível agora</strong>As fontes serão consultadas novamente em até uma hora.</div>';
  if(payload.update){state.marketEnvelope=state.marketEnvelope||{};state.marketEnvelope.updates={...(state.marketEnvelope.updates||{}),headlines:payload.update};}
  $("#dashboard-tab-content").innerHTML = marketUpdatePanel(["headlines"])+sectionCard("10 principais manchetes de economia", list, "Atualização automática a cada hora");
}

async function refreshMarketGroups(keys) {
  const groups=String(keys||"").split(",").map(value=>value.trim()).filter(Boolean);
  if(!groups.length)return;
  try {
    if(groups.some(group=>["catalog","fundamentals","technical_daily","technical_intraday"].includes(group)))state.analysisResultCache.clear();
    const results=await Promise.all(groups.map(group=>api(`/market-dashboard/groups/${encodeURIComponent(group)}/refresh`,{method:"POST"})));
    const scheduled=results.filter(result=>result.scheduled).length;
    toast(scheduled?"Atualização solicitada. Os dados atuais permanecerão visíveis.":"Esses dados foram solicitados há menos de 5 minutos.",scheduled?"success":"info");
    setTimeout(()=>loadCurrentView(),2500);
  } catch(error) { toast(error.message,"error"); }
}

const filterDefinitions = {
  fundamental: [
    ["price","Preço","Cotação mais recente disponível."],["pe","P/L","Preço dividido pelo lucro por ação."],["pbv","P/VP","Preço dividido pelo valor patrimonial por ação."],["dividend_yield_pct","Dividend yield (%)","Proventos dos últimos 12 meses em relação ao preço."],
    ["ev_ebitda","EV/EBITDA","Valor da firma em relação ao EBITDA."],["ebit_margin_pct","Margem EBIT (%)","EBIT dividido pela receita líquida."],["net_margin_pct","Margem líquida (%)","Lucro líquido dividido pela receita."],
    ["current_ratio","Liquidez corrente","Ativo circulante dividido pelo passivo circulante."],["roe_pct","ROE (%)","Lucro líquido em relação ao patrimônio líquido."],["roic_pct","ROIC (%)","Retorno operacional sobre o capital investido."],
    ["gross_debt_to_equity","Dívida bruta/patrimônio","Dívida bruta em relação ao patrimônio."],["net_debt_to_ebitda","Dívida líquida/EBITDA","Anos aproximados de EBITDA para cobrir a dívida líquida."],
    ["revenue_cagr_5y_pct","CAGR receita 5a (%)","Crescimento anual composto da receita em cinco anos."],["earnings_cagr_5y_pct","CAGR lucro 5a (%)","Crescimento anual composto do lucro em cinco anos."],
    ["daily_liquidity","Liquidez diária","Volume financeiro médio negociado por dia."],["ffo_yield_pct","FFO yield (%)","Geração operacional do FII em relação ao preço."],["cap_rate_pct","Cap rate (%)","Renda operacional dos imóveis em relação ao valor dos ativos."],
    ["vacancy_pct","Vacância física (%)","Percentual da área não ocupada."],["financial_vacancy_pct","Vacância financeira (%)","Percentual da receita potencial não recebida."],["ltv_pct","LTV (%)","Dívida do fundo em relação ao valor dos imóveis."],
  ],
  scores: [["quality_score","Qualidade","Rentabilidade, margens, dívida e liquidez corrente, com perfil por setor."],["value_score","Valor","Valuation, dividendos e potencial de Graham."],["growth_score","Crescimento","CAGR de receita e lucro em cinco anos."],["technical_score","Técnica","Médias de 20, 50 e 200 períodos, RSI 14, MACD e momentum de 3 meses."],["risk_score","Risco","Volatilidade, drawdown e alavancagem; quanto maior, melhor o controle de risco."],["liquidity_score","Liquidez","Escala da liquidez financeira diária."],["alb_score","Nota ALB","Média ponderada das notas, ajustada ao perfil setorial."],["data_quality_score","Qualidade dos dados","Cobertura, validade e atualidade dos dados usados no cálculo."]],
};

function helpMark(text) { return text ? `<button type="button" class="help-mark" title="${esc(text)}" aria-label="${esc(text)}">?</button>` : ""; }

function numericRange(key, label, kind="filter", help="") {
  const attr = kind === "score" ? "data-score-field" : kind === "technical" ? "data-technical-field" : "data-filter-field";
  return `<div class="field" ${attr}="${key}"><label>${esc(label)} ${helpMark(help)}</label><div class="range-pair"><input type="number" step="any" data-bound="min" placeholder="Mín."><input type="number" step="any" data-bound="max" placeholder="Máx."></div></div>`;
}

function renderFilterInputs() {
  $("#fundamental-filters").innerHTML = `
    <div class="field"><label>Máximo de ativos: <strong id="analysis-limit-label">${state.analysisLimit}</strong></label><input id="analysis-limit" type="range" min="5" max="100" step="5" value="${state.analysisLimit}"></div>
    <div class="field stock-only-filter"><label>Participação no IBOV</label><select id="ibov-membership"><option value="any">Qualquer</option><option value="inside">Somente no IBOV</option><option value="outside">Fora do IBOV</option></select></div>
    <div class="field stock-only-filter"><label>Porte da empresa</label><select id="company-sizes" multiple size="3"><option value="large">Blue Chip / Large Cap</option><option value="mid">Mid Cap</option><option value="small">Small Cap</option></select></div>
    <div class="field wide-action valuation-filter"><label>Metodologias de valor ${helpMark("Combine até quatro famílias. Um método sem dados suficientes reprova o critério ativo, sem estimativas artificiais.")}</label>
      <div class="valuation-choice-grid">
        <label class="check" data-valuation-types="stock"><input id="below-graham" type="checkbox"><span><span data-valuation-label>Número de Graham</span><small data-valuation-status></small></span></label>
        <label class="check" data-valuation-types="stock,fii"><input id="below-barsi" type="checkbox"><span><span data-valuation-label>Preço-teto por dividend yield-alvo (6%, últimos 12 meses)</span><small data-valuation-status></small></span></label>
        <label class="check" data-valuation-types="stock,fii,etf,bdr"><input id="below-relative" type="checkbox"><span><span data-valuation-label>Valuation relativo por pares comparáveis</span><small data-valuation-status></small></span></label>
        <label class="check" data-valuation-types="stock,etf,bdr,future"><input id="below-economic" type="checkbox"><span><span data-valuation-label>Valor econômico (Gordon com cenários explícitos)</span><small data-valuation-status></small></span></label>
      </div>
      <div class="filter-grid compact-grid valuation-controls">
        <div class="field"><label>Combinação</label><select id="valuation-logic"><option value="all">Todos os métodos selecionados</option><option value="any">Ao menos um método</option></select></div>
        <div class="field"><label>Potencial mínimo (%) ${helpMark("É a valorização mínima exigida entre a referência calculada e o preço atual: 100 × (valor de referência ÷ preço atual − 1). Exemplo: 20 exige potencial de pelo menos 20%. Deixe vazio para exigir apenas que o preço esteja abaixo da referência. Em Todos, cada método selecionado precisa atingir o mínimo; em Qualquer, basta um.")}</label><input id="valuation-min-upside" type="number" min="0" max="10000" step="0.1" placeholder="Opcional — ex.: 20"><small>Valorização mínima sobre o preço atual; vazio = somente abaixo da referência.</small></div>
      </div>
      <details id="economic-assumptions" class="filter-subgroup" open><summary>Cenários do valor econômico: Conservador, Base e Otimista</summary>
        <div class="notice info">O modelo não usa crescimento ou retorno ocultos. Para usar os proventos dos últimos 12 meses, marque a confirmação abaixo; eles podem não representar um dividendo sustentável.</div>
        <label class="check"><input id="economic-use-ttm" type="checkbox"> Usar provento dos últimos 12 meses como D0 não normalizado</label>
        <div class="filter-grid compact-grid">
          <div class="field"><label>Conservador: retorno (%)</label><input id="economic-conservative-return" type="number" min="0.1" max="100" step="0.1" value="16"></div>
          <div class="field"><label>Conservador: crescimento (%)</label><input id="economic-conservative-growth" type="number" min="0" max="99" step="0.1" value="1"></div>
          <div class="field"><label>Base: retorno (%)</label><input id="economic-base-return" type="number" min="0.1" max="100" step="0.1" value="13"></div>
          <div class="field"><label>Base: crescimento (%)</label><input id="economic-base-growth" type="number" min="0" max="99" step="0.1" value="3"></div>
          <div class="field"><label>Otimista: retorno (%)</label><input id="economic-optimistic-return" type="number" min="0.1" max="100" step="0.1" value="11"></div>
          <div class="field"><label>Otimista: crescimento (%)</label><input id="economic-optimistic-growth" type="number" min="0" max="99" step="0.1" value="4"></div>
          <div class="field"><label>Margem de segurança (%)</label><input id="economic-margin" type="number" min="0" max="99" step="0.1" value="20"></div>
        </div>
      </details>
      <div id="class-valuation-note" class="notice info hidden"></div>
      <small id="valuation-permission-note"></small>
    </div>
    <details class="filter-subgroup" open><summary>Indicadores fundamentalistas</summary><div class="filter-grid">${filterDefinitions.fundamental.map(([key,label,help])=>numericRange(key,label,"filter",help)).join("")}</div></details>
    <details class="filter-subgroup"><summary>Notas e qualidade</summary><div class="filter-grid">${filterDefinitions.scores.map(([key,label,help])=>numericRange(key,label,"score",help)).join("")}</div></details>`;
  $("#technical-filters").innerHTML = `
    ${numericRange("rsi14","RSI 14","technical","Força relativa calculada em 14 pregões pelo suavizamento de Wilder.")}
    <div class="field"><label>Média da tendência ${helpMark("Compara o preço atual à média simples de 20 ou 21 períodos, nos gráficos diário, semanal e mensal.")}</label><select id="trend-period"><option value="21">21 períodos</option><option value="20">20 períodos</option></select></div>
    <div class="field"><label>Tendência diária ${helpMark("Preço atual acima ou abaixo da média escolhida no gráfico diário.")}</label><select id="trend-daily"><option value="any">Qualquer</option><option value="up">Alta</option><option value="down">Baixa</option></select></div>
    <div class="field"><label>Tendência semanal ${helpMark("Preço atual acima ou abaixo da média escolhida em semanas concluídas.")}</label><select id="trend-weekly"><option value="any">Qualquer</option><option value="up">Alta</option><option value="down">Baixa</option></select></div>
    <div class="field"><label>Tendência mensal ${helpMark("Preço atual acima ou abaixo da média escolhida em meses concluídos.")}</label><select id="trend-monthly"><option value="any">Qualquer</option><option value="up">Alta</option><option value="down">Baixa</option></select></div>
    <div class="field"><label>Período dos pivôs</label><select id="pivot-timeframe"><option value="daily">Diário</option><option value="weekly">Semanal</option><option value="monthly">Mensal</option></select></div>
    <div class="field"><label>Zona entre pivôs</label><select id="pivot-zone"><option value="any">Qualquer</option><option value="below_s3">Abaixo de S3</option><option value="s3_s2">S3–S2</option><option value="s2_s1">S2–S1</option><option value="s1_pp">S1–Pivô</option><option value="pp_r1">Pivô–R1</option><option value="r1_r2">R1–R2</option><option value="r2_r3">R2–R3</option><option value="above_r3">Acima de R3</option></select></div>
    <div class="field"><label>Próximo de</label><select id="near-pivot"><option value="none">Sem filtro</option><option value="s3">Suporte 3</option><option value="s2">Suporte 2</option><option value="s1">Suporte 1</option><option value="pp">Pivô</option><option value="r1">Resistência 1</option><option value="r2">Resistência 2</option><option value="r3">Resistência 3</option></select></div>
    <div class="field"><label>Tolerância ao pivô (%)</label><input id="pivot-tolerance" type="number" min="0" max="20" step="0.1" value="0.5"></div>
    <div class="field"><label>Volume acima da média de 9 ${helpMark("O volume atual precisa superar a média simples dos nove períodos concluídos anteriores.")}</label><label class="check"><input id="volume-daily-ma9" type="checkbox"> Diário</label><label class="check"><input id="volume-monthly-ma9" type="checkbox"> Mensal</label></div>
    <button id="apply-advanced-filters" class="button primary wide-action">Aplicar ajustes</button>`;
  updateFilterAvailability();
}

function updateFilterAvailability() {
  $$(".stock-only-filter").forEach(node=>node.classList.toggle("hidden",analysisType()!=="stock"));
  const type=analysisType(),supportsFundamentals=["stock","fii"].includes(type),supportsTechnical=["stock","fii","etf","bdr","future"].includes(type);
  const access=state.session?.access||{},alb=Boolean(access.can_use_alb_analysis);
  $$('[data-filter-field] input,[data-score-field] input').forEach(node=>node.disabled=!supportsFundamentals);
  $$("#technical-filters input,#technical-filters select").forEach(node=>node.disabled=!supportsTechnical);
  if($("#analysis-limit"))$("#analysis-limit").disabled=false;
  const permissions={"below-graham":alb||access.can_use_graham_valuation,"below-barsi":alb||access.can_use_dividend_ceiling,"below-relative":alb||access.can_use_relative_valuation,"below-economic":alb||access.can_use_economic_valuation};
  const valuationLabels={
    stock:{"below-graham":"Número de Graham","below-barsi":"Preço-teto por dividend yield-alvo (6%, últimos 12 meses)","below-relative":"Valuation relativo por pares comparáveis","below-economic":"Valor econômico (Gordon com cenários explícitos)"},
    fii:{"below-graham":"Número de Graham","below-barsi":"Preço-teto por dividend yield-alvo (6%, últimos 12 meses)","below-relative":"Valuation relativo por FIIs comparáveis","below-economic":"Valor econômico por classe"},
    etf:{"below-graham":"Número de Graham","below-barsi":"Preço-teto por dividend yield-alvo","below-relative":"Prêmio/desconto relativo ao NAV dos ETFs pares","below-economic":"Referência patrimonial do ETF (NAV)"},
    bdr:{"below-graham":"Número de Graham no ativo-lastro","below-barsi":"Preço-teto de proventos do ativo-lastro","below-relative":"Valuation relativo P/VP entre BDRs comparáveis","below-economic":"Paridade do BDR com o ativo-lastro"},
    future:{"below-graham":"Número de Graham","below-barsi":"Preço-teto por dividendos","below-relative":"Valuation relativo por pares","below-economic":"Preço teórico por custo de carregamento"},
  };
  const classNotes={
    etf:"ETFs: o valor patrimonial recupera o NAV por cota a partir do prêmio/desconto informado; o relativo compara esse prêmio apenas com ETFs na mesma moeda.",
    bdr:"BDRs: o relativo usa P/VP de BDRs do mesmo setor ou indústria. A paridade econômica só é calculada quando preço do lastro, câmbio e razão do programa estiverem verificados.",
    future:"Futuros: o preço teórico usa o contrato frontal, seu vencimento, o ativo à vista e a taxa de carregamento. Contratos sem lastro identificado continuam N/D.",
  };
  Object.entries(permissions).forEach(([id,allowed])=>{
    const input=$(`#${id}`),holder=input?.closest("[data-valuation-types]");
    const applicable=Boolean(holder?.dataset.valuationTypes.split(",").includes(type));
    if(input)input.disabled=!allowed||!applicable;
    if(holder){
      const label=holder.querySelector("[data-valuation-label]");if(label)label.textContent=valuationLabels[type]?.[id]||label.textContent;
      const unavailable=!applicable, reason=unavailable?"N/D: esta metodologia não representa corretamente esta classe.":!allowed?"Disponível mediante autorização individual.":"Disponível para esta conta; cada ativo ainda precisa ter os insumos necessários.";
      holder.classList.toggle("unavailable",unavailable||!allowed);
      holder.title=reason;
      const status=holder.querySelector("[data-valuation-status]");if(status)status.textContent=reason;
    }
  });
  const canEconomic=Boolean(permissions["below-economic"]&&type==="stock");
  $$("#economic-assumptions input").forEach(node=>node.disabled=!canEconomic);
  if($("#economic-assumptions"))$("#economic-assumptions").classList.toggle("hidden",type!=="stock");
  if($("#class-valuation-note")){const note=classNotes[type]||"";$("#class-valuation-note").textContent=note;$("#class-valuation-note").classList.toggle("hidden",!note);}
  if($("#valuation-logic"))$("#valuation-logic").disabled=false;
  if($("#valuation-min-upside"))$("#valuation-min-upside").disabled=false;
  if($("#valuation-permission-note"))$("#valuation-permission-note").textContent="Cada metodologia exige autorização própria; ALB libera as quatro. Métodos sem dados suficientes aparecem como N/D e nunca aprovam artificialmente um ativo.";
  if($("#apply-advanced-filters")) $("#apply-advanced-filters").disabled=!supportsTechnical;
  $$("#analysis-preset-row [data-preset-id]").forEach(node=>{
    const permission=node.dataset.presetId==="cnpi"?"can_use_fdi_analysis":node.dataset.presetId==="alb"?"can_use_alb_analysis":null;
    node.disabled=!supportsTechnical||Boolean(permission&&!access[permission]);
    node.title=node.disabled&&permission?"Análise disponível mediante autorização do administrador.":!supportsFundamentals&&permission?"Versão técnica desta análise para a classe selecionada.":"";
  });
  if($("#analysis-filter-notice")) {
    $("#analysis-filter-notice").textContent=!supportsFundamentals?"Padrão, FDI e ALB usam critérios técnicos próprios nesta classe. As metodologias compatíveis agora usam dados específicos do ativo; cada linha continua N/D quando seu insumo não estiver disponível.":"Filtros fundamentalistas e técnicos estão ativos. As metodologias de valor respeitam autorizações e aplicabilidade.";
  }
}

function resetAdvancedFilters() {
  $$('[data-filter-field] input,[data-score-field] input,[data-technical-field] input').forEach(input=>input.value="");
  ["trend-daily","trend-weekly","trend-monthly"].forEach(id=>{if($(`#${id}`))$(`#${id}`).value="any";});
  if($("#pivot-zone")) $("#pivot-zone").value="any";
  if($("#near-pivot")) $("#near-pivot").value="none";
  if($("#trend-period")) $("#trend-period").value="21";
  if($("#pivot-timeframe")) $("#pivot-timeframe").value="daily";
  if($("#pivot-tolerance")) $("#pivot-tolerance").value="0.5";
  ["below-graham","below-barsi","below-relative","below-economic","economic-use-ttm","volume-daily-ma9","volume-monthly-ma9"].forEach(id=>{if($(`#${id}`))$(`#${id}`).checked=false;});
  if($("#valuation-logic"))$("#valuation-logic").value="all";
  if($("#valuation-min-upside"))$("#valuation-min-upside").value="";
  const economicDefaults={"economic-conservative-return":16,"economic-conservative-growth":1,"economic-base-return":13,"economic-base-growth":3,"economic-optimistic-return":11,"economic-optimistic-growth":4,"economic-margin":20};
  Object.entries(economicDefaults).forEach(([id,value])=>{if($(`#${id}`))$(`#${id}`).value=String(value);});
  if($("#ibov-membership")) $("#ibov-membership").value="any";
  if($("#company-sizes")) [...$("#company-sizes").options].forEach(option=>option.selected=false);
}

function analysisType() {
  return ({stocks:"stock",fiis:"fii",etfs:"etf",bdrs:"bdr",futures:"future"})[state.tabs.analysis];
}

function normalizedConfiguration(saved) {
  const filters=saved?.filters||saved||{};
  if(filters.schema_version===2)return filters.configuration||{};
  if(filters.fundamental_filters)return filters;
  const fundamental_filters={};
  const mapping={roe_min:["roe_pct","min"],net_margin_min:["net_margin_pct","min"],ebit_margin_min:["ebit_margin_pct","min"],revenue_cagr_5y_min:["revenue_cagr_5y_pct","min"],pe_min:["pe","min"],pe_max:["pe","max"],pbv_max:["pbv","max"],dividend_yield_min:["dividend_yield_pct","min"],ev_ebitda_max:["ev_ebitda","max"],gross_debt_to_equity_max:["gross_debt_to_equity","max"],current_ratio_min:["current_ratio","min"],daily_liquidity_min:["daily_liquidity","min"],ffo_yield_min:["ffo_yield_pct","min"],cap_rate_min:["cap_rate_pct","min"],vacancy_max:["vacancy_pct","max"]};
  Object.entries(mapping).forEach(([oldKey,[field,bound]])=>{if(!nullable(filters[oldKey])){fundamental_filters[field]??={min:null,max:null};fundamental_filters[field][bound]=filters[oldKey];}});
  return {asset_type:saved?.asset_type||analysisType(),fundamental_filters,score_filters:{},valuation_flags:{below_graham:Boolean(filters.require_below_graham),below_barsi_6pct:Boolean(filters.require_below_dividend_target)},technical_filters:{},trend_period:21,pivot_timeframe:"daily",include_technical_columns:true,limit:50,company_sizes:[],ibov_membership:"any"};
}

function setRangeValue(selector, range) {
  const group=$(selector); if(!group)return;
  group.querySelector('[data-bound="min"]').value=range?.min??"";
  group.querySelector('[data-bound="max"]').value=range?.max??"";
}

function fillAnalysisForm(configuration={}) {
  resetAdvancedFilters();
  Object.entries(configuration.fundamental_filters||{}).forEach(([key,value])=>setRangeValue(`[data-filter-field="${key}"]`,value));
  Object.entries(configuration.score_filters||{}).forEach(([key,value])=>setRangeValue(`[data-score-field="${key}"]`,value));
  const technical=configuration.technical_filters||{};
  setRangeValue('[data-technical-field="rsi14"]',technical.rsi14);
  if($("#trend-daily")) $("#trend-daily").value=technical.daily_trend||"any";
  if($("#trend-weekly")) $("#trend-weekly").value=technical.weekly_trend||"any";
  if($("#trend-monthly")) $("#trend-monthly").value=technical.monthly_trend||"any";
  if($("#trend-period")) $("#trend-period").value=String(configuration.trend_period||21);
  if($("#pivot-timeframe")) $("#pivot-timeframe").value=configuration.pivot_timeframe||"daily";
  if($("#pivot-zone")) $("#pivot-zone").value=technical.pivot_zone||"any";
  if($("#near-pivot")) $("#near-pivot").value=technical.near_pivot_level||"none";
  if($("#pivot-tolerance")) $("#pivot-tolerance").value=technical.pivot_tolerance_pct??0.5;
  if($("#volume-daily-ma9")) $("#volume-daily-ma9").checked=Boolean(technical.volume_daily_above_ma9);
  if($("#volume-monthly-ma9")) $("#volume-monthly-ma9").checked=Boolean(technical.volume_monthly_above_ma9);
  if($("#below-graham")) $("#below-graham").checked=Boolean(configuration.valuation_flags?.below_graham);
  if($("#below-barsi")) $("#below-barsi").checked=Boolean(configuration.valuation_flags?.below_barsi_6pct);
  if($("#below-relative")) $("#below-relative").checked=Boolean(configuration.valuation_flags?.below_relative_value||configuration.valuation_flags?.below_relative_peers);
  if($("#below-economic")) $("#below-economic").checked=Boolean(configuration.valuation_flags?.below_economic_value||configuration.valuation_flags?.below_gordon_ddm);
  if($("#valuation-logic")) $("#valuation-logic").value=configuration.valuation_flags?.logic||configuration.valuation_flags?.valuation_logic||"all";
  if($("#valuation-min-upside")) $("#valuation-min-upside").value=configuration.valuation_flags?.minimum_upside_pct??"";
  const economic=configuration.valuation_assumptions?.economic_value||configuration.valuation_assumptions?.gordon_growth_ddm||{};
  if($("#economic-use-ttm"))$("#economic-use-ttm").checked=Boolean(economic.use_ttm_dividend);
  [["conservative","economic-conservative"],["base","economic-base"],["optimistic","economic-optimistic"]].forEach(([name,id])=>{const scenario=economic.scenarios?.[name]||economic[name];if(scenario){$(`#${id}-return`).value=scenario.required_return_pct;$(`#${id}-growth`).value=scenario.growth_pct;}});
  if($("#economic-margin")&&!nullable(economic.margin_of_safety_pct))$("#economic-margin").value=economic.margin_of_safety_pct;
  if($("#ibov-membership")) $("#ibov-membership").value=configuration.ibov_membership||"any";
  if($("#company-sizes")) [...$("#company-sizes").options].forEach(option=>option.selected=(configuration.company_sizes||[]).includes(option.value));
  state.analysisLimit=Number(configuration.limit||50);
  if($("#analysis-limit")) $("#analysis-limit").value=String(state.analysisLimit);
  if($("#analysis-limit-label")) $("#analysis-limit-label").textContent=state.analysisLimit;
}

function analysisRequestFromForm() {
  const fundamental_filters={};
  $$("[data-filter-field]").forEach(group=>{
    const min=group.querySelector('[data-bound="min"]').value,max=group.querySelector('[data-bound="max"]').value;
    if(min!==""||max!=="")fundamental_filters[group.dataset.filterField]={min:min===""?null:Number(min),max:max===""?null:Number(max)};
  });
  const score_filters={};
  $$('[data-score-field]').forEach(group=>{
    const min=group.querySelector('[data-bound="min"]').value,max=group.querySelector('[data-bound="max"]').value;
    if(min!==""||max!=="")score_filters[group.dataset.scoreField]={min:min===""?null:Number(min),max:max===""?null:Number(max)};
  });
  const rsiGroup=$("[data-technical-field='rsi14']"),rsiMin=rsiGroup?.querySelector('[data-bound="min"]').value,rsiMax=rsiGroup?.querySelector('[data-bound="max"]').value;
  const technical_filters={daily_trend:$("#trend-daily")?.value||"any",weekly_trend:$("#trend-weekly")?.value||"any",monthly_trend:$("#trend-monthly")?.value||"any",pivot_zone:$("#pivot-zone")?.value||"any",near_pivot_level:$("#near-pivot")?.value||"none",pivot_tolerance_pct:Number($("#pivot-tolerance")?.value||.5),volume_daily_above_ma9:Boolean($("#volume-daily-ma9")?.checked),volume_monthly_above_ma9:Boolean($("#volume-monthly-ma9")?.checked)};
  if(rsiMin!==""||rsiMax!=="")technical_filters.rsi14={min:rsiMin===""?null:Number(rsiMin),max:rsiMax===""?null:Number(rsiMax)};
  state.analysisLimit=Number($("#analysis-limit")?.value||50);
  const valuation_flags={below_graham:Boolean($("#below-graham")?.checked),below_barsi_6pct:Boolean($("#below-barsi")?.checked),below_relative_value:Boolean($("#below-relative")?.checked),below_economic_value:Boolean($("#below-economic")?.checked),logic:$("#valuation-logic")?.value||"all"};
  if($("#valuation-min-upside")?.value!=="")valuation_flags.minimum_upside_pct=Number($("#valuation-min-upside").value);
  const valuation_assumptions={relative_peers:{minimum_peers:5,winsor_limits:[0.10,0.90]}};
  if(valuation_flags.below_economic_value&&analysisType()==="stock")valuation_assumptions.economic_value={use_ttm_dividend:Boolean($("#economic-use-ttm")?.checked),margin_of_safety_pct:Number($("#economic-margin")?.value||20),scenarios:{conservative:{required_return_pct:Number($("#economic-conservative-return")?.value),growth_pct:Number($("#economic-conservative-growth")?.value)},base:{required_return_pct:Number($("#economic-base-return")?.value),growth_pct:Number($("#economic-base-growth")?.value)},optimistic:{required_return_pct:Number($("#economic-optimistic-return")?.value),growth_pct:Number($("#economic-optimistic-growth")?.value)}}};
  return {asset_type:analysisType(),fundamental_filters,score_filters,valuation_flags,valuation_assumptions,technical_filters,trend_period:Number($("#trend-period")?.value||21),pivot_timeframe:$("#pivot-timeframe")?.value||"daily",include_technical_columns:true,limit:state.analysisLimit,company_sizes:$("#company-sizes")?[...$("#company-sizes").selectedOptions].map(option=>option.value):[],ibov_membership:$("#ibov-membership")?.value||"any"};
}

function validateAnalysisRequest(request) {
  const flags=request.valuation_flags||{};
  const selected=["below_graham","below_barsi_6pct","below_relative_value","below_economic_value"].filter(key=>flags[key]);
  if(!nullable(flags.minimum_upside_pct)&&!selected.length)throw new Error("Selecione ao menos uma metodologia antes de exigir um potencial mínimo.");
  if(!nullable(flags.minimum_upside_pct)&&Number(flags.minimum_upside_pct)<0)throw new Error("O potencial mínimo deve ser zero ou positivo.");
  if(!flags.below_economic_value||request.asset_type!=="stock")return;
  const economic=request.valuation_assumptions?.economic_value||{};
  if(!economic.use_ttm_dividend)throw new Error("Para usar o valor econômico nesta tela, confirme o uso do provento dos últimos 12 meses como D0.");
  for(const [name,label] of [["conservative","Conservador"],["base","Base"],["optimistic","Otimista"]]){
    const scenario=economic.scenarios?.[name]||{},required=Number(scenario.required_return_pct),growth=Number(scenario.growth_pct);
    if(!Number.isFinite(required)||!Number.isFinite(growth)||required<=growth)throw new Error(`No cenário ${label}, o retorno exigido precisa ser maior que o crescimento.`);
  }
}

function revealSelectedValuationColumns(request) {
  const type=analysisType(),columns=analysisColumns(type),active=new Set(visibleAnalysisColumns(type,columns).map(column=>column.id));
  const economicColumns={stock:["economic","economic_upside"],etf:["nav","nav_upside"],bdr:["parity","parity_upside"],future:["carry","basis"]}[type]||[];
  const map={below_graham:["graham","graham_upside"],below_barsi_6pct:["barsi","barsi_upside"],below_relative_value:["relative","relative_upside"],below_economic_value:economicColumns};
  Object.entries(map).forEach(([flag,ids])=>{if(request.valuation_flags?.[flag])ids.forEach(id=>active.add(id));});
  state.visibleColumns[type]=columns.filter(column=>column.always||active.has(column.id)).map(column=>column.id);
  localStorage.setItem("fdi-visible-columns",JSON.stringify(state.visibleColumns));
}

function renderCustomPresetButtons() {
  const root=$("#custom-preset-buttons"); if(!root)return;
  root.innerHTML=state.analysisCustom.map(item=>`<button class="preset-button" data-custom-filter-id="${esc(item.id)}">${esc(item.name)}</button>`).join("");
  const access=state.session?.access||{},allowed=Number(access.custom_filter_limit||0)>0&&["stock","fii","etf","bdr","future"].includes(analysisType());
  $("#custom-filter-controls").classList.toggle("hidden",!allowed);
  $("#custom-filter-usage").textContent=allowed?`${state.analysisCustomUsage.used} de ${state.analysisCustomUsage.limit} análise(s) personalizada(s) utilizada(s).`:"";
  updateCustomFilterControls();
}

function updateCustomFilterControls() {
  const current=state.currentCustomFilter;
  if(!$("#save-custom-filter"))return;
  $("#save-custom-filter").textContent=current?"Salvar alterações da análise personalizada":"Gravar análise personalizada";
  $("#delete-custom-filter").classList.toggle("hidden",!current);
  if(current&&$("#custom-filter-name"))$("#custom-filter-name").value=current.name||"";
}

async function loadAnalysisCatalog(type, force=false) {
  if(force||!state.analysisCatalog[type]){
    const presetPayload=await api(`/screen/presets?asset_type=${type}`,{cacheTtlMs:300000,bypassCache:force});
    state.analysisCatalog[type]=Object.fromEntries((presetPayload.items||[]).map(item=>[item.id,item]));
  }
  if(Number(state.session?.access?.custom_filter_limit||0)>0&&(force||!state.analysisCustomCache[type])) {
    try {
      const custom=await api(`/screen/custom-filters?asset_type=${type}`,{cacheTtlMs:60000,bypassCache:force});
      state.analysisCustomCache[type]=custom.items||[];state.analysisCustomUsageCache[type]={used:custom.used||0,limit:custom.limit||0};
    } catch(_){state.analysisCustomCache[type]=[];}
  }
  state.analysisCustom=state.analysisCustomCache[type]||[];
  state.analysisCustomUsage=state.analysisCustomUsageCache[type]||{used:0,limit:Number(state.session?.access?.custom_filter_limit||0)};
  renderCustomPresetButtons();
}

function markActiveAnalysis({presetId=null,custom=null}={}) {
  state.currentCustomFilter=custom;
  if(presetId)state.analysisPreset=presetId;
  $$("#analysis-preset-row .preset-button").forEach(button=>button.classList.toggle("active",presetId?button.dataset.presetId===presetId:button.dataset.customFilterId===custom?.id));
  const label=custom?.name||state.analysisCatalog[analysisType()]?.[presetId]?.name||"Ajustes livres";
  $("#active-analysis-summary").textContent=`${label} • ${custom?"análise personalizada":"critérios originais do sistema"}`;
  if($("#custom-filter-name"))$("#custom-filter-name").value=custom?.name||"";
  updateCustomFilterControls();
}

async function selectSystemPreset(presetId) {
  const item=state.analysisCatalog[analysisType()]?.[presetId]; if(!item)return;
  fillAnalysisForm(item.configuration);markActiveAnalysis({presetId});await loadAnalysisResults();
}

async function selectCustomFilter(filterId) {
  const item=state.analysisCustom.find(row=>row.id===filterId);if(!item)return;
  fillAnalysisForm(normalizedConfiguration(item));markActiveAnalysis({custom:item});await applyAdvancedFilters(false);
}

async function saveCustomFilter() {
  const current=state.currentCustomFilter,name=$("#custom-filter-name").value.trim();
  if(!name){toast("Informe um nome para a análise personalizada.","error");$("#custom-filter-name").focus();return;}
  const method=current?"PUT":"POST",path=current?`/screen/custom-filters/${current.id}`:"/screen/custom-filters";
  const filters=analysisRequestFromForm();try{validateAnalysisRequest(filters);}catch(error){toast(error.message,"error");return;}
  const body=current?{name,filters}:{asset_type:analysisType(),name,filters};
  try {const saved=await api(path,{method,body:JSON.stringify(body)});await loadAnalysisCatalog(analysisType(),true);state.currentCustomFilter=state.analysisCustom.find(item=>item.id===saved.id)||saved;markActiveAnalysis({custom:state.currentCustomFilter});toast(current?"Alterações salvas.":"Análise personalizada gravada.","success");}
  catch(error){toast(error.message,"error");}
}

async function deleteCustomFilter() {
  const current=state.currentCustomFilter;if(!current)return;
  if(!confirm(`Excluir a análise personalizada "${current.name}"?`))return;
  try {await api(`/screen/custom-filters/${current.id}`,{method:"DELETE"});state.currentCustomFilter=null;await loadAnalysisCatalog(analysisType(),true);await selectSystemPreset("default");toast("Análise excluída.","success");}
  catch(error){toast(error.message,"error");}
}

async function loadAnalysis() {
  if(state.tabs.analysisMode==="guide"){renderIndicatorGuide();return;}
  $("#analysis-list-workspace").classList.remove("hidden");$("#analysis-guide").classList.add("hidden");
  const type=analysisType();
  const now=Date.now();
  if(now-state.analysisUpdateCheckedAt>60000){
    state.analysisUpdateCheckedAt=now;
    api("/market-dashboard/updates",{cacheTtlMs:60000}).then(updatePayload=>{
      state.marketEnvelope=state.marketEnvelope||{};state.marketEnvelope.updates={...(state.marketEnvelope.updates||{}),...(updatePayload.updates||{})};
      if(state.view==="analysis"&&$("#analysis-update-status"))$("#analysis-update-status").innerHTML=marketUpdatePanel(["fundamentals","technical_daily","technical_intraday"],"Atualizações dos dados de análise");
    }).catch(()=>{if(state.view==="analysis"&&$("#analysis-update-status"))$("#analysis-update-status").innerHTML='<div class="notice warning">O estado das atualizações não pôde ser consultado agora. Os dados disponíveis continuam acessíveis.</div>';});
  } else if($("#analysis-update-status")) {
    $("#analysis-update-status").innerHTML=marketUpdatePanel(["fundamentals","technical_daily","technical_intraday"],"Atualizações dos dados de análise");
  }
  try {
    await loadAnalysisCatalog(type);
    if(state.view!=="analysis"||type!==analysisType())return;
    if(state.analysisLoadedType!==type){state.analysisLoadedType=type;state.currentCustomFilter=null;state.analysisPreset="default";fillAnalysisForm(state.analysisCatalog[type]?.default?.configuration||{});markActiveAnalysis({presetId:"default"});}
  } catch(error){toast(`Configuração dos filtros: ${error.message}`,"error");}
  updateFilterAvailability();
  await loadAnalysisResults();
  if(now-state.analysisEnsureSentAt>300000){
    state.analysisEnsureSentAt=now;
    setTimeout(()=>Promise.all(["catalog","fundamentals","technical_daily","technical_intraday"].map(group=>api(`/market-dashboard/groups/${group}/ensure`,{method:"POST",invalidateCache:false}))).catch(()=>{}),1500);
  }
}

function analysisResultCacheKey(type) {
  return [type,state.currentCustomFilter?.id||"system",state.analysisPreset,state.analysisLimit].join("|");
}

async function loadAnalysisResults(force=false) {
  const root = $("#analysis-table");
  const type = analysisType();
  const requestSerial=++state.analysisRequestSerial;
  const cacheKey=analysisResultCacheKey(type),cached=state.analysisResultCache.get(cacheKey);
  if(!force&&cached&&Date.now()-cached.savedAt<ANALYSIS_CACHE_TTL_MS){state.analysisRows=cached.rows;renderAnalysisRows(cached.rows);return;}
  if(cached?.rows?.length){state.analysisRows=cached.rows;renderAnalysisRows(cached.rows);root.insertAdjacentHTML("afterbegin",'<div class="notice info analysis-refreshing">Atualizando a lista em segundo plano…</div>');}
  else root.innerHTML = loadingCards(6);
  try {
    let rows, warnings=[];
    if (state.currentCustomFilter) {
      const payload=await api(`/screen/db/custom/${state.currentCustomFilter.id}?limit=${state.analysisLimit}`,{requestKey:"analysis"});rows=payload.rows||payload;warnings=payload?.meta?.warnings||[];
    } else if (type === "stock") rows = await api(`/screen/db/stocks/${state.analysisPreset}?limit=${state.analysisLimit}`, {requestKey:"analysis"});
    else if (type === "fii") rows = await api(`/screen/db/fiis/${state.analysisPreset}?limit=${state.analysisLimit}`, {requestKey:"analysis"});
    else if(state.analysisPreset==="default") rows=await api(`/screen/db/universe/${type}?limit=${state.analysisLimit}`,{requestKey:"analysis"});
    else {
      const configuration={...(state.analysisCatalog[type]?.[state.analysisPreset]?.configuration||{}),asset_type:type,limit:state.analysisLimit};
      const payload=await api("/screen/advanced",{method:"POST",requestKey:"analysis",body:JSON.stringify(configuration)});rows=payload.rows||payload;warnings=payload?.meta?.warnings||[];
    }
    if (type === "stock") rows.sort((a,b)=>(Number(b.graham_upside_pct)||-Infinity)-(Number(a.graham_upside_pct)||-Infinity));
    else rows.sort((a,b)=>String(a.ticker).localeCompare(String(b.ticker)));
    if(state.view!=="analysis"||type!==analysisType()||requestSerial!==state.analysisRequestSerial||cacheKey!==analysisResultCacheKey(type))return;
    state.analysisRows = rows;
    state.analysisResultCache.set(cacheKey,{savedAt:Date.now(),rows});
    renderAnalysisRows(rows);
    if(warnings.length)toast(warnings.join(" "),"warning");
    const enrichedRows=await enrichBacktestLeaders(rows);
    if(state.view!=="analysis"||type!==analysisType()||requestSerial!==state.analysisRequestSerial||cacheKey!==analysisResultCacheKey(type))return;
    state.analysisRows=enrichedRows;
    state.analysisResultCache.set(cacheKey,{savedAt:Date.now(),rows:enrichedRows});
    renderAnalysisRows(enrichedRows);
  } catch (error) {
    if(error.name==="AbortError"||state.view!=="analysis"||type!==analysisType()||requestSerial!==state.analysisRequestSerial)return;
    if(cached?.rows?.length){state.analysisRows=cached.rows;renderAnalysisRows(cached.rows);root.insertAdjacentHTML("afterbegin",'<div class="notice warning analysis-refreshing">Não foi possível renovar a lista agora. Exibindo a última consulta concluída.</div>');}
    else root.innerHTML = errorState(error, "analysis");
  }
}

async function enrichBacktestLeaders(rows) {
  if (!state.session?.access?.can_view_backtests || !rows?.length) return rows || [];
  const tickers=rows.slice(0,100).map(row=>row.ticker).filter(Boolean).join(",");
  try {
    const payload=await api(`/backtests/leaderboard?per_asset=3&tickers=${encodeURIComponent(tickers)}`,{requestKey:"analysis-backtests",cacheTtlMs:60000});
    return rows.map(row=>{
      const leaders=payload.items?.[row.ticker]||[];
      return {...row,backtest_leaders:leaders,best_signal:leaders[0]?.current_signal,best_strategy:leaders[0]?.strategy_name};
    });
  } catch(error) {
    if(error.name!=="AbortError") toast("Os sinais dos backtests serão exibidos assim que o catálogo estiver disponível.");
    return rows;
  }
}

function signalLabel(value) {
  return ({buy:"Comprar",sell:"Vender",neutral:"Neutro",compra:"Comprar",venda:"Vender"})[String(value||"").toLowerCase()]||"—";
}

function backtestLeadersCell(row) {
  const leaders=(row.backtest_leaders||[]).slice(0,3);
  if(!leaders.length)return '<span class="muted">Sem dados</span>';
  return `<div class="backtest-leader-stack">${leaders.map((leader,index)=>`<div><span class="leader-rank">${index+1}</span><span><strong>${esc(leader.strategy_name||leader.strategy_id||"Estratégia")}</strong><small>${nullable(leader.ranking_score)?"":`Pontuação ${number(leader.ranking_score,1)}`}</small></span><span class="pill signal-${esc(leader.current_signal||"neutral")}">${signalLabel(leader.current_signal)}</span></div>`).join("")}</div>`;
}

function renderIndicatorGuide() {
  $("#analysis-count").textContent="";
  $("#analysis-list-workspace").classList.add("hidden");
  const root=$("#analysis-guide");root.classList.remove("hidden");
  const indicators=[...filterDefinitions.fundamental.map(([,label,description])=>({label,description})),
    {label:"Número de Graham",description:"Raiz quadrada de 22,5 × lucro por ação × valor patrimonial por ação. É uma referência conservadora para ações com lucro e patrimônio positivos, não um preço justo universal."},
    {label:"Preço-teto por dividend yield-alvo",description:"Proventos por ação dos últimos 12 meses divididos pela taxa-alvo explícita de 6%. Não é chamado de Bazin quando não há normalização histórica dos proventos."},
    {label:"Valuation relativo por pares",description:"Compara ações do mesmo setor, FIIs do mesmo segmento, ETFs pelo prêmio/desconto ao NAV na mesma moeda e BDRs pelo P/VP no mesmo setor ou indústria. Exige ao menos cinco pares e reduz o efeito de extremos antes dos cenários."},
    {label:"Valor econômico por classe",description:"Ações usam Gordon somente com D0 e três cenários explícitos. ETFs usam NAV por cota informado ou recuperado do prêmio/desconto. BDRs usam paridade apenas com lastro, câmbio e razão verificados. Futuros usam ativo à vista, carrego e vencimento do contrato frontal. Sem o insumo próprio, aparece N/D."},
    {label:"Potencial mínimo (%)",description:"Valorização mínima exigida entre a referência calculada e o preço atual: 100 × (valor de referência ÷ preço atual − 1). Se ficar vazio, o filtro exige apenas preço abaixo da referência. Com Todos, cada método deve atingir o mínimo; com Qualquer, basta um."},
    {label:"RSI 14",description:"Compara ganhos e perdas em 14 pregões pelo suavizamento de Wilder; extremos merecem contexto, não são ordem automática."},
    {label:"Tendências",description:"Alta quando o preço atual está acima da média simples de 20 ou 21 períodos. Semanas e meses em formação são excluídos."},
    {label:"Pivô, suportes e resistências",description:"PP=(máxima+mínima+fechamento)/3. R1=2×PP−mínima; S1=2×PP−máxima; R2/S2 usam a amplitude; R3/S3 usam os extremos e o PP."},
    {label:"Volume / média 9",description:"Compara o volume atual com a média simples dos nove períodos concluídos anteriores, separadamente no diário e no mensal."},
  ];
  const notes=filterDefinitions.scores.map(([,label,description])=>({label,description}));
  root.innerHTML=`<div class="guide-intro data-card"><div class="card-section"><p class="eyebrow">Base de consulta</p><h2>Como interpretar filtros, indicadores e notas</h2><p>Os filtros reduzem o universo; eles não substituem a análise do investidor. Campos sem dado não passam por um critério ativo, evitando aprovação artificial.</p></div></div>
    <div class="guide-grid">${sectionCard("Indicadores e filtros",`<div class="guide-list">${indicators.map(item=>`<details><summary>${esc(item.label)}</summary><p>${esc(item.description)}</p></details>`).join("")}</div>`,"Passe o mouse sobre o ? nos filtros para consultar estas definições")}${sectionCard("Notas de 0 a 100",`<div class="guide-list">${notes.map(item=>`<details><summary>${esc(item.label)}</summary><p>${esc(item.description)}</p></details>`).join("")}</div>`,"As notas usam somente componentes disponíveis e registram a cobertura dos dados")}</div>
    ${sectionCard("Como a Nota ALB é formada",`<div class="score-profile-grid"><article><strong>Empresas em geral</strong><span>Qualidade 25% • Valor 25% • Crescimento 15% • Técnica 10% • Risco 15% • Liquidez 10%</span></article><article><strong>Bancos</strong><span>Qualidade 30% • Valor 25% • Crescimento 10% • Técnica 10% • Risco 15% • Liquidez 10%</span></article><article><strong>Seguradoras</strong><span>Qualidade 28% • Valor 24% • Crescimento 13% • Técnica 10% • Risco 15% • Liquidez 10%</span></article><article><strong>Utilities</strong><span>Qualidade 25% • Valor 25% • Crescimento 10% • Técnica 10% • Risco 20% • Liquidez 10%</span></article><article><strong>FIIs</strong><span>Qualidade 25% • Valor 30% • Técnica 10% • Risco 20% • Liquidez 15%</span></article></div><div class="notice info" style="margin-top:14px">Se uma parte estiver sem dados, os pesos disponíveis são normalizados. A qualidade dos dados informa a cobertura para que a nota nunca pareça mais precisa do que realmente é.</div>`)}`;
}

function analysisColumns(type) {
  const common=[
    {id:"ticker",label:"Ativo",always:true,render:r=>`<span class="ticker-cell">${esc(r.ticker)}</span><br><small>${esc(r.name||"")}</small>`},
    {id:"price",label:"Preço",render:r=>money(r.price)},
    {id:"best_signal",label:"3 melhores backtests",render:backtestLeadersCell},
  ];
  const access=state.session?.access||{},alb=Boolean(access.can_use_alb_analysis),canGraham=Boolean(access.can_use_graham_valuation||alb),canDividend=Boolean(access.can_use_dividend_ceiling||alb),canRelative=Boolean(access.can_use_relative_valuation||alb),canEconomic=Boolean(access.can_use_economic_valuation||alb);
  const valuationCell=(row,family,valueField)=>{const result=row.valuation_methods?.[family]||{};if(result.status&&result.status!=="valid")return `<span class="pill muted" title="${esc(result.reason||"Dados insuficientes")}">N/D</span>`;const scenarios=result.scenarios||{},scenarioItems=[["conservative","C"],["base","B"],["optimistic","O"]].filter(([key])=>!nullable(scenarios[key]?.value));return `<span class="valuation-base-value">${money(result.value??row[valueField])}</span>${scenarioItems.length?`<small class="valuation-mini-scenarios">${scenarioItems.map(([key,label])=>`${label}: ${money(scenarios[key].value)}`).join(" • ")}</small>`:""}`;};
  const upsideCell=(row,family,valueField)=>{const result=row.valuation_methods?.[family]||{};if(result.status&&result.status!=="valid")return "—";const value=result.upside_pct??row[valueField];return `<span class="${variationClass(value)}">${pct(value,true)}</span>`;};
  if(type==="stock") {
    return [common[0],
    {id:"sector",label:"Setor",render:r=>esc(r.sector_label||r.classification||"—")},
    {id:"company_size",label:"Porte",render:r=>esc(r.company_size_label||"—")},
    {id:"in_ibov",label:"IBOV",render:r=>nullable(r.in_ibov)?"—":r.in_ibov?"Sim":"Não"},common[1],
    {id:"pe",label:"P/L",render:r=>number(r.pe)},{id:"pbv",label:"P/VP",render:r=>number(r.pbv)},
    {id:"dy",label:"DY",render:r=>pct(r.dy??r.dividend_yield_pct)},{id:"roe",label:"ROE",render:r=>pct(r.roe??r.roe_pct)},
    {id:"graham",label:"Número de Graham",render:r=>valuationCell(r,"graham_reference","graham_number")},{id:"graham_upside",label:"Potencial Graham",render:r=>upsideCell(r,"graham_reference","graham_upside_pct")},
    {id:"barsi",label:"Preço-teto DY-alvo",render:r=>valuationCell(r,"dividend_yield_ceiling","dividend_yield_ceiling_value")},{id:"barsi_upside",label:"Potencial DY-alvo",render:r=>upsideCell(r,"dividend_yield_ceiling","dividend_yield_ceiling_upside_pct")},
    {id:"relative",label:"Valor relativo",render:r=>valuationCell(r,"relative_peers","relative_peers_value")},{id:"relative_upside",label:"Potencial relativo",render:r=>upsideCell(r,"relative_peers","relative_peers_upside_pct")},
    {id:"economic",label:"Valor econômico",render:r=>valuationCell(r,"economic_value","economic_value")},{id:"economic_upside",label:"Potencial econômico",render:r=>upsideCell(r,"economic_value","economic_value_upside_pct")},
    {id:"alb",label:"Nota ALB",render:r=>number(r.alb_score,1)},
    {id:"trend_daily",label:"Tendência alta",render:r=>r.trend_daily==="up"?"Sim":r.trend_daily==="down"?"Não":"—"},
    {id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},
    ...["s3","s2","s1","pp","r1","r2","r3"].map(id=>({id,label:id==="pp"?"Pivô":id.toUpperCase(),render:r=>money(r[id])})),
    {id:"volume_daily",label:"Volume/Média 9 diário",render:r=>nullable(r.volume_daily_ratio)?"—":`${number(Number(r.volume_daily_ratio)*100,0)}%`},
    {id:"volume_monthly",label:"Volume/Média 9 mensal",render:r=>nullable(r.volume_monthly_ratio)?"—":`${number(Number(r.volume_monthly_ratio)*100,0)}%`},
    common[2],
    ].filter(column=>!(["graham","graham_upside"].includes(column.id)&&!canGraham)&&!(["barsi","barsi_upside"].includes(column.id)&&!canDividend)&&!(["relative","relative_upside"].includes(column.id)&&!canRelative)&&!(["economic","economic_upside"].includes(column.id)&&!canEconomic));
  }
  if(type==="fii") return [common[0],{id:"segment",label:"Segmento",render:r=>esc(r.segment_label||r.classification||"—")},common[1],{id:"pbv",label:"P/VP",render:r=>number(r.pbv)},{id:"dy",label:"DY",render:r=>pct(r.dy??r.dividend_yield_pct)},{id:"ffo",label:"FFO yield",render:r=>pct(r.ffo_yield??r.ffo_yield_pct)},{id:"vacancy",label:"Vacância",render:r=>pct(r.vacancy??r.vacancy_pct)},{id:"barsi",label:"Preço-teto DY-alvo",render:r=>valuationCell(r,"dividend_yield_ceiling","dividend_yield_ceiling_value")},{id:"barsi_upside",label:"Potencial DY-alvo",render:r=>upsideCell(r,"dividend_yield_ceiling","dividend_yield_ceiling_upside_pct")},{id:"relative",label:"Valor relativo",render:r=>valuationCell(r,"relative_peers","relative_peers_value")},{id:"relative_upside",label:"Potencial relativo",render:r=>upsideCell(r,"relative_peers","relative_peers_upside_pct")},{id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},common[2]].filter(column=>!(["barsi","barsi_upside"].includes(column.id)&&!canDividend)&&!(["relative","relative_upside"].includes(column.id)&&!canRelative));
  if(type==="etf") return [common[0],common[1],{id:"nav",label:"NAV por cota",render:r=>valuationCell(r,"economic_value","economic_value")},{id:"nav_upside",label:"Desconto/potencial ao NAV",render:r=>upsideCell(r,"economic_value","economic_value_upside_pct")},{id:"premium",label:"Prêmio/desconto informado",render:r=>pct(r.nav_discount_premium_pct,true)},{id:"expense",label:"Taxa de administração",render:r=>pct(r.expense_ratio_pct)},{id:"relative",label:"Referência pelos pares",render:r=>valuationCell(r,"relative_peers","relative_peers_value")},{id:"relative_upside",label:"Potencial relativo",render:r=>upsideCell(r,"relative_peers","relative_peers_upside_pct")},{id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},common[2]].filter(column=>!(["nav","nav_upside"].includes(column.id)&&!canEconomic)&&!(["relative","relative_upside"].includes(column.id)&&!canRelative));
  if(type==="bdr") return [common[0],{id:"sector",label:"Setor",render:r=>esc(r.sector_label||r.sector||"—")},common[1],{id:"pbv",label:"P/VP informado",render:r=>number(r.pbv)},{id:"relative",label:"Referência P/VP dos pares",render:r=>valuationCell(r,"relative_peers","relative_peers_value")},{id:"relative_upside",label:"Potencial relativo",render:r=>upsideCell(r,"relative_peers","relative_peers_upside_pct")},{id:"parity",label:"Paridade com o lastro",render:r=>valuationCell(r,"economic_value","economic_value")},{id:"parity_upside",label:"Potencial pela paridade",render:r=>upsideCell(r,"economic_value","economic_value_upside_pct")},{id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},common[2]].filter(column=>!(["relative","relative_upside"].includes(column.id)&&!canRelative)&&!(["parity","parity_upside"].includes(column.id)&&!canEconomic));
  if(type==="future") return [common[0],common[1],{id:"front",label:"Contrato frontal",render:r=>esc(r.front_contract||"—")},{id:"expiry",label:"Vencimento",render:r=>esc(r.expiration_date||"—")},{id:"spot",label:"Ativo à vista",render:r=>r.underlying_ticker?`${esc(r.underlying_ticker)} • ${money(r.underlying_spot_price)}`:"—"},{id:"carry",label:"Preço teórico",render:r=>valuationCell(r,"economic_value","economic_value")},{id:"basis",label:"Potencial / basis",render:r=>upsideCell(r,"economic_value","economic_value_upside_pct")},{id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},common[2]].filter(column=>!(["carry","basis"].includes(column.id)&&!canEconomic));
  return [common[0],{id:"category",label:"Categoria",render:r=>esc(r.asset_type_label||r.classification||"—")},common[1],{id:"signal",label:"Sinal",render:r=>esc(r.signal_tv||"—")},{id:"rsi",label:"RSI 14",render:r=>number(r.rsi14_screen)},{id:"technical",label:"Nota técnica",render:r=>number(r.technical_score,1)},common[2]];
}

function visibleAnalysisColumns(type, columns) {
  const defaults={stock:["ticker","sector","price","pe","pbv","dy","roe","graham_upside","barsi","relative","best_signal"],fii:["ticker","segment","price","pbv","dy","ffo","vacancy","barsi","relative","best_signal"],etf:["ticker","price","nav","nav_upside","premium","relative","best_signal"],bdr:["ticker","sector","price","pbv","relative","relative_upside","best_signal"],future:["ticker","price","front","expiry","spot","carry","basis","best_signal"]};
  const saved=state.visibleColumns[type];
  const active=new Set(Array.isArray(saved)?saved:(defaults[type]||columns.map(column=>column.id)));
  return columns.filter(column=>column.always||active.has(column.id));
}

function renderAnalysisRows(rows) {
  $("#analysis-count").textContent = `${rows.length} ativo${rows.length===1?"":"s"}`;
  if (!rows.length) { $("#analysis-table").innerHTML='<div class="empty-state"><strong>Nenhum ativo passou pelos filtros</strong>Abra os ajustes para ampliar ou alterar os critérios.</div>'; return; }
  const type = analysisType();
  const allColumns=analysisColumns(type), columns=visibleAnalysisColumns(type,allColumns);
  const active=new Set(columns.map(column=>column.id));
  const picker=`<details class="column-picker"><summary>Colunas visíveis</summary><div>${allColumns.filter(column=>!column.always).map(column=>`<label class="check"><input type="checkbox" data-column-id="${column.id}" ${active.has(column.id)?"checked":""}> ${esc(column.label)}</label>`).join("")}</div></details>`;
  $("#analysis-table").innerHTML = `<div class="table-toolbar">${picker}<span>Clique em um ativo para abrir todos os dados.</span></div><div class="table-scroll"><table><thead><tr>${columns.map(c=>`<th>${esc(c.label)}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr data-ticker="${esc(r.ticker)}">${columns.map(c=>`<td>${c.render(r)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

async function applyAdvancedFilters(showToast=true) {
  const request=analysisRequestFromForm();
  try{validateAnalysisRequest(request);}catch(error){toast(error.message,"error");return;}
  const type=analysisType(),requestSerial=++state.analysisRequestSerial;
  revealSelectedValuationColumns(request);
  if(!state.currentCustomFilter){const label=state.analysisCatalog[analysisType()]?.[state.analysisPreset]?.name||"Análise";$("#active-analysis-summary").textContent=`${label} • ajustes temporários`;}
  $("#analysis-table").innerHTML=loadingCards(6);
  try {
    const payload=await api("/screen/advanced",{method:"POST",requestKey:"analysis",body:JSON.stringify(request)});
    const rows=payload.rows||payload;
    if(state.view!=="analysis"||type!==analysisType()||requestSerial!==state.analysisRequestSerial)return;
    state.analysisRows=rows; renderAnalysisRows(rows);
    const warnings=payload?.meta?.warnings||[];
    if(warnings.length) toast(warnings.join(" "),"warning");
    else if(showToast) toast(`${rows.length} ativo(s) após os ajustes.`,"success");
    const enrichedRows=await enrichBacktestLeaders(rows);
    if(state.view!=="analysis"||type!==analysisType()||requestSerial!==state.analysisRequestSerial)return;
    state.analysisRows=enrichedRows;renderAnalysisRows(enrichedRows);
  } catch(error) { if(error.name!=="AbortError"&&state.view==="analysis"&&type===analysisType()&&requestSerial===state.analysisRequestSerial) $("#analysis-table").innerHTML=errorState(error,"analysis"); }
}

async function openAsset(ticker) {
  const dialog=$("#asset-dialog"), content=$("#asset-dialog-content");
  content.innerHTML=loadingCards(4); dialog.showModal();
  try {
    const data=await api(`/assets/${encodeURIComponent(ticker)}`,{cacheTtlMs:60000});
    const a=data.asset||{}, f=data.fundamentals||{}, t=data.technical||{}, d=data.derived||{}, tech=data.technical_analysis||{}, scores=data.scores||{}, leaders=data.backtests||[];
    const valuationLabels={graham_reference:"Número de Graham",dividend_yield_ceiling:"Preço-teto por DY-alvo",relative_peers:"Valuation relativo",economic_value:"Valor econômico"};
    const valuationStatus=result=>result.status==="not_applicable"?"Não se aplica":result.status==="valid"?"Calculado":"Dados insuficientes";
    const valuationReason=result=>({requires_positive_eps_and_bvps:"Exige lucro e patrimônio por ação positivos.",dividend_per_share_ttm_required:"Exige proventos válidos dos últimos 12 meses.",normalized_dividend_per_share_required:"Exige um dividendo D0 explícito; nenhum valor foi presumido.",three_explicit_scenarios_required:"Exige os três cenários completos.",etf_nav_or_premium_required:"A fonte ainda não informou NAV por cota nem prêmio/desconto ao NAV.",insufficient_etf_nav_peers:"Ainda não há ETFs comparáveis suficientes com prêmio/desconto ao NAV.",bdr_book_value_or_pbv_required:"A fonte ainda não informou P/VP ou valor patrimonial deste BDR.",insufficient_bdr_pbv_peers:"Ainda não há BDRs suficientes do mesmo setor ou indústria com P/VP válido.",bdr_peer_classification_required:"O BDR ainda não tem setor ou indústria confiável para formar o grupo de comparação.",bdr_underlying_price_fx_and_ratio_required:"A paridade exige preço do ativo-lastro, câmbio e razão verificada do programa de BDR.",future_spot_carry_and_expiry_required:"O preço teórico exige ativo à vista, taxa de carregamento e vencimento do contrato frontal."})[result.reason]||result.reason||"Os insumos próprios desta metodologia ainda não estão disponíveis.";
    const valuationMethods=d.valuation_methods||{};
    const valuationCards=Object.entries(valuationMethods).map(([family,result])=>metricCard(result.label||valuationLabels[family]||family,result.status==="valid"?money(result.value):valuationStatus(result),result.status==="valid"?`Potencial ${pct(result.upside_pct,true)}`:"Sem estimativa artificial",result.upside_pct)).join("");
    const valuationDetail=Object.entries(valuationMethods).map(([family,result])=>{
      const scenarios=Object.entries(result.scenarios||{});
      const scenarioBody=scenarios.length?`<div class="detail-list">${scenarios.map(([name,item])=>{const assumptions=item.assumptions||{},premises=!nullable(assumptions.required_return_pct)?`<small>Retorno ${pct(assumptions.required_return_pct)} • crescimento ${pct(assumptions.growth_pct)}${nullable(assumptions.margin_of_safety_pct)?"":` • margem ${pct(assumptions.margin_of_safety_pct)}`}</small>`:"";return `<div><span>${esc(({conservative:"Conservador",base:"Base",optimistic:"Otimista"})[name]||name)}${premises}</span><strong>${money(item.value)} <small>${pct(item.upside_pct,true)}</small></strong></div>`;}).join("")}</div>`:"";
      const audit=[result.metadata?.source,result.metadata?.as_of?`dados de ${dateTime(result.metadata.as_of)}`:null].filter(Boolean).join(" • ");
      return `<article class="valuation-method-card"><div><strong>${esc(result.label||valuationLabels[family]||family)}</strong><span class="pill">${esc(valuationStatus(result))}</span></div>${result.status==="valid"?`<p>Referência base: <strong>${money(result.value)}</strong> • potencial ${pct(result.upside_pct,true)}</p>`:`<p>${esc(valuationReason(result))} O sistema não criou uma estimativa artificial.</p>`}${scenarioBody}${!nullable(result.quality?.coverage_pct)?`<small>Cobertura: ${pct(result.quality.coverage_pct)} • amostra: ${number(result.quality.sample_size||0,0)}</small>`:""}${audit?`<small>${esc(audit)}</small>`:""}</article>`;
    }).join("");
    const fundamentals=[
      ["P/L",f.pe],["P/VP",f.pbv],["EV/EBITDA",f.ev_ebitda],["Dividend yield (%)",f.dividend_yield_pct],
      ["ROE (%)",f.roe_pct],["ROIC (%)",f.roic_pct],["Margem EBIT (%)",f.ebit_margin_pct],["Margem líquida (%)",f.net_margin_pct],
      ["Liquidez corrente",f.current_ratio],["Dívida bruta/patrimônio",f.gross_debt_to_equity],["Dívida líq./EBITDA",f.net_debt_to_ebitda],
      ["CAGR receita 5a (%)",f.revenue_cagr_5y_pct],["CAGR lucro 5a (%)",f.earnings_cagr_5y_pct],["Liquidez diária",f.daily_liquidity??t.daily_liquidity],
    ].filter(([,value])=>!nullable(value));
    const pivotRows=["s3","s2","s1","pp","r1","r2","r3"].map(key=>({label:key==="pp"?"Pivô central":key.startsWith("s")?`Suporte ${key.slice(1)}`:`Resistência ${key.slice(1)}`,value:tech[key]}));
    const leaderTable=leaders.length?marketTable(leaders,[
      {label:"Estratégia",render:r=>`<strong>${esc(r.strategy_name||r.strategy_id)}</strong>`},
      {label:"Sinal atual",render:r=>`<span class="pill signal-${esc(r.current_signal||"neutral")}">${signalLabel(r.current_signal)}</span>`},
      {label:"Pontuação",render:r=>number(r.ranking_score,1)},
      {label:"Retorno",render:r=>pct(r.metrics?.total_return_pct,true),className:r=>variationClass(r.metrics?.total_return_pct)},
    ]):'<div class="empty-state compact"><strong>Sem catálogo oficial para este ativo</strong>Os três melhores resultados aparecerão após a rodada oficial.</div>';
    content.innerHTML=`<div class="asset-dialog-header"><p class="eyebrow">${esc(a.asset_type_label||a.asset_type||"Ativo")}</p><h2 class="asset-title">${esc(a.ticker)} • ${esc(a.name||"")}</h2><p class="asset-subtitle">${esc(a.sector_label||a.classification||"")} ${a.company_size_label?`• ${esc(a.company_size_label)}`:""}</p></div>
      <div class="metric-grid asset-summary">${metricCard("Preço",money(f.price??t.close))}${valuationCards}${metricCard("Sinal do melhor backtest",signalLabel(leaders[0]?.current_signal),leaders[0]?.strategy_name||"")}</div>
      <div class="asset-detail-grid">
        ${sectionCard("Indicadores fundamentalistas",fundamentals.length?`<div class="detail-list">${fundamentals.map(([label,value])=>`<div><span>${esc(label)}</span><strong>${number(value,2)}</strong></div>`).join("")}</div>`:'<div class="empty-state compact">Sem dados fundamentalistas recentes.</div>')}
        ${valuationDetail?sectionCard("Metodologias de valor",`<div class="valuation-method-list">${valuationDetail}</div>`,`Somente métodos autorizados são exibidos; N/D nunca é convertido em preço estimado.`):""}
        ${sectionCard("Análise técnica",`<div class="metric-grid mini">${metricCard("RSI 14",number(tech.rsi14??t.rsi14))}${metricCard("Tendência diária",tech.trend_daily==="up"?"Alta":tech.trend_daily==="down"?"Baixa":"—")}${metricCard("Volume diário / média 9",nullable(tech.volume_daily_ratio)?"—":pct(Number(tech.volume_daily_ratio)*100))}${metricCard("Volume mensal / média 9",nullable(tech.volume_monthly_ratio)?"—":pct(Number(tech.volume_monthly_ratio)*100))}</div><div class="detail-list pivot-list">${pivotRows.map(row=>`<div><span>${esc(row.label)}</span><strong>${money(row.value)}</strong></div>`).join("")}</div><small class="formula-note">Pivôs calculados pela máxima, mínima e fechamento do último período concluído.</small>`)}
        ${sectionCard("Notas do ativo",`<div class="detail-list">${Object.entries({"Qualidade":scores.quality_score,"Valor":scores.value_score,"Crescimento":scores.growth_score,"Técnica":scores.technical_score,"Risco":scores.risk_score,"Liquidez":scores.liquidity_score,"ALB":scores.alb_score,"Qualidade dos dados":scores.data_quality_score}).map(([label,value])=>`<div><span>${esc(label)}</span><strong>${number(value,1)}</strong></div>`).join("")}</div>`)}
        ${sectionCard("3 melhores backtests e sinal atual",leaderTable,"Ordenados pela consistência dos resultados oficiais")}
      </div>`;
  } catch(error) { content.innerHTML=errorState(error); }
}

async function loadPortfolios() {
  const root=$("#portfolio-tab-content"); root.innerHTML=loadingCards(5);
  try {
    state.portfolios=await api("/portfolios",{requestKey:"portfolios",cacheTtlMs:30000});
    if (!state.portfolios.length) {
      state.portfolioId=null;$("#portfolio-selector-wrap").innerHTML="";
      if(state.tabs.portfolio==="alerts"){await renderAlerts(root);return;}
      if(state.tabs.portfolio==="news"){await renderNewsWorkspace(root);return;}
      root.innerHTML='<div class="data-card empty-state"><strong>Você ainda não criou uma carteira</strong>A criação estará disponível aqui para contas com permissão de edição.</div>'; return;
    }
    if (!state.portfolioId || !state.portfolios.some(p=>p.id===state.portfolioId)) state.portfolioId=state.portfolios[0].id;
    $("#portfolio-selector-wrap").innerHTML=`<select id="portfolio-selector" class="button secondary">${state.portfolios.map(p=>`<option value="${esc(p.id)}" ${p.id===state.portfolioId?"selected":""}>${esc(p.name)}</option>`).join("")}</select>`;
    await renderPortfolioTab();
  } catch(error) { root.innerHTML=errorState(error,"portfolio"); }
}

function allocationDonut(items) {
  const rows=(items||[]).filter(item=>Number(item.value)>0);
  if(!rows.length)return '<div class="empty-state"><strong>Composição ainda vazia</strong>Cadastre posições ou investimentos para visualizar a distribuição.</div>';
  const colors=["#0b5d4b","#c79b3b","#4f7cac","#9b5de5","#e07a5f","#2a9d8f","#6c757d","#f4a261"];
  let cursor=0;const stops=rows.map((item,index)=>{const start=cursor;cursor+=Number(item.weight_pct||0);return `${colors[index%colors.length]} ${start}% ${cursor}%`;});
  return `<div class="allocation-visual"><div class="allocation-donut" style="background:conic-gradient(${stops.join(",")})"><span>${money(rows.reduce((sum,item)=>sum+Number(item.value||0),0))}</span></div><div class="allocation-legend">${rows.map((item,index)=>`<div><i class="legend-dot" style="background:${colors[index%colors.length]}"></i><span>${esc(item.label)}</span><strong>${pct(item.weight_pct)}</strong></div>`).join("")}</div></div>`;
}

function newsCacheStatus(cache) {
  const labels={not_requested:"Aguardando primeira atualização",pending:"Na fila",queued:"Na fila",running:"Atualizando",completed:"Atualizado",failed:"Falha na última tentativa"};
  return labels[cache?.status]||cache?.status||"Aguardando";
}

function newsHeadline(item,index,{recommendation=false}={}) {
  const institution=recommendation?(item.institution||item.bank_group_label):null;
  const metadata=[institution,item.source,item.published_at?dateTime(item.published_at):null].filter(Boolean);
  const tickers=(item.mentioned_tickers||[]).map(ticker=>`<span class="pill">${esc(ticker)}</span>`).join("");
  return `<a class="headline" href="${esc(safeExternalUrl(item.url))}" target="_blank" rel="noopener noreferrer"><span class="headline-number">${index+1}</span><span><strong>${esc(item.title)}</strong><small>${esc(metadata.join(" • "))}</small>${tickers?`<span class="headline-tags">${tickers}</span>`:""}</span><small>Abrir fonte</small></a>`;
}

function queueNewsPanelReload(cache) {
  clearTimeout(state.newsRefreshTimer);
  if(!["pending","queued","running"].includes(cache?.status))return;
  state.newsRefreshTimer=setTimeout(()=>{
    if(state.view==="portfolio"&&state.tabs.portfolio==="news")renderPortfolioTab();
  },4500);
}

async function renderPortfolioNews(root) {
  if(!state.portfolioId) {
    root.innerHTML='<div class="data-card empty-state"><strong>Nenhuma carteira cadastrada</strong>Crie uma carteira para receber notícias relacionadas aos ativos. As notícias de recomendações continuam disponíveis acima.</div>';
    return;
  }
  const cache=await api(`/insights/news/cache/portfolios/${state.portfolioId}`,{cacheTtlMs:15000,bypassCache:true});
  const data=cache.data||{},groups=data.assets||data.items||[];
  const update=`<div class="update-panel"><div class="update-summary"><span><strong>Notícias dos ativos da carteira</strong><small>${cache.finished_at?`Última atualização: ${dateTime(cache.finished_at)}`:"A atualização diária será iniciada no primeiro acesso autenticado."}</small></span><span><span class="pill ${cache.status==="failed"?"danger":""}">${esc(newsCacheStatus(cache))}</span><button class="button secondary compact" data-portfolio-news-refresh="${esc(state.portfolioId)}" ${["pending","queued","running"].includes(cache.status)?"disabled":""}>Atualizar novamente hoje</button></span></div>${cache.error?`<div class="notice danger">A última tentativa não foi concluída. Os dados anteriores foram preservados.</div>`:""}</div>`;
  const content=groups.length?groups.map(group=>`<div class="card-section"><div class="card-heading"><h3>${esc(group.ticker||group.label||"Ativo")}</h3><small>${(group.items||group.news||[]).length} notícia(s)</small></div><div class="headline-list">${(group.items||group.news||[]).map((item,index)=>newsHeadline(item,index)).join("")}</div></div>`).join(""):'<div class="empty-state"><strong>Notícias sendo preparadas</strong>O carregamento ocorre em segundo plano e a página continua disponível para outras tarefas.</div>';
  root.innerHTML=update+sectionCard("Notícias da carteira",content,"Até 3 notícias relevantes por ativo, sem bloquear a navegação");
  queueNewsPanelReload(cache);
}

async function renderRecommendationNews(root) {
  const category=state.recommendationCategory;
  const cache=await api(`/insights/news/cache/recommendations?category=${encodeURIComponent(category)}`,{cacheTtlMs:15000,bypassCache:true});
  const data=cache.data||{},items=data.items||[];
  const categories=[{id:"all",label:"Todas"},{id:"brazil",label:"Instituições brasileiras"},{id:"global",label:"Instituições globais"}];
  const controls=`<div class="recommendation-controls"><div class="segmented-control">${categories.map(item=>`<button class="button ${item.id===category?"primary":"ghost"} compact" data-recommendation-category="${item.id}">${item.label}</button>`).join("")}</div><button class="button secondary compact" data-recommendation-news-refresh="${esc(category)}" ${["pending","queued","running"].includes(cache.status)?"disabled":""}>Atualizar novamente hoje</button></div>`;
  const update=`<div class="update-panel"><div class="update-summary"><span><strong>Notícias de recomendações</strong><small>${cache.finished_at?`Última atualização: ${dateTime(cache.finished_at)}`:"A primeira busca do dia será feita automaticamente."}</small></span><span class="pill ${cache.status==="failed"?"danger":""}">${esc(newsCacheStatus(cache))}</span></div>${cache.error?'<div class="notice danger">A fonte não respondeu na última tentativa. Uma nova tentativa pode ser solicitada sem apagar os dados anteriores.</div>':""}</div>`;
  const content=items.length?`<div class="headline-list"><div class="headline headline-header"><span>#</span><span>Manchete • instituição • fonte • publicação</span><span>Link</span></div>${items.map((item,index)=>newsHeadline(item,index,{recommendation:true})).join("")}</div>`:'<div class="empty-state"><strong>Recomendações sendo pesquisadas</strong>As fontes públicas estão sendo consultadas em segundo plano.</div>';
  root.innerHTML=controls+update+sectionCard("Recomendações de instituições",content,"Links informativos encontrados em fontes públicas; não constituem recomendação do Formação do Investidor.");
  queueNewsPanelReload(cache);
}

async function renderNewsWorkspace(root) {
  const allowed=state.session.access.can_view_news_insights;
  if(!allowed){root.innerHTML='<div class="data-card empty-state"><strong>Notícias não liberadas para esta conta</strong>O administrador pode liberar este módulo no nível de acesso do usuário.</div>';return;}
  root.innerHTML=`<div class="subtabs"><button class="tab ${state.portfolioNewsMode==="portfolio"?"active":""}" data-portfolio-news-mode="portfolio">Ativos da carteira</button><button class="tab ${state.portfolioNewsMode==="recommendations"?"active":""}" data-portfolio-news-mode="recommendations">Recomendações</button></div><div id="portfolio-news-content">${loadingCards(4)}</div>`;
  const content=$("#portfolio-news-content",root);
  if(state.portfolioNewsMode==="recommendations")await renderRecommendationNews(content);
  else await renderPortfolioNews(content);
}

async function renderPortfolioTab() {
  const root=$("#portfolio-tab-content"), tab=state.tabs.portfolio;
  root.innerHTML=loadingCards(5);
  try {
    if (tab==="positions") {
      const data=await api(`/portfolios/${state.portfolioId}`,{cacheTtlMs:30000});
      const positions=data.positions||data.items||[];
      const summary=data.summary||{};
      const cards=`<div class="metric-grid summary-grid">${metricCard("Patrimônio",money(data.consolidated_summary?.total_value??data.consolidated_summary?.known_total_value??summary.market_value))}${metricCard("Posições",String(positions.length))}${metricCard("Outros investimentos",money(data.custom_summary?.current_value||0))}${metricCard("Caixa",money(data.portfolio?.cash_balance))}</div>`;
      const priceDates=positions.map(item=>item.current_price_as_of).filter(Boolean).sort();
      const priceUpdate=data.price_update||{};
      const quoteUpdate=`<div class="update-panel"><div class="update-summary"><span><strong>Cotações da carteira</strong><small>${priceDates.length?`Mais recente: ${dateTime(priceDates[priceDates.length-1])}`:"Nenhuma cotação disponível"} • ${esc(priceUpdate.source||"Yahoo Finance")}${priceUpdate.next_update_at?` • próxima ${dateTime(priceUpdate.next_update_at)}`:""}</small></span><span><span class="pill ${["failed","stale","partial"].includes(priceUpdate.status)?"warning":""}">${esc(updateStatusLabels[priceUpdate.status]||priceUpdate.status||"Sob demanda")}</span><button class="button secondary compact" data-portfolio-prices-refresh="${esc(state.portfolioId)}">Atualizar agora</button></span></div></div>`;
      const positionForm=state.session.access.can_write_portfolio?`<details class="data-card"><summary><strong>Adicionar ou atualizar posição</strong></summary><form id="portfolio-position-form" class="filter-grid" style="margin-top:16px"><div class="field"><label>Código do ativo</label><input name="ticker" required maxlength="24" placeholder="PETR4"></div><div class="field"><label>Tipo</label><select name="asset_type"><option value="stock">Ação</option><option value="fii">FII</option><option value="etf">ETF</option><option value="bdr">BDR</option><option value="future">Futuro</option><option value="crypto">Cripto</option><option value="other">Outro</option></select></div><div class="field"><label>Quantidade total</label><input name="quantity" type="number" min="0" step="0.000001" required></div><div class="field"><label>Preço médio</label><input name="average_price" type="number" min="0" step="0.000001"></div><div class="field"><label>Meta na carteira (%)</label><input name="target_weight_pct" type="number" min="0" max="100" step="0.01" value="0"></div><div class="field"><label>Categoria opcional</label><input name="classification_override" maxlength="120" placeholder="Ex.: Renda variável"></div><div class="field"><label>Setor</label><input name="sector_override" maxlength="120" placeholder="Ex.: Financeiro"></div><div class="field"><label>Segmento</label><input name="segment_override" maxlength="120" placeholder="Ex.: Bancos"></div><button class="button primary wide-action" type="submit">Salvar posição</button></form></details>`:"";
      const positionTable=marketTable(positions,[{label:"Ativo",render:r=>`<span class="ticker-cell">${esc(r.ticker)}</span>`},{label:"Quantidade",render:r=>Number(r.quantity||0).toLocaleString("pt-BR",{maximumFractionDigits:6})},{label:"Preço médio",render:r=>money(r.average_price)},{label:"Preço atual",render:r=>`${money(r.current_price)}${r.current_price_as_of?`<br><small>${dateTime(r.current_price_as_of)} • ${esc(r.price_source||"")}</small>`:""}`},{label:"Valor",render:r=>money(r.market_value??(Number(r.quantity)*Number(r.current_price)))},{label:"Peso / meta",render:r=>`${pct(r.current_weight_pct)}<br><small>meta ${pct(r.effective_target_weight_pct??r.target_weight_pct)}</small>`},{label:"Rebalanceamento",render:r=>nullable(r.rebalance_value)?"—":`<strong class="${variationClass(r.rebalance_value)}">${Number(r.rebalance_value)>=0?"Comprar":"Reduzir"} ${money(Math.abs(Number(r.rebalance_value)))}</strong>${nullable(r.rebalance_quantity)?"":`<br><small>aprox. ${number(Math.abs(Number(r.rebalance_quantity)),0)} unidade(s)</small>`}`},{label:"Setor / segmento",render:r=>`${esc(r.sector||r.classification||"—")}<br><small>${esc(r.segment||"—")}</small>`},{label:"",render:r=>state.session.access.can_write_portfolio?`<button class="button ghost compact danger" data-delete-position="${esc(r.ticker)}">Remover</button>`:""}]);
      root.innerHTML=quoteUpdate+cards+sectionCard("Posições",positionTable,"Sugestão matemática baseada nas metas informadas; não constitui recomendação de investimento.")+positionForm;
    } else if (tab==="allocation") {
      const [data,catalog]=await Promise.all([api(`/portfolios/${state.portfolioId}`,{cacheTtlMs:30000}),api(`/portfolios/${state.portfolioId}/custom-investments/catalog`,{cacheTtlMs:300000})]);
      const rows=data.custom_investments||[],summary=data.consolidated_summary||{},today=new Date().toISOString().slice(0,10);
      const form=state.session.access.can_write_portfolio?`<details class="data-card" ${rows.length?"":"open"}><summary><strong>Adicionar investimento sem ticker</strong></summary><form id="custom-investment-form" class="filter-grid" style="margin-top:16px"><div class="field"><label>Tipo</label><select name="category" required>${catalog.map(item=>`<option value="${esc(item.id)}">${esc(item.label)}</option>`).join("")}</select></div><div class="field"><label>Nome do investimento</label><input name="name" required maxlength="200" placeholder="Ex.: CDB Banco X 110% CDI"></div><div class="field"><label>Instituição</label><input name="institution" maxlength="160" placeholder="Banco ou corretora"></div><div class="field"><label>Setor</label><input name="sector" maxlength="120" placeholder="Ex.: Renda fixa"></div><div class="field"><label>Segmento</label><input name="segment" maxlength="120" placeholder="Ex.: Bancário pós-fixado"></div><div class="field"><label>Data da aplicação</label><input type="date" name="application_date" required value="${today}"></div><div class="field"><label>Vencimento (opcional)</label><input type="date" name="maturity_date"></div><div class="field"><label>Valor aplicado</label><input type="number" name="invested_value" min="0.01" step="0.01" required></div><div class="field"><label>Valor atual</label><input type="number" name="current_value" min="0" step="0.01" required></div><div class="field"><label>Data do valor atual</label><input type="date" name="current_value_as_of" required value="${today}"></div><div class="field"><label>Indexador / referência</label><input name="benchmark" maxlength="80" placeholder="Ex.: 110% do CDI"></div><div class="field"><label>Liquidez</label><input name="liquidity" maxlength="120" placeholder="Ex.: no vencimento ou D+1"></div><div class="field wide-action"><label>Observações</label><textarea name="notes" rows="2"></textarea></div><button class="button primary wide-action" type="submit">Salvar investimento</button></form></details>`:"";
      root.innerHTML=`<div class="metric-grid summary-grid">${metricCard("Patrimônio conhecido",money(summary.known_total_value))}${metricCard("Investimentos sem ticker",money(data.custom_summary?.current_value||0),`${rows.length} cadastro(s)`)}${metricCard("Valor aplicado",money(data.custom_summary?.invested_value||0))}${metricCard("Variação",pct(data.custom_summary?.variation_pct,true))}</div>${sectionCard("Composição consolidada",allocationDonut(data.consolidated_allocation||[]),summary.allocation_complete?"Valores de mercado e valores informados manualmente":"Composição parcial: existe posição sem cotação")}${sectionCard("Renda fixa, fundos e outros",marketTable(rows,[{label:"Investimento",render:r=>`<strong>${esc(r.name)}</strong><br><small>${esc(r.category_label)}</small>`},{label:"Setor / segmento",render:r=>`${esc(r.sector||"—")}<br><small>${esc(r.segment||"—")}</small>`},{label:"Instituição",render:r=>esc(r.institution||"—")},{label:"Aplicação",render:r=>dateOnly(r.application_date)},{label:"Vencimento",render:r=>dateOnly(r.maturity_date)},{label:"Aplicado",render:r=>money(r.invested_value)},{label:"Atual",render:r=>`${money(r.current_value)}<br><small>${dateOnly(r.current_value_as_of)}</small>`},{label:"Variação",render:r=>pct(r.variation_pct,true),className:r=>variationClass(r.variation_pct)},{label:"",render:r=>state.session.access.can_write_portfolio?`<span class="row-actions"><button class="button ghost compact" data-update-custom-investment="${esc(r.id)}" data-current-value="${esc(r.current_value)}">Atualizar valor</button><button class="button ghost compact danger" data-delete-custom-investment="${esc(r.id)}">Arquivar</button></span>`:""}]),"O histórico preserva cada valor informado por data")}${form}`;
    } else if (tab==="dividends") {
      await renderPortfolioDividends(root);
    } else if (tab==="news") {
      await renderNewsWorkspace(root);
    } else {
      await renderAlerts(root);
    }
  } catch(error) { root.innerHTML=errorState(error); }
}

async function renderAlerts(root) {
  const access=state.session.access;
  if (!access.can_use_price_alerts) { root.innerHTML='<div class="data-card empty-state"><strong>Alertas não liberados para esta conta</strong>O administrador pode conceder um limite de 1, 3, 5 ou 10 ativos.</div>'; return; }
  const [catalog,data,history]=await Promise.all([
    api("/alerts/catalog",{cacheTtlMs:300000}),
    api("/alerts",{cacheTtlMs:10000,bypassCache:true}),
    api("/alerts/history?limit=100",{cacheTtlMs:10000,bypassCache:true}),
  ]);
  state.alertCatalog=catalog;state.alertData={...data,history};
  const alerts=data.alerts||[],active=alerts.filter(item=>item.status==="active");
  const permissions=catalog.permissions||data.permissions||{};
  const conditionFields=[
    {key:"price_above",label:"Preço subindo até ou acima de",placeholder:"Ex.: 42,50",suffix:"valor"},
    {key:"price_below",label:"Preço caindo até ou abaixo de",placeholder:"Ex.: 38,00",suffix:"valor"},
    {key:"change_positive_pct",label:"Variação positiva desde o fechamento",placeholder:"Ex.: 3,00",suffix:"%"},
    {key:"change_negative_pct",label:"Variação negativa desde o fechamento",placeholder:"Ex.: 2,50",suffix:"%"},
  ];
  const ruleInputs=conditionFields.map(field=>`<div class="field alert-condition ${permissions[field.key]?"":"disabled-condition"}"><label>${esc(field.label)} ${permissions[field.key]?"":'<span class="pill">Não liberado</span>'}</label><div class="input-suffix"><input name="${field.key}" type="number" min="0.000001" step="any" placeholder="${esc(field.placeholder)}" ${permissions[field.key]?"":"disabled"}><span>${field.suffix}</span></div></div>`).join("");
  const alertForm=`<form id="price-alert-form" class="alert-form"><div class="filter-grid"><div class="field"><label>Mercado</label><select name="market_scope" id="alert-market-scope"><option value="b3">Ativos negociados na B3</option><option value="market">Índices, moedas, criptos e commodities</option></select></div><div class="field alert-symbol-field"><label>Código ou nome do ativo</label><input name="symbol" id="alert-symbol" autocomplete="off" required maxlength="32" placeholder="Digite, por exemplo, BBAS3"><div id="alert-symbol-suggestions" class="alert-suggestions hidden"></div></div>${ruleInputs}<button class="button primary wide-action" type="submit">Criar ou atualizar alerta</button></div><div class="notice info alert-form-help">Cada ativo consome uma vaga, mesmo quando possui mais de uma condição. Campos vazios não serão monitorados. Regravar um ativo atualiza o alerta existente.</div></form>`;
  const preferenceForm=`<form id="alert-preference-form" class="filter-grid"><div class="field"><label>E-mail principal do cadastro</label><input value="${esc(data.primary_email||state.session.user.email)}" disabled></div><div class="field"><label>Segundo e-mail (opcional)</label><input name="secondary_email" type="email" maxlength="320" value="${esc(data.secondary_email||"")}" placeholder="outro@email.com"></div><button class="button primary" type="submit">Salvar e-mails</button><button class="button secondary" type="button" data-alert-test-email ${data.delivery_configured?"":"disabled"}>Enviar e-mail de teste</button></form>`;
  const alertTable=marketTable(alerts,[
    {label:"Ativo",render:r=>`<strong>${esc(r.symbol)}</strong><br><small>${esc(r.display_name||"")}</small>`},
    {label:"Condições",render:r=>alertConditionSummary(r)},
    {label:"Última cotação",render:r=>`${nullable(r.last_price)?"—":number(r.last_price,4)}${nullable(r.last_change_pct)?"":`<br><small class="${variationClass(r.last_change_pct)}">${pct(r.last_change_pct,true)}</small>`}`},
    {label:"Verificado em",render:r=>dateTime(r.last_checked_at)},
    {label:"Situação",render:r=>`<span class="pill ${r.status==="disabled"?"warning":r.status==="triggered"?"danger":""}">${esc(alertStatusLabel(r.status))}</span>`},
    {label:"Ações",render:r=>`<span class="row-actions"><button class="button ghost compact" data-edit-alert="${esc(r.id)}">Editar</button><button class="button ${r.status==="active"?"ghost danger":"secondary"} compact" data-alert-status="${esc(r.id)}" data-next-status="${r.status==="active"?"disabled":"active"}">${r.status==="active"?"Desativar":"Reativar"}</button></span>`},
  ]);
  const historyTable=marketTable(history,[
    {label:"Ativo",render:r=>`<strong>${esc(r.symbol)}</strong><br><small>${esc(r.display_name||"")}</small>`},
    {label:"O que ocorreu",render:r=>alertEventSummary(r)},
    {label:"Cotação",render:r=>`${nullable(r.observed?.price)?"—":number(r.observed.price,4)}${nullable(r.observed?.change_pct)?"":`<br><small class="${variationClass(r.observed.change_pct)}">${pct(r.observed.change_pct,true)}</small>`}`},
    {label:"Disparo",render:r=>dateTime(r.sent_at||r.created_at)},
    {label:"Destinatários",render:r=>(r.recipients||[]).map(esc).join("<br>")||"—"},
    {label:"Entrega",render:r=>`<span class="pill ${r.delivery_status==="failed"?"danger":""}">${esc(({sent:"E-mail enviado",pending:"Envio pendente",failed:"Falha no envio"})[r.delivery_status]||r.delivery_status||"—")}</span>`},
  ]);
  root.innerHTML=`<div class="notice info alert-schedule"><strong>Como funciona:</strong> ${esc(catalog.b3_schedule)} ${esc(catalog.market_schedule)}<br><small>${esc(catalog.quote_notice||"")}</small></div><div class="metric-grid summary-grid">${metricCard("Alertas ativos",`${active.length} / ${data.limit??access.alert_asset_limit}`,"Cada ativo conta como um alerta")}${metricCard("Condições liberadas",String(Object.values(permissions).filter(Boolean).length),"Até quatro por ativo")}${metricCard("Envio por e-mail",data.delivery_configured?"Configurado":"Pendente",data.secondary_email?"Dois destinatários":"E-mail principal")}${metricCard("Alertas disparados",String(history.length),"Histórico preservado")}</div><div class="alerts-workspace">${sectionCard("Novo alerta",alertForm,"B3 a cada 5 minutos; mercados internacionais a cada 30 minutos")}${sectionCard("Destinatários",preferenceForm,"O e-mail principal é o mesmo utilizado no acesso à plataforma")}</div>${sectionCard("Alertas cadastrados",alerts.length?alertTable:'<div class="empty-state compact"><strong>Nenhum alerta cadastrado</strong>Escolha um ativo e ao menos uma condição acima.</div>',`Limite autorizado: ${data.limit??access.alert_asset_limit} ativo(s)`)}`+
    `<details class="data-card alert-history" ${history.length?"":"open"}><summary><strong>Histórico de alertas disparados</strong><span class="pill">${history.length}</span></summary><div class="alert-history-body">${history.length?historyTable:'<div class="empty-state compact">Nenhum alerta foi disparado até agora.</div>'}</div></details>`;
  $("#notification-count").textContent=active.length;
  $("#notification-count").classList.toggle("hidden",!active.length);
}

function alertStatusLabel(status){return ({active:"Ativo",disabled:"Desativado",triggered:"Disparado"})[status]||status||"—";}
function alertConditionSummary(alert){
  const parts=[];
  if(!nullable(alert.price_above))parts.push(`Preço ≥ ${number(alert.price_above,4)}`);
  if(!nullable(alert.price_below))parts.push(`Preço ≤ ${number(alert.price_below,4)}`);
  if(!nullable(alert.change_positive_pct))parts.push(`Alta ≥ ${pct(alert.change_positive_pct)}`);
  if(!nullable(alert.change_negative_pct))parts.push(`Queda ≥ ${pct(alert.change_negative_pct)}`);
  return parts.length?parts.map(esc).join("<br>"):"—";
}
function alertEventSummary(event){
  const configured=event.configured_values||{};
  return (event.triggered_rules||[]).map(rule=>({price_above:`Preço atingiu ou superou ${number(configured.price_above,4)}`,price_below:`Preço atingiu ou caiu abaixo de ${number(configured.price_below,4)}`,change_positive_pct:`Alta atingiu ${pct(configured.change_positive_pct)}`,change_negative_pct:`Queda atingiu ${pct(configured.change_negative_pct)}`})[rule]||rule).map(esc).join("<br>")||"Condição atingida";
}
function alertCatalogItems(){
  const scope=$("#alert-market-scope")?.value||"b3";
  return state.alertCatalog?.[scope]||[];
}
function renderAlertSuggestions(query=""){
  const root=$("#alert-symbol-suggestions");if(!root)return;
  const term=String(query||"").trim().toLocaleUpperCase("pt-BR");
  if(!term){root.classList.add("hidden");root.innerHTML="";return;}
  const items=alertCatalogItems().filter(item=>`${item.key} ${item.label}`.toLocaleUpperCase("pt-BR").includes(term)).slice(0,12);
  root.innerHTML=items.length?items.map(item=>`<button type="button" data-alert-suggestion="${esc(item.key)}"><strong>${esc(item.key)}</strong><span>${esc(item.label||item.key)}</span><small>${esc(item.asset_type||item.group||"")}</small></button>`).join(""):'<div class="empty-state compact">Nenhum ativo correspondente.</div>';
  root.classList.remove("hidden");
}
async function savePriceAlert(form){
  const values=Object.fromEntries(new FormData(form));
  const payload={market_scope:values.market_scope,symbol:String(values.symbol||"").trim().toUpperCase()};
  for(const key of ["price_above","price_below","change_positive_pct","change_negative_pct"])payload[key]=values[key]?Number(String(values[key]).replace(",",".")):null;
  const button=form.querySelector('button[type="submit"]');button.disabled=true;button.textContent="Salvando…";
  try{await api("/alerts",{method:"POST",body:JSON.stringify(payload)});toast("Alerta salvo e monitoramento ativado.","success");await renderPortfolioTab();}
  catch(error){toast(error.message,"error");button.disabled=false;button.textContent="Criar ou atualizar alerta";}
}
async function saveAlertPreferences(form){
  const secondary=String(new FormData(form).get("secondary_email")||"").trim()||null;
  try{await api("/alerts/preferences",{method:"PUT",body:JSON.stringify({secondary_email:secondary})});toast("Destinatários atualizados.","success");await renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}
async function sendAlertTestEmail(button){
  button.disabled=true;
  try{const result=await api("/alerts/test-email",{method:"POST"});toast(`E-mail de teste enviado para ${(result.recipients||[]).length||1} destinatário(s).`,"success");}
  catch(error){toast(error.message,"error");}
  finally{button.disabled=false;}
}
async function setAlertStatus(button){
  button.disabled=true;
  try{await api(`/alerts/${encodeURIComponent(button.dataset.alertStatus)}/status`,{method:"PATCH",body:JSON.stringify({status:button.dataset.nextStatus})});toast(button.dataset.nextStatus==="active"?"Alerta reativado.":"Alerta desativado.","success");await renderPortfolioTab();}
  catch(error){toast(error.message,"error");button.disabled=false;}
}
function editPriceAlert(alertId){
  const alert=(state.alertData?.alerts||[]).find(item=>item.id===alertId),form=$("#price-alert-form");if(!alert||!form)return;
  form.elements.market_scope.value=alert.market_scope;form.elements.symbol.value=alert.symbol;
  for(const key of ["price_above","price_below","change_positive_pct","change_negative_pct"])if(form.elements[key])form.elements[key].value=nullable(alert[key])?"":alert[key];
  form.scrollIntoView({behavior:"smooth",block:"start"});form.elements.symbol.focus();
}

async function refreshRecommendationNews(category){
  try{const result=await api(`/insights/news/cache/recommendations/refresh?category=${encodeURIComponent(category)}`,{method:"POST"});toast(result.scheduled===false?"As recomendações já estão sendo atualizadas.":"Atualização das recomendações solicitada.",result.scheduled===false?"info":"success");setTimeout(()=>renderPortfolioTab(),2500);}
  catch(error){toast(error.message,"error");}
}

async function refreshPortfolioNews(portfolioId) {
  try {
    const result=await api(`/insights/news/cache/portfolios/${encodeURIComponent(portfolioId)}/refresh`,{method:"POST"});
    toast(result.scheduled===false?"As notícias já estão sendo atualizadas.":"Atualização das notícias solicitada.",result.scheduled===false?"info":"success");
    setTimeout(()=>renderPortfolioTab(),2500);
  } catch(error) { toast(error.message,"error"); }
}

async function saveCustomInvestment(form) {
  const values=Object.fromEntries(new FormData(form));
  for(const key of ["invested_value","current_value"])values[key]=Number(values[key]);
  for(const key of ["maturity_date","institution","sector","segment","benchmark","liquidity","notes"])if(!values[key])values[key]=null;
  try{await api(`/portfolios/${encodeURIComponent(state.portfolioId)}/custom-investments`,{method:"POST",body:JSON.stringify(values)});toast("Investimento salvo.","success");renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}

async function savePortfolioPosition(form){
  const values=Object.fromEntries(new FormData(form)),ticker=String(values.ticker||"").trim().toUpperCase();
  const payload={asset_type:values.asset_type,stage:"position",quantity:Number(values.quantity||0),average_price:values.average_price?Number(values.average_price):null,target_weight_pct:Number(values.target_weight_pct||0),classification_override:values.classification_override||null,sector_override:values.sector_override||null,segment_override:values.segment_override||null,notes:null};
  try{await api(`/portfolios/${encodeURIComponent(state.portfolioId)}/positions/${encodeURIComponent(ticker)}`,{method:"PUT",body:JSON.stringify(payload)});toast("Posição salva e alocação recalculada.","success");renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}

async function deletePortfolioPosition(button){
  if(!window.confirm(`Remover ${button.dataset.deletePosition} desta carteira?`))return;
  try{await api(`/portfolios/${encodeURIComponent(state.portfolioId)}/positions/${encodeURIComponent(button.dataset.deletePosition)}`,{method:"DELETE"});toast("Posição removida.","success");renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}

async function updateCustomInvestmentValue(button) {
  const dialog=$("#custom-value-dialog"),form=$("#custom-value-form");
  form.elements.investment_id.value=button.dataset.updateCustomInvestment;
  form.elements.current_value.value=button.dataset.currentValue||"";
  form.elements.current_value_as_of.value=new Date().toISOString().slice(0,10);
  dialog.showModal();
}

async function saveCustomInvestmentValue(form){
  const values=Object.fromEntries(new FormData(form)),value=Number(values.current_value);
  if(!Number.isFinite(value)||value<0){toast("Informe um valor válido.","error");return;}
  try{await api(`/portfolios/${encodeURIComponent(state.portfolioId)}/custom-investments/${encodeURIComponent(values.investment_id)}`,{method:"PATCH",body:JSON.stringify({current_value:value,current_value_as_of:values.current_value_as_of})});$("#custom-value-dialog").close();toast("Valor e histórico atualizados.","success");renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}

async function deleteCustomInvestment(button) {
  if(!window.confirm("Arquivar este investimento? O histórico será preservado."))return;
  try{await api(`/portfolios/${encodeURIComponent(state.portfolioId)}/custom-investments/${encodeURIComponent(button.dataset.deleteCustomInvestment)}`,{method:"DELETE"});toast("Investimento arquivado.","success");renderPortfolioTab();}
  catch(error){toast(error.message,"error");}
}

async function refreshPortfolioPrices(portfolioId) {
  try {
    const result=await api(`/portfolios/${encodeURIComponent(portfolioId)}/refresh-prices`,{method:"POST"});
    toast(result.scheduled?"Atualização das cotações solicitada.":"As cotações foram solicitadas há menos de 5 minutos.",result.scheduled?"success":"info");
    setTimeout(()=>renderPortfolioTab(),3000);
  } catch(error) { toast(error.message,"error"); }
}

function readableConfigurationKey(key) {
  const labels={
    fast:"Período rápido",fast_period:"Período rápido",fast_window:"Média rápida",
    slow:"Período lento",slow_period:"Período lento",slow_window:"Média lenta",
    signal:"Período do sinal",signal_period:"Período do sinal",window:"Período",
    lower:"Limite inferior",upper:"Limite superior",enabled:"Status",direction:"Direção",
    period:"Período da média",mode:"Regra da tendência",slope_lookback:"Intervalo para confirmar a inclinação",
    daily_trend:"Tendência diária",weekly_trend:"Tendência semanal",monthly_trend:"Tendência mensal",
    trend_combination:"Combinação das tendências",adx_min:"ADX mínimo",volume_ratio_min:"Volume mínimo em relação à média",
    rsi_min:"RSI mínimo",rsi_max:"RSI máximo",atr_pct_min:"ATR mínimo",atr_pct_max:"ATR máximo",
    exit_on_filter_failure:"Sair quando um filtro deixar de ser atendido",fundamental_entry:"Fundamentos exigidos para entrada",
    fundamental_exit:"Fundamentos que provocam saída",fundamental_exit_logic:"Combinação das condições de saída",
    fundamental_min_coverage_pct:"Cobertura fundamentalista mínima",fundamental_max_age_days:"Idade máxima dos fundamentos",
    initial_capital:"Capital inicial",fee_pct:"Taxa por operação",slippage_pct:"Slippage estimado",
    risk_free_rate_pct:"Taxa livre de risco",apply_cash_yield:"Remunerar o caixa não investido",
    cash_yield_rate_pct:"Rendimento anual do caixa",fundamental_filters:"Filtros fundamentalistas",
    technical_filters:"Filtros técnicos",mean_total_return_pct:"Retorno total médio",
    mean_cagr_pct:"Retorno anualizado médio (CAGR)",mean_sharpe_ratio:"Índice de Sharpe médio",
    mean_max_drawdown_pct:"Perda máxima média (drawdown)",mean_profit_factor:"Fator de lucro médio",
    mean_win_rate_pct:"Taxa média de acerto",mean_closed_trades:"Média de operações encerradas",
    pe:"P/L",pbv:"P/VP",dividend_yield_pct:"Dividend yield",ev_ebitda:"EV/EBITDA",
    ebit_margin_pct:"Margem EBIT",net_margin_pct:"Margem líquida",current_ratio:"Liquidez corrente",
    roe_pct:"ROE",roic_pct:"ROIC",gross_debt_to_equity:"Dívida bruta / patrimônio",
    net_debt_to_ebitda:"Dívida líquida / EBITDA",revenue_cagr_5y_pct:"Crescimento da receita em 5 anos",
    earnings_cagr_5y_pct:"Crescimento dos lucros em 5 anos",ffo_yield_pct:"FFO yield",
    cap_rate_pct:"Cap rate",vacancy_pct:"Vacância física",financial_vacancy_pct:"Vacância financeira",
    ltv_pct:"LTV",wale_years:"Prazo médio dos contratos (WALE)",daily_liquidity:"Liquidez diária",
    min:"Mínimo",max:"Máximo",
  };
  return labels[key]||String(key||"").replaceAll("_"," ").replace(/^./,letter=>letter.toUpperCase());
}

function readableConfigurationValue(key,value,parentKey="") {
  if(value===null||value===undefined||value==="")return "Não utilizado neste teste";
  if(typeof value==="boolean")return key==="enabled"||key==="apply_cash_yield"?(value?"Ativado":"Desativado"):(value?"Sim":"Não");
  if(typeof value==="number") {
    if(key==="initial_capital")return money(value);
    if(key==="fundamental_max_age_days")return `${number(value,0)} dias`;
    if(["fast","fast_period","fast_window","slow","slow_period","slow_window","signal","signal_period","window","period","slope_lookback"].includes(key))return `${number(value,0)} períodos`;
    if(key==="volume_ratio_min")return `${number(value,2)} × a média`;
    if(String(key).includes("_pct")||String(parentKey).includes("_pct"))return `${number(value,2)}%`;
    return number(value,2);
  }
  const text=String(value);
  const labels={
    up:"Alta",down:"Baixa",none:"Sem filtro",all:"Todas as condições",any:"Qualquer condição",
    majority:"Maioria das condições",price_above:"Preço acima da média móvel",
    sma_rising:"Média móvel simples em alta",price_above_or_sma_rising:"Preço acima da média OU média em alta",
    price_above_and_sma_rising:"Preço acima da média E média em alta",close:"Fechamento",
    low_touch:"Mínima toca a banda",close_reentry:"Fechamento retorna para dentro da banda",
  };
  if(key==="trend_combination")return {all:"Todas as tendências ativas devem concordar",any:"Ao menos uma tendência ativa deve confirmar",majority:"A maioria das tendências ativas deve confirmar"}[text]||readableConfigurationKey(text);
  if(key==="fundamental_exit_logic")return {all:"Todas as condições devem ocorrer",any:"Qualquer condição pode provocar a saída"}[text]||readableConfigurationKey(text);
  return labels[text]||readableConfigurationKey(text);
}

function configurationValue(value,key="",parentKey="") {
  if(Array.isArray(value))return value.length?`<ul class="configuration-list">${value.map(item=>`<li>${configurationValue(item,key,parentKey)}</li>`).join("")}</ul>`:'<span class="muted">Nenhum item configurado.</span>';
  if(value!==null&&typeof value==="object") {
    const nested=Object.entries(value);
    if(!nested.length)return '<span class="muted">Nenhuma condição configurada.</span>';
    return `<dl class="configuration-pairs nested">${nested.map(([nestedKey,nestedValue])=>`<div><dt>${esc(readableConfigurationKey(nestedKey))}</dt><dd>${configurationValue(nestedValue,nestedKey,key||parentKey)}</dd></div>`).join("")}</dl>`;
  }
  return `<span>${esc(readableConfigurationValue(key,value,parentKey))}</span>`;
}

function configurationPairs(values) {
  if(values!==null&&values!==undefined&&typeof values!=="object")return `<p class="configuration-text">${configurationValue(values)}</p>`;
  const entries=Object.entries(values||{});
  if(!entries.length)return '<span class="muted">Nenhuma configuração adicional.</span>';
  return `<dl class="configuration-pairs">${entries.map(([key,value])=>`<div><dt>${esc(readableConfigurationKey(key))}</dt><dd>${configurationValue(value,key)}</dd></div>`).join("")}</dl>`;
}

async function openStudyStrategy(strategyId) {
  const dialog=$("#asset-dialog"),content=$("#asset-dialog-content");
  content.innerHTML=loadingCards(5);dialog.showModal();
  try {
    const data=await api(`/backtests/study/${encodeURIComponent(strategyId)}/configurations`,{cacheTtlMs:60000});
    const configurations=data.items||[];
    content.innerHTML=`<div class="asset-dialog-header"><p class="eyebrow">Estudo de backtests</p><h2 class="asset-title">${esc(data.strategy_name||strategyId)}</h2><p class="asset-subtitle">Todas as configurações oficiais utilizadas nesta estratégia.</p></div>
      <div class="metric-grid">${metricCard("Configurações",number(data.configuration_count||0,0))}${metricCard("Execuções",number(data.run_count||0,0))}${metricCard("Estratégia",esc(strategyId))}</div>
      ${sectionCard("Regras da estratégia",configurationPairs(data.strategy_rules))}
      <div class="study-configurations">${configurations.length?configurations.map(item=>`<details class="study-configuration"><summary><span>Configuração ${number(item.configuration_number,0)}</span><small>${number(item.assets_tested,0)} ativo(s) • nota média ${number(item.mean_ranking_score,1)}</small></summary><div class="study-configuration-body"><div class="study-configuration-grid"><article><h4>Parâmetros da estratégia</h4>${configurationPairs(item.strategy_parameters)}</article><article><h4>Filtros</h4>${configurationPairs(item.filters)}</article><article><h4>Premissas financeiras</h4>${configurationPairs({...item.financial,...item.assumptions})}</article><article><h4>Métricas médias</h4>${configurationPairs(item.mean_metrics)}</article></div><p><strong>Ativos testados:</strong> ${esc((item.tickers||[]).join(", ")||"—")}</p><p><strong>Sinais atuais:</strong> ${esc(Object.entries(item.signal_counts||{}).map(([key,value])=>`${signalLabel(key)}: ${value}`).join(" • ")||"—")}</p></div></details>`).join(""):'<div class="empty-state"><strong>Nenhuma configuração elegível</strong>As configurações aparecerão depois da próxima rodada oficial válida.</div>'}</div>`;
  } catch(error) {content.innerHTML=errorState(error);}
}

const officialStatusLabels = {
  queued:"Na fila", running:"Executando", completed:"Concluído",
  completed_with_errors:"Concluído com avisos", failed:"Falhou", cancelled:"Cancelado",
};

function officialErrorText(item) {
  const code=String(item?.code||"");
  const labels={
    github_worker_failed:"A execução no GitHub foi interrompida antes da conclusão.",
    github_dispatch_failed:"Não foi possível iniciar a nova execução no GitHub.",
    cancelled_by_owner:"A rodada foi cancelada pelo administrador.",
  };
  const stage=String(item?.details?.failure_stage||"");
  if(stage==="prepare_temporary_database") return "O banco temporário da rodada não pôde ser preparado. A correção desta revisão torna a inicialização independente do histórico de migrações da produção.";
  const safe=String(item?.details?.safe_message||"");
  if(safe.includes("HTTP 413")) return "O pacote de resultados ultrapassou o limite de envio. Esta versão passa a entregá-lo em partes menores e repetíveis com segurança.";
  return labels[code]||String(item?.message||item?.error||"Falha não detalhada.");
}

function openOfficialBacktestJob(jobId) {
  const job=state.officialBacktestJobs.get(String(jobId));
  if(!job)return;
  const content=$("#asset-dialog-content"),dialog=$("#asset-dialog");
  const total=Number(job.total_assets||(job.tickers||[]).length||0);
  const processed=Number(job.processed_assets||0);
  const errors=job.errors||[];
  const canRetry=Boolean(state.session?.access?.is_owner&&(job.retry_tickers||[]).length&&["failed","cancelled","completed_with_errors"].includes(job.status));
  content.innerHTML=`<div class="asset-dialog-header"><p class="eyebrow">Rodada oficial</p><h2 class="asset-title">${esc(officialStatusLabels[job.status]||job.status||"—")}</h2><p class="asset-subtitle">${esc(job.id)}</p></div>
    <div class="metric-grid">${metricCard("Ativos concluídos",`${processed} / ${total}`)}${metricCard("Partes recebidas",number(job.received_chunks||0,0))}${metricCard("Execuções concluídas",number(job.completed_runs||0,0))}${metricCard("Execuções com falha",number(job.failed_runs||0,0))}</div>
    ${sectionCard("Andamento",`<p><strong>Início:</strong> ${dateTime(job.started_at||job.created_at)}</p><p><strong>Última atualização:</strong> ${dateTime(job.last_update_at||job.finished_at)}</p><p><strong>Último ativo recebido:</strong> ${esc(job.last_ticker||job.last_chunk_ticker||"—")}${job.last_chunk_count?` • parte ${number(job.last_chunk_index,0)} de ${number(job.last_chunk_count,0)}`:""}</p>`)}
    ${(job.pending_tickers||[]).length?sectionCard("Ativos pendentes",`<p>${esc(job.pending_tickers.join(", "))}</p>`):""}
    ${errors.length?sectionCard("Motivo e orientação",`<div class="notice danger">${errors.map(item=>`<p>${esc(officialErrorText(item))}</p>`).join("")}</div>`):""}
    <div class="dialog-actions">${canRetry?`<button class="button primary" data-retry-official-job="${esc(job.id)}">Reprocessar ativos pendentes ou com falha</button>`:""}<a class="button secondary" href="https://github.com/andrelbr22/invest/actions/workflows/backtests-semanais.yml" target="_blank" rel="noopener">Ver execuções no GitHub</a></div>`;
  dialog.showModal();
}

async function retryOfficialBacktestJob(jobId, button) {
  if(button){button.disabled=true;button.textContent="Solicitando nova execução…";}
  try {
    const result=await api(`/backtests/batch/jobs/${encodeURIComponent(jobId)}/retry`,{method:"POST",body:"{}"});
    $("#asset-dialog").close();
    const destination=result.dispatch?.environment==="production"?"produção":"ambiente de teste";
    toast(`${(result.retry_tickers||result.tickers||[]).length} ativo(s) enviado(s) para nova execução em ${destination}.`,"success");
    await loadBacktests();
  } catch(error) {
    toast(error.message,"error");
    if(button){button.disabled=false;button.textContent="Reprocessar ativos pendentes ou com falha";}
  }
}

const backtestParameterLabels={period:"Período",stddev:"Desvios-padrão",rsi_period:"Período do RSI",entry_rsi:"RSI de entrada",exit_rsi:"RSI de saída",trend_period:"Período da tendência",trend_filter_mode:"Filtro de tendência",trend_slope_lookback:"Janela da inclinação",band_trigger:"Gatilho da banda",fast_period:"Média rápida",slow_period:"Média lenta",fast_type:"Tipo da média rápida",slow_type:"Tipo da média lenta",atr_period:"Período do ATR",multiplier:"Multiplicador",lookback:"Janela de observação",skip_recent:"Pregões recentes ignorados",min_absolute_return_pct:"Retorno absoluto mínimo (%)",min_excess_return_pct:"Excesso sobre benchmark (%)",squeeze_lookback:"Janela do squeeze",squeeze_quantile:"Percentil do squeeze",volume_period:"Período do volume",volume_ratio_min:"Volume / média mínimo"};
const backtestChoiceLabels={sma:"Média simples",ema:"Média exponencial",price_above:"Preço acima/abaixo",sma_rising:"Inclinação da média",price_above_and_sma_rising:"Preço e inclinação",price_above_or_sma_rising:"Preço ou inclinação",none:"Sem filtro",close:"Fechamento",low_touch:"Mínima toca a banda",close_reentry:"Retorno para dentro da banda"};

function renderBacktestStrategyParameters(form){
  const root=form?.querySelector("#backtest-strategy-parameters");if(!root)return;
  const selected=[...form.querySelector('[name="strategy_ids"]').selectedOptions].map(option=>option.value);
  const catalog=state.backtestCatalog?.strategies||[];
  root.innerHTML=selected.map(id=>{
    const strategy=catalog.find(item=>item.id===id),schema=strategy?.parameter_schema||{},defaults=strategy?.default_params||{};
    const fields=Object.entries(schema).map(([key,spec])=>{
      const name=`strategy_param__${id}__${key}`,label=backtestParameterLabels[key]||key,value=defaults[key];
      if(spec.type==="choice")return `<div class="field"><label>${esc(label)}</label><select name="${esc(name)}">${(spec.options||[]).map(option=>`<option value="${esc(option)}" ${String(option)===String(value)?"selected":""}>${esc(backtestChoiceLabels[option]||option)}</option>`).join("")}</select></div>`;
      const step=spec.type==="int"?"1":"0.01";
      return `<div class="field"><label>${esc(label)}</label><input type="number" name="${esc(name)}" min="${esc(spec.min)}" max="${esc(spec.max)}" step="${step}" value="${esc(value)}"></div>`;
    }).join("");
    return `<details class="data-card strategy-parameter-card" open><summary><strong>${esc(strategy?.name||id)}</strong></summary><p class="block-hint">${esc(strategy?.rules||"")}</p>${fields?`<div class="filter-grid compact-grid">${fields}</div>`:'<p class="block-hint">Esta estratégia usa parâmetros fixos e auditados; os filtros técnicos gerais continuam disponíveis abaixo.</p>'}</details>`;
  }).join("")||'<div class="notice info">Selecione uma ou mais estratégias para revisar regras e parâmetros antes do envio.</div>';
}

function collectBacktestStrategyParameters(form,strategyIds){
  const result={};
  strategyIds.forEach(id=>{
    const strategy=(state.backtestCatalog?.strategies||[]).find(item=>item.id===id),params={};
    Object.entries(strategy?.parameter_schema||{}).forEach(([key,spec])=>{
      const input=form.querySelector(`[name="strategy_param__${CSS.escape(id)}__${CSS.escape(key)}"]`);if(!input)return;
      params[key]=spec.type==="choice"?input.value:spec.type==="int"?Number.parseInt(input.value,10):Number(input.value);
    });
    result[id]=params;
  });
  return result;
}

async function loadBacktests() {
  const root=$("#backtests-tab-content"),tab=state.tabs.backtests; root.innerHTML=loadingCards(6);
  try {
    if(tab==="history") {
      const rows=await api("/backtests/runs?limit=100",{requestKey:"backtests",cacheTtlMs:15000});
      rows.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
      root.innerHTML=recordedUpdatePanel("Histórico de backtests",rows[0]?.created_at,"Atualizado sempre que um teste é concluído")+sectionCard("Últimos 100 backtests",marketTable(rows,[{label:"Data e hora",render:r=>dateTime(r.created_at)},{label:"Ativo",render:r=>`<span class="ticker-cell">${esc(r.ticker||"—")}</span>`},{label:"Estratégia",render:r=>esc(r.strategy_name||r.strategy_id||"—")},{label:"Retorno",render:r=>pct(r.metrics?.total_return_pct??r.return_pct,true),className:r=>variationClass(r.metrics?.total_return_pct??r.return_pct)},{label:"Status",render:r=>`<span class="pill">${esc(r.status||"—")}</span>`}]));
    } else if(tab==="study") {
      const data=await api("/backtests/study?limit=5",{cacheTtlMs:60000}); const rows=data.items||data.ranking||[];
      root.innerHTML=recordedUpdatePanel("Estudos oficiais",data.generated_at||data.updated_at,"Recalculado a partir das rodadas oficiais")+sectionCard("Estratégias mais consistentes",marketTable(rows,[{label:"Posição",render:(r)=>`<strong>${esc(r.position||r.rank||"—")}</strong>`},{label:"Estratégia",render:r=>`<button class="table-link" data-study-strategy="${esc(r.strategy_id)}">${esc(r.strategy_name||r.name||r.strategy_id)}</button><small class="block-hint">Abrir configurações</small>`},{label:"Pontuação",render:r=>number(r.study_score??r.score??r.points,1)},{label:"Presença no top 3",render:r=>number(r.top_three_count??r.top3_count,0)},{label:"1º lugares",render:r=>number(r.first_places,0)},{label:"Cobertura",render:r=>pct(r.coverage_pct)}]),"Ranking ponderado por recorrência no top 3, posição, qualidade e cobertura. Clique na estratégia para ver todas as variáveis.");
    } else if(tab==="official") {
      const rows=await api("/backtests/batch/jobs?limit=30",{cacheTtlMs:10000});
      state.officialBacktestJobs=new Map(rows.map(row=>[String(row.id),row]));
      const officialUpdated=rows.map(row=>row.last_update_at||row.finished_at||row.created_at).filter(Boolean).sort().pop();
      root.innerHTML=recordedUpdatePanel("Backtests oficiais",officialUpdated,"Rodada automática aos sábados às 00h01, horário de Brasília")+sectionCard("Rodadas oficiais",marketTable(rows,[{label:"Criado em",render:r=>dateTime(r.created_at)},{label:"Identificador",render:r=>`<button class="table-link" data-official-job="${esc(r.id)}">${esc(String(r.id).slice(0,8))}…</button>`},{label:"Ativos",render:r=>number((r.requested_tickers||r.tickers||[]).length,0)},{label:"Progresso",render:r=>`${number(r.processed_assets||0,0)} / ${number(r.total_assets||(r.requested_tickers||r.tickers||[]).length,0)}`},{label:"Partes",render:r=>number(r.received_chunks||0,0)},{label:"Status",render:r=>`<span class="pill ${r.status==="failed"?"danger":""}">${esc(officialStatusLabels[r.status]||r.status)}</span>`},{label:"",render:r=>`<button class="button ghost compact" data-official-job="${esc(r.id)}">Detalhes</button>`}]),"Em caso de falha, abra Detalhes e use Reprocessar ativos pendentes ou com falha. O sistema não recalcula entregas já concluídas.");
    } else {
      const [catalog,recentJobs]=await Promise.all([api("/backtests/strategies",{cacheTtlMs:300000}),api("/backtests/jobs?limit=5",{cacheTtlMs:10000})]);
      const access=state.session.access;state.backtestCatalog=catalog;
      root.innerHTML=sectionCard("Comparar estratégias",`<form id="backtest-form" class="filter-grid backtest-form">
        <div class="field wide-action"><label>Ativos — separe por vírgula ou espaço</label><textarea name="tickers" required rows="3" placeholder="PETR4, VALE3, BBAS3"></textarea><small>Limite autorizado por análise: ${number(access.backtest_asset_limit||0,0)} ativo(s).</small></div>
        <div class="field"><label>Estratégias (até ${number(access.backtest_strategy_limit||0,0)})</label><select name="strategy_ids" multiple size="7" required>${(catalog.strategies||[]).map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("")}</select><small>Use Ctrl para selecionar mais de uma.</small></div>
        <div id="backtest-strategy-parameters" class="wide-action strategy-parameters"></div>
        <div class="field"><label>Forma de análise</label><select name="execution_mode"><option value="compare">Comparar separadamente</option><option value="combined">Combinar estratégias</option></select><small>A combinação produz uma única posição.</small></div>
        <div class="field" data-combination-rule hidden><label>Regra da combinação</label><select name="combination_rule"><option value="all">Todas confirmam (E)</option><option value="any">Qualquer uma confirma (OU)</option><option value="majority">Maioria confirma</option></select></div>
        <div class="field"><label>Tipo de ativo</label><select name="asset_type"><option value="stock">Ações</option><option value="fii">FIIs</option><option value="etf">ETFs</option><option value="bdr">BDRs</option><option value="future">Futuros</option></select></div>
        <div class="field"><label>Período</label><select name="period">${Object.entries(catalog.periods||{}).map(([id,label])=>`<option value="${esc(id)}" ${id==="5y"?"selected":""}>${esc(label)}</option>`).join("")}<option value="custom">Personalizado</option></select></div>
        <div class="field" data-backtest-custom-date hidden><label>De</label><input type="date" name="start"></div><div class="field" data-backtest-custom-date hidden><label>Até</label><input type="date" name="end"></div>
        <details class="wide-action"><summary>Filtros técnicos de entrada e saída</summary><p class="block-hint">Cada filtro é aplicado sobre o sinal de todas as estratégias selecionadas, sem antecipar dados futuros.</p><div class="filter-grid compact-grid">
          ${["daily","weekly","monthly"].map((prefix,index)=>`<fieldset class="data-card"><legend>${["Tendência diária","Tendência semanal","Tendência mensal"][index]}</legend><label class="check"><input type="checkbox" name="${prefix}_enabled"> Ativar</label><div class="field"><label>Média móvel</label><select name="${prefix}_ma"><option value="sma:8">MMS 8</option><option value="ema:9">MME 9</option><option value="sma:21" selected>MMS 21</option><option value="sma:50">MMS 50</option><option value="sma:200">MMS 200</option></select></div><div class="field"><label>Direção</label><select name="${prefix}_direction"><option value="up">Alta</option><option value="down">Baixa</option></select></div><div class="field"><label>Condição</label><select name="${prefix}_mode"><option value="price_above">Preço acima/abaixo da média</option><option value="sma_rising">Inclinação da média</option><option value="price_above_and_sma_rising">Preço e inclinação confirmam</option><option value="price_above_or_sma_rising">Preço ou inclinação confirma</option></select></div></fieldset>`).join("")}
          <div class="field"><label>Combinação das tendências</label><select name="trend_combination"><option value="all">Todas confirmam</option><option value="majority">Maioria confirma</option><option value="any">Qualquer uma confirma</option></select></div>
          <div class="field"><label>ADX mínimo</label><input type="number" name="adx_min" min="0" max="100" step="0.1" placeholder="Ex.: 20"></div><div class="field"><label>Volume / média mínimo</label><input type="number" name="volume_ratio_min" min="0.1" max="10" step="0.1" placeholder="Ex.: 1,2"></div>
          <div class="field"><label>Período da média de volume</label><select name="volume_period"><option value="9">9 períodos</option><option value="20" selected>20 períodos</option><option value="50">50 períodos</option></select></div><div class="field"><label>Gráfico do volume</label><select name="volume_timeframe"><option value="daily">Diário</option><option value="weekly">Semanal</option><option value="monthly">Mensal</option></select></div>
          <div class="field"><label>RSI mínimo</label><input type="number" name="rsi_min" min="0" max="100" step="0.1"></div><div class="field"><label>RSI máximo</label><input type="number" name="rsi_max" min="0" max="100" step="0.1"></div>
          <div class="field"><label>ATR mínimo (%)</label><input type="number" name="atr_pct_min" min="0" max="100" step="0.1"></div><div class="field"><label>ATR máximo (%)</label><input type="number" name="atr_pct_max" min="0" max="100" step="0.1"></div>
          <div class="field"><label>MACD</label><select name="macd_condition"><option value="any">Sem filtro</option><option value="above">Acima do sinal</option><option value="below">Abaixo do sinal</option><option value="cross_up">Cruzamento para cima</option><option value="cross_down">Cruzamento para baixo</option></select></div>
          <div class="field"><label>Bollinger %B mínimo</label><input type="number" name="bollinger_percent_b_min" min="-5" max="5" step="0.01"></div><div class="field"><label>Bollinger %B máximo</label><input type="number" name="bollinger_percent_b_max" min="-5" max="5" step="0.01"></div>
          <div class="field"><label>Largura Bollinger mínima</label><input type="number" name="bollinger_bandwidth_min" min="0" max="500" step="0.1"></div><div class="field"><label>Largura Bollinger máxima</label><input type="number" name="bollinger_bandwidth_max" min="0" max="500" step="0.1"></div>
          <div class="field"><label>Força relativa mínima (%)</label><input type="number" name="relative_strength_min" min="-200" max="500" step="0.1"></div><div class="field"><label>Janela da força relativa</label><input type="number" name="relative_strength_lookback" min="20" max="504" step="1" value="126"></div>
          <div class="field"><label>Zona de pivô</label><select name="pivot_zone"><option value="any">Sem filtro</option><option value="below_s3">Abaixo de S3</option><option value="s3_s2">S3–S2</option><option value="s2_s1">S2–S1</option><option value="s1_pp">S1–Pivô</option><option value="pp_r1">Pivô–R1</option><option value="r1_r2">R1–R2</option><option value="r2_r3">R2–R3</option><option value="above_r3">Acima de R3</option></select></div><div class="field"><label>Próximo do nível</label><select name="near_pivot_level"><option value="none">Sem filtro</option><option value="s3">S3</option><option value="s2">S2</option><option value="s1">S1</option><option value="pp">Pivô</option><option value="r1">R1</option><option value="r2">R2</option><option value="r3">R3</option></select></div>
          <div class="field"><label>Tolerância ao pivô (%)</label><input type="number" name="pivot_tolerance_pct" min="0" max="20" step="0.1" value="0.5"></div><div class="field"><label>Liquidez diária mínima (R$)</label><input type="number" name="daily_liquidity_min" min="0" step="1000"></div>
          <label class="check wide-action"><input type="checkbox" name="exit_on_filter_failure"> Encerrar a posição quando os filtros deixarem de ser atendidos</label>
        </div></details>
        <details class="wide-action"><summary>Premissas financeiras</summary><div class="filter-grid compact-grid"><div class="field"><label>Capital inicial</label><input type="number" name="initial_capital" min="1" step="100" value="10000"></div><div class="field"><label>Taxa (%)</label><input type="number" name="fee_pct" min="0" max="5" step="0.01" value="0.03"></div><div class="field"><label>Slippage (%)</label><input type="number" name="slippage_pct" min="0" max="5" step="0.01" value="0.05"></div><div class="field"><label>Taxa livre de risco (% a.a.)</label><input type="number" name="risk_free_rate_pct" min="-20" max="100" step="0.1" value="0"></div><label class="check"><input type="checkbox" name="apply_cash_yield"> Remunerar o caixa</label><div class="field"><label>Rendimento do caixa (% a.a.)</label><input type="number" name="cash_yield_rate_pct" min="-99" max="100" step="0.1" value="0"></div></div></details>
        <button class="button primary wide-action" type="submit">Enviar análise para processamento</button>
      </form><div id="backtest-result" style="margin-top:16px"></div>`+((recentJobs||[]).length?`<div style="margin-top:18px">${sectionCard("Execuções recentes",marketTable(recentJobs,[{label:"Solicitado",render:r=>dateTime(r.created_at)},{label:"Progresso",render:r=>`${number(r.progress_current||0,0)} / ${number(r.progress_total||0,0)}`},{label:"Status",render:r=>`<span class="pill">${esc(r.status)}</span>`}]))}</div>`:""),`Cada envio conta como uma análise diária. Limite: ${access.backtest_daily_limit||0} por dia; até ${access.backtest_strategy_limit||0} estratégia(s); intervalo mínimo de ${access.backtest_cooldown_seconds||60} segundos. A tela permanece livre durante o processamento.`);
      renderBacktestStrategyParameters($("#backtest-form"));
    }
  } catch(error) { root.innerHTML=errorState(error,"backtests"); }
}

async function runBacktest(form) {
  const result=$("#backtest-result"); result.innerHTML=loadingCards(4);
  const formData=new FormData(form), values=Object.fromEntries(formData);
  const tickers=String(values.tickers||"").toUpperCase().split(/[\s,;]+/).map(value=>value.trim()).filter(Boolean);
  const strategy_ids=[...form.querySelector('[name="strategy_ids"]').selectedOptions].map(option=>option.value);
  if(!tickers.length||!strategy_ids.length){result.innerHTML=errorState("Informe ao menos um ativo e uma estratégia.");return;}
  try {
    const numberOrNull=name=>values[name]===""||nullable(values[name])?null:Number(values[name]);
    const trend=prefix=>{const [ma_type,period]=String(values[`${prefix}_ma`]||"sma:21").split(":");return {enabled:Boolean(form.querySelector(`[name="${prefix}_enabled"]`)?.checked),direction:values[`${prefix}_direction`]||"up",ma_type,period:Number(period),mode:values[`${prefix}_mode`]||"price_above",slope_lookback:prefix==="daily"?5:prefix==="weekly"?4:3};};
    const filters={daily_trend:trend("daily"),weekly_trend:trend("weekly"),monthly_trend:trend("monthly"),trend_combination:values.trend_combination||"all",adx_min:numberOrNull("adx_min"),volume_ratio_min:numberOrNull("volume_ratio_min"),volume_period:Number(values.volume_period||20),volume_timeframe:values.volume_timeframe||"daily",rsi_min:numberOrNull("rsi_min"),rsi_max:numberOrNull("rsi_max"),atr_pct_min:numberOrNull("atr_pct_min"),atr_pct_max:numberOrNull("atr_pct_max"),macd_condition:values.macd_condition||"any",bollinger_percent_b_min:numberOrNull("bollinger_percent_b_min"),bollinger_percent_b_max:numberOrNull("bollinger_percent_b_max"),bollinger_bandwidth_min:numberOrNull("bollinger_bandwidth_min"),bollinger_bandwidth_max:numberOrNull("bollinger_bandwidth_max"),relative_strength_min:numberOrNull("relative_strength_min"),relative_strength_lookback:Number(values.relative_strength_lookback||126),pivot_zone:values.pivot_zone||"any",near_pivot_level:values.near_pivot_level||"none",pivot_tolerance_pct:Number(values.pivot_tolerance_pct||.5),daily_liquidity_min:numberOrNull("daily_liquidity_min"),exit_on_filter_failure:Boolean(form.querySelector('[name="exit_on_filter_failure"]')?.checked)};
    const strategy_params=collectBacktestStrategyParameters(form,strategy_ids);
    const payload={tickers,strategy_ids,strategy_params,execution_mode:values.execution_mode,combination_rule:values.combination_rule,asset_type:values.asset_type,period:values.period,start:values.period==="custom"&&values.start?`${values.start}T00:00:00Z`:null,end:values.period==="custom"&&values.end?`${values.end}T23:59:59Z`:null,initial_capital:Number(values.initial_capital||10000),fee_pct:Number(values.fee_pct||0),slippage_pct:Number(values.slippage_pct||0),risk_free_rate_pct:Number(values.risk_free_rate_pct||0),apply_cash_yield:form.querySelector('[name="apply_cash_yield"]')?.checked||false,cash_yield_rate_pct:Number(values.cash_yield_rate_pct||0),filters};
    const data=await api("/backtests/matrix",{method:"POST",body:JSON.stringify(payload)});
    result.innerHTML=sectionCard("Análise na fila",`<div class="notice"><strong>Você pode continuar usando o site.</strong><br>O processamento ocorre em segundo plano.</div><progress max="${data.assets_requested}" value="0" style="width:100%;margin-top:14px"></progress><p class="block-hint">Preparando a análise…</p>`);
    toast("Análise enviada. Você pode continuar navegando.","success");
    await watchBacktestJob(data.job_id,result,data);
  } catch(error) { result.innerHTML=errorState(error); }
}

function renderPersonalBacktestResult(job,submission) {
  const data=job.result||{},rows=data.results||[];
  return sectionCard(data.execution_mode==="combined"?"Resultado da combinação":"Resultado comparativo",marketTable(rows,[
    {label:"Ativo",render:r=>`<strong>${esc(r.ticker||r.requested_ticker)}</strong>`},
    {label:"Estratégia",render:r=>esc(r.strategy_name||r.strategy_id)},
    {label:"Ação agora",render:r=>`<span class="pill signal-${esc(r.action_signal?.status||r.current_signal||"neutral")}">${signalLabel(r.action_signal?.status||r.current_signal)}</span>`},
    {label:"Posição",render:r=>esc(r.position_state?.label||({invested:"Comprado",out:"Fora da posição"})[r.position_state?.status]||"—")},
    {label:"Retorno",render:r=>pct(r.total_return_pct,true),className:r=>variationClass(r.total_return_pct)},
    {label:"CAGR",render:r=>pct(r.cagr_pct??r.cagr,true),className:r=>variationClass(r.cagr_pct??r.cagr)},
    {label:"Sharpe",render:r=>number(r.sharpe_ratio??r.sharpe)},
    {label:"Drawdown",render:r=>pct(r.max_drawdown_pct??r.max_drawdown,true)},
  ]),`${data.assets_requested||submission.assets_requested} ativo(s), ${data.strategies_requested||submission.strategies_requested} estratégia(s) • uso diário ${submission.daily_used}/${submission.daily_limit}`)+(data.failures?.length?`<div class="notice" style="margin-top:12px">${data.failures.length} ativo(s) não puderam ser processados nesta rodada.</div>`:"")+`<p style="margin-top:14px"><a class="button secondary" href="${BASE_PATH}/backtests/jobs/${encodeURIComponent(job.id)}/export.csv">Exportar operações em CSV</a></p>`;
}

async function watchBacktestJob(jobId,result,submission) {
  for(let attempt=0;attempt<3600;attempt+=1) {
    if(!result?.isConnected)return;
    const job=await api(`/backtests/jobs/${encodeURIComponent(jobId)}`);
    const total=Math.max(1,Number(job.progress_total||submission.assets_requested||1));
    const current=Math.min(total,Number(job.progress_current||0));
    if(job.status==="succeeded"){
      result.innerHTML=renderPersonalBacktestResult(job,submission);
      toast("Análise concluída e salva no histórico.","success");return;
    }
    if(job.status==="failed"||job.status==="cancelled"){
      result.innerHTML=errorState(`A análise não foi concluída (${job.last_error_code||job.status}).`);return;
    }
    result.innerHTML=sectionCard("Análise em segundo plano",`<progress max="${total}" value="${current}" style="width:100%"></progress><p><strong>${current} de ${total}</strong> ativo(s)</p><p class="block-hint">${esc(job.message||"Processando…")} Você pode continuar usando as outras áreas.</p>`);
    await new Promise(resolve=>setTimeout(resolve,2000));
  }
  result.innerHTML=errorState("O acompanhamento excedeu o tempo desta tela. Consulte o histórico de execuções.");
}

function financeCategoryBars(rows,total) {
  if(!(rows||[]).length)return '<div class="empty-state compact"><strong>Nenhuma despesa neste mês</strong>Os grupos aparecerão à medida que você fizer lançamentos.</div>';
  const maximum=Math.max(...rows.map(row=>Number(row.value||0)),1);
  return `<div class="finance-bars">${rows.map(row=>`<div class="finance-bar-row"><span>${esc(row.category)}</span><div><i style="width:${Math.max(2,Number(row.value||0)/maximum*100)}%"></i></div><strong>${money(row.value)}</strong></div>`).join("")}</div><small>Total previsto e realizado: ${money(total)}</small>`;
}

function financeBudgetTable(rows) {
  return marketTable(rows||[],[
    {label:"Categoria",render:r=>`<strong>${esc(r.category)}</strong>`},
    {label:"Limite",render:r=>money(r.limit_value)},
    {label:"Usado",render:r=>money(r.used_value)},
    {label:"Consumo",render:r=>`<span class="pill ${Number(r.used_pct)>100?"danger":""}">${pct(r.used_pct)}</span>`},
  ]);
}

function financeTransactionTable(rows,canWrite) {
  const statusLabels={planned:"Previsto",paid:"Pago",received:"Recebido",overdue:"Atrasado"};
  return marketTable(rows||[],[
    {label:"Data",render:r=>dateOnly(r.transaction_date)},
    {label:"Descrição",render:r=>`<strong>${esc(r.description)}</strong><br><small>${esc(r.category)}${r.institution?` • ${esc(r.institution)}`:""}</small>`},
    {label:"Tipo",render:r=>r.kind==="income"?"Receita":"Despesa"},
    {label:"Valor",render:r=>money(r.amount),className:r=>r.kind==="income"?"positive":"negative"},
    {label:"Status",render:r=>`<span class="pill ${r.status==="overdue"?"danger":""}">${esc(statusLabels[r.status]||r.status)}</span>`},
    {label:"",render:r=>canWrite?`<span class="row-actions">${["paid","received"].includes(r.status)?"":`<button class="button ghost compact" data-set-finance-status="${esc(r.id)}" data-finance-kind="${esc(r.kind)}">${r.kind==="income"?"Marcar recebido":"Marcar pago"}</button>`}<button class="button ghost compact danger" data-delete-finance="${esc(r.id)}">Arquivar</button></span>`:""},
  ]);
}

async function loadFinances() {
  const root=$("#finances-tab-content"),monthInput=$("#finance-month");
  if(monthInput&&!monthInput.value)monthInput.value=state.financeMonth;
  root.innerHTML=loadingCards(5);
  try {
    const [data,catalog]=await Promise.all([
      api(`/finances/summary?month=${encodeURIComponent(state.financeMonth)}`,{requestKey:"finances",cacheTtlMs:20000}),
      api("/finances/catalog",{cacheTtlMs:300000}),
    ]);
    const access=state.session.access,tab=state.tabs.finances,transactions=data.transactions||[];
    if(tab==="monthly"){
      const expenseTotal=(data.expense_by_category||[]).reduce((sum,row)=>sum+Number(row.value||0),0);
      root.innerHTML=`<div class="metric-grid summary-grid">${metricCard("Receitas recebidas",money(data.realized?.income),"Realizado")}${metricCard("Despesas pagas",money(data.realized?.expense),"Realizado")}${metricCard("Saldo realizado",money(data.realized?.balance),"Entradas menos saídas",data.realized?.balance)}${metricCard("Saldo previsto",money(data.forecast?.balance),"Inclui lançamentos pendentes",data.forecast?.balance)}</div><div class="finance-overview-grid">${sectionCard("Despesas por categoria",financeCategoryBars(data.expense_by_category||[],expenseTotal),`Competência ${state.financeMonth}`)}${sectionCard("Orçamento do mês",(data.budgets||[]).length?financeBudgetTable(data.budgets):'<div class="empty-state compact"><strong>Orçamento ainda não definido</strong>Use a aba Orçamento para criar limites por categoria.</div>')}</div>${sectionCard("Lançamentos mais recentes",financeTransactionTable(transactions.slice(0,8),access.can_write_finances),data.updated_at?`Atualizado em ${dateTime(data.updated_at)}`:"Sem lançamentos")}`;
    }else if(tab==="transactions"){
      const options=(kind)=>(catalog.categories?.[kind]||[]).map(item=>`<option data-finance-category-kind="${kind}" ${kind==="income"?"hidden disabled":""}>${esc(item)}</option>`).join("");
      const form=access.can_write_finances?`<details class="data-card" open><summary><strong>Novo lançamento</strong></summary><form id="finance-transaction-form" class="filter-grid" style="margin-top:16px"><div class="field"><label>Tipo</label><select name="kind"><option value="expense">Despesa</option><option value="income">Receita</option></select></div><div class="field"><label>Categoria</label><select name="category">${options("expense")}${options("income")}</select></div><div class="field"><label>Descrição</label><input name="description" required maxlength="200"></div><div class="field"><label>Valor</label><input name="amount" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Data</label><input name="transaction_date" type="date" value="${new Date().toISOString().slice(0,10)}" required></div><div class="field"><label>Situação</label><select name="status"><option value="planned">Previsto</option><option value="paid" data-finance-status-kind="expense">Pago</option><option value="received" data-finance-status-kind="income" hidden disabled>Recebido</option><option value="overdue">Atrasado</option></select></div><div class="field"><label>Instituição</label><input name="institution" maxlength="120"></div><div class="field"><label>Forma de pagamento</label><input name="payment_method" maxlength="80"></div><div class="field wide-action"><label>Observações</label><textarea name="notes" rows="2"></textarea></div><button class="button primary wide-action" type="submit">Salvar lançamento</button></form></details>`:"";
      root.innerHTML=form+sectionCard("Planilha mensal",financeTransactionTable(transactions,access.can_write_finances),`${transactions.length} lançamento(s) em ${state.financeMonth}`);
    }else{
      const current=new Map((data.budgets||[]).map(row=>[row.category,Number(row.limit_value||0)]));
      const fields=(catalog.categories?.expense||[]).map(category=>`<div class="field"><label>${esc(category)}</label><input type="number" min="0" step="0.01" name="${esc(category)}" value="${current.get(category)||""}" placeholder="Sem limite"></div>`).join("");
      root.innerHTML=`${sectionCard("Acompanhamento",(data.budgets||[]).length?financeBudgetTable(data.budgets):'<div class="empty-state compact">Nenhum limite definido.</div>',"O consumo inclui despesas previstas e pagas")}${access.can_write_finances?`<form id="finance-budget-form" class="data-card filter-grid" style="margin-top:16px">${fields}<button class="button primary wide-action" type="submit">Salvar orçamento de ${esc(state.financeMonth)}</button></form>`:""}`;
    }
  }catch(error){root.innerHTML=errorState(error,"finances");}
}

async function saveFinanceTransaction(form){
  const values=Object.fromEntries(new FormData(form));values.amount=Number(values.amount);values.competence_month=state.financeMonth;
  try{await api("/finances/transactions",{method:"POST",body:JSON.stringify(values)});toast("Lançamento salvo.","success");loadFinances();}
  catch(error){toast(error.message,"error");}
}

async function saveFinanceBudget(form){
  const values={};new FormData(form).forEach((value,key)=>{values[key]=Number(value||0);});
  try{await api("/finances/budgets",{method:"PUT",body:JSON.stringify({competence_month:state.financeMonth,values})});toast("Orçamento atualizado.","success");loadFinances();}
  catch(error){toast(error.message,"error");}
}

async function setFinanceStatus(button){
  const status=button.dataset.financeKind==="income"?"received":"paid";
  try{await api(`/finances/transactions/${encodeURIComponent(button.dataset.setFinanceStatus)}`,{method:"PATCH",body:JSON.stringify({status})});toast("Situação atualizada.","success");loadFinances();}
  catch(error){toast(error.message,"error");}
}

async function archiveFinanceTransaction(button){
  if(!window.confirm("Arquivar este lançamento? O registro continuará preservado no banco."))return;
  try{await api(`/finances/transactions/${encodeURIComponent(button.dataset.deleteFinance)}`,{method:"DELETE"});toast("Lançamento arquivado.","success");loadFinances();}
  catch(error){toast(error.message,"error");}
}

const accessPermissionSections=[
  {title:"Mercado e análises",items:[["can_view_market","Ver Painel de Mercado"],["can_use_advanced_filters","Usar filtros avançados"],["can_use_fdi_analysis","Análise FDI"],["can_use_alb_analysis","Análise ALB"],["can_use_graham_valuation","Número de Graham"],["can_use_dividend_ceiling","Preço-teto por dividendos"],["can_use_relative_valuation","Valuation relativo"],["can_use_economic_valuation","Valor econômico"]]},
  {title:"Carteira, notícias e alertas",items:[["can_view_portfolio","Ver carteiras"],["can_write_portfolio","Editar carteiras"],["can_view_news_insights","Notícias e recomendações"],["can_use_price_alerts","Usar alertas"],["can_alert_price_above","Preço acima"],["can_alert_price_below","Preço abaixo"],["can_alert_change_positive","Variação positiva"],["can_alert_change_negative","Variação negativa"]]},
  {title:"Finanças e backtests",items:[["can_view_finances","Ver finanças"],["can_write_finances","Editar finanças"],["can_view_backtests","Ver backtests"],["can_run_backtests","Executar backtests"],["can_refresh_backtest_signals","Atualizar sinais"],["can_view_backtest_studies","Ver estudos"]]},
  {title:"Administração",items:[["can_sync_market","Atualizar dados e qualidade"],["can_manage_users","Gerenciar usuários e níveis"],["can_manage_portal","Editar página inicial e livros"]]},
];
const accessLimitDefinitions=[
  {key:"custom_filter_limit",label:"Análises personalizadas",values:[0,1,2,3]},
  {key:"alert_asset_limit",label:"Ativos com alertas",values:[0,1,3,5,10]},
  {key:"backtest_asset_limit",label:"Ativos por backtest",values:[0,1,3,5,10]},
  {key:"backtest_strategy_limit",label:"Estratégias combinadas",values:[0,1,2,3,5]},
  {key:"backtest_daily_limit",label:"Backtests por dia",values:[0,1,5,10,20]},
  {key:"backtest_cooldown_seconds",label:"Intervalo mínimo (segundos)",values:[60,120,300,600,1800,3600]},
];
const adminRefreshGroups=[
  {key:"selic_current",section:"Juros e macro",frequency:"06h e 13h"},{key:"selic_focus",section:"Juros e macro",frequency:"Diária, 04h"},{key:"macro",section:"Juros e macro",frequency:"Diária, 04h"},{key:"rates_calendar",section:"Juros e macro",frequency:"06h e 13h"},
  {key:"global_markets",section:"Mercados",frequency:"06h e 13h"},{key:"crypto",section:"Mercados",frequency:"A cada 30 min"},{key:"fx",section:"Mercados",frequency:"A cada 2 horas"},
  {key:"headlines",section:"Notícias e históricos",frequency:"A cada hora"},{key:"comparison",section:"Notícias e históricos",frequency:"Diária, 05h"},
  {key:"catalog",section:"Catálogo e análises",frequency:"Dias úteis, 08h30"},{key:"fundamentals",section:"Catálogo e análises",frequency:"Dias úteis, 19h"},{key:"technical_daily",section:"Catálogo e análises",frequency:"Dias úteis, 18h15"},{key:"technical_intraday",section:"Catálogo e análises",frequency:"Pregão, a cada 15 min"},
  {key:"portfolio_dividends",section:"Eventos oficiais",frequency:"Dias úteis, 07h20 e 19h20"},{key:"cvm_relevant_facts",section:"Eventos oficiais",frequency:"Diária, 07h40"},{key:"official_calendar",section:"Eventos oficiais",frequency:"Diária, 03h20"},{key:"ima_history",section:"Eventos oficiais",frequency:"Dias úteis, 21h30"},
  {key:"alb_monitor",section:"Qualidade",frequency:"Dias úteis, 19h40"},{key:"data_quality",section:"Qualidade",frequency:"Diária, 20h10"},
];

function accessRuleEditor(level,disabled=false){
  const permissions=level.permissions||{},limits=level.limits||{};
  const sections=accessPermissionSections.map((section,index)=>`<details class="permission-section" ${index<2?"open":""}><summary>${esc(section.title)}<span>${section.items.filter(([key])=>permissions[key]).length} liberada(s)</span></summary><div class="permission-matrix">${section.items.map(([key,label])=>`<label class="check"><input type="checkbox" data-level-permission="${key}" ${permissions[key]?"checked":""} ${disabled?"disabled":""}><span>${esc(label)}</span></label>`).join("")}</div></details>`).join("");
  const limitFields=accessLimitDefinitions.map(field=>`<div class="field"><label>${esc(field.label)}</label><select data-level-limit="${field.key}" ${disabled?"disabled":""}>${field.values.map(value=>`<option value="${value}" ${Number(limits[field.key]||0)===value?"selected":""}>${value}</option>`).join("")}</select></div>`).join("");
  return `${sections}<div class="access-limit-grid">${limitFields}</div>`;
}

function accessLevelCard(level){
  const locked=level.slug==="owner";
  return `<details class="access-level-card" data-level-card="${esc(level.slug)}"><summary><span><strong>${esc(level.name)}</strong><small>${esc(level.description||"")}</small></span><span><span class="pill">${number(level.member_count||0,0)} usuário(s)</span>${level.is_active?'<span class="pill">Ativo</span>':'<span class="pill warning">Inativo</span>'}</span></summary><form class="access-level-form" data-access-level-form="${esc(level.slug)}"><div class="access-level-meta"><div class="field"><label>Nome do nível</label><input name="name" maxlength="80" value="${esc(level.name)}" ${locked?"disabled":""}></div><div class="field"><label>Descrição</label><input name="description" maxlength="500" value="${esc(level.description||"")}" ${locked?"disabled":""}></div>${locked?"":`<label class="check access-active"><input name="is_active" type="checkbox" ${level.is_active?"checked":""}> Nível disponível para novas atribuições</label>`}</div>${accessRuleEditor(level,locked)}${locked?'<div class="notice info">O nível do proprietário é permanente e não pode ser reduzido.</div>':'<button class="button primary" type="submit">Salvar regras deste nível</button>'}</form></details>`;
}

async function loadAccessLevels(root){
  const levels=await api("/access/levels",{cacheTtlMs:10000,bypassCache:true});
  root.innerHTML=`<div class="notice info"><strong>Permissões por nível:</strong> altere uma vez aqui e a mudança será aplicada imediatamente a todos os usuários vinculados. Contas antigas só mudam quando você atribuir um nível.</div><div class="access-level-list">${levels.map(accessLevelCard).join("")}</div><details class="data-card create-level-card"><summary><strong>Criar nível adicional</strong></summary><form id="create-access-level-form" class="filter-grid"><div class="field"><label>Identificador interno</label><input name="slug" required pattern="[a-z][a-z0-9_-]{1,31}" placeholder="ex.: parceiro"></div><div class="field"><label>Nome exibido</label><input name="name" required maxlength="80" placeholder="Ex.: Parceiro"></div><div class="field wide-action"><label>Descrição</label><input name="description" maxlength="500"></div><button class="button primary wide-action" type="submit">Criar nível sem permissões</button></form></details>`;
}

function userStatusLabel(status){return ({pending:"Pendente",approved:"Aprovado",blocked:"Bloqueado"})[status]||status;}
async function loadAdminUsers(root){
  const params=new URLSearchParams({limit:"100",offset:String(state.adminUsersOffset)});if(state.adminUsersQuery)params.set("q",state.adminUsersQuery);if(state.adminUsersStatus)params.set("status",state.adminUsersStatus);if(state.adminUsersLevel)params.set("level",state.adminUsersLevel);
  const [payload,levels]=await Promise.all([api(`/access/users/manage?${params}`,{bypassCache:true}),api("/access/levels?include_inactive=true",{cacheTtlMs:10000})]);
  const users=payload.items||[],activeLevels=levels.filter(level=>level.slug!=="owner"&&level.is_active),from=payload.total?payload.offset+1:0,to=Math.min(payload.offset+payload.limit,payload.total);
  const levelOptions=user=>{
    const legacy=!user.access_level_slug?'<option value="legacy" selected disabled>Personalizado legado (preservado)</option>':"";
    const current=levels.find(level=>level.slug===user.access_level_slug);
    const inactive=current&&!current.is_active?`<option value="${esc(current.slug)}" selected disabled>${esc(current.name)} (inativo)</option>`:"";
    return legacy+inactive+activeLevels.map(level=>`<option value="${esc(level.slug)}" ${user.access_level_slug===level.slug?"selected":""}>${esc(level.name)}</option>`).join("");
  };
  const rows=users.map(user=>`<tr data-user-row="${esc(user.email)}" data-current-level="${esc(user.access_level_slug||"legacy")}" data-current-status="${esc(user.status)}"><td>${user.is_owner?"":`<input type="checkbox" data-user-select="${esc(user.email)}" aria-label="Selecionar ${esc(user.email)}">`}</td><td><strong>${esc(user.display_name||user.email)}</strong><br><small>${esc(user.email)}</small></td><td>${user.is_owner?'<span class="pill">Proprietário</span>':`<select data-user-level>${levelOptions(user)}</select><small class="block-hint">${user.access_inheritance?"Herda regras do nível":"Permissões atuais preservadas"}</small>`}</td><td>${user.is_owner?'<span class="pill">Permanente</span>':`<select data-user-status><option value="pending" ${user.status==="pending"?"selected":""}>Pendente</option><option value="approved" ${user.status==="approved"?"selected":""}>Aprovado</option><option value="blocked" ${user.status==="blocked"?"selected":""}>Bloqueado</option></select>`}</td><td>${user.access_overrides&&Object.keys(user.access_overrides).length?`<span class="pill warning">${Object.keys(user.access_overrides).length} ajuste(s)</span><br><button class="button ghost compact" data-clear-user-overrides="${esc(user.email)}">Remover ajustes</button>`:'<span class="pill">Sem exceções</span>'}</td><td>${dateTime(user.last_seen_at)}</td><td>${user.is_owner?"":`<button class="button primary compact" data-save-user-level="${esc(user.email)}">Salvar</button>`}</td></tr>`).join("");
  root.innerHTML=`<form id="admin-user-filter-form" class="admin-user-filters"><div class="field"><label>Buscar</label><input name="q" value="${esc(state.adminUsersQuery)}" placeholder="Nome ou e-mail"></div><div class="field"><label>Nível</label><select name="level"><option value="">Todos</option><option value="legacy" ${state.adminUsersLevel==="legacy"?"selected":""}>Personalizado legado</option>${levels.map(level=>`<option value="${esc(level.slug)}" ${state.adminUsersLevel===level.slug?"selected":""}>${esc(level.name)}</option>`).join("")}</select></div><div class="field"><label>Status</label><select name="status"><option value="">Todos</option>${["pending","approved","blocked"].map(value=>`<option value="${value}" ${state.adminUsersStatus===value?"selected":""}>${userStatusLabel(value)}</option>`).join("")}</select></div><button class="button secondary" type="submit">Filtrar</button></form><div class="bulk-access-bar"><span><strong>Atribuição em lote</strong><small>Marque usuários desta página</small></span><select id="bulk-access-level">${activeLevels.map(level=>`<option value="${esc(level.slug)}">${esc(level.name)}</option>`).join("")}</select><button class="button secondary" data-bulk-assign-level>Atribuir nível</button></div>${sectionCard("Usuários",`<div class="table-scroll"><table class="admin-users-table"><thead><tr><th></th><th>Usuário</th><th>Nível de acesso</th><th>Status individual</th><th>Exceções</th><th>Último acesso</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="7"><div class="empty-state compact">Nenhum usuário encontrado.</div></td></tr>'}</tbody></table></div>`,`Exibindo ${from}–${to} de ${payload.total} usuário(s)`)}<div class="pagination"><button class="button ghost" data-admin-users-page="prev" ${payload.offset<=0?"disabled":""}>Anterior</button><span>Página ${Math.floor(payload.offset/payload.limit)+1}</span><button class="button ghost" data-admin-users-page="next" ${to>=payload.total?"disabled":""}>Próxima</button></div>`;
}

function adminUpdateTable(updates){
  return marketTable(adminRefreshGroups.map(item=>({...item,...(updates[item.key]||{})})),[
    {label:"Atualização",render:r=>`<strong>${esc(r.label||r.key)}</strong><br><small>${esc(r.section)} • ${esc(r.frequency)}</small>`},
    {label:"Fonte",render:r=>esc(r.source||"—")},
    {label:"Status",render:r=>`<span class="pill ${["failed","stale","partial"].includes(r.status)?"warning":""}">${esc(updateStatusLabels[r.status]||r.status||"Aguardando")}</span>${r.last_error_code?`<br><small>${esc(r.last_error_code)}</small>`:""}`},
    {label:"Última atualização",render:r=>dateTime(r.last_updated_at)},
    {label:"Próxima",render:r=>dateTime(r.next_update_at)},
    {label:"",render:r=>`<button class="button secondary compact" data-refresh-groups="${esc(r.key)}" ${["queued","running"].includes(r.status)?"disabled":""}>Atualizar</button>`},
  ]);
}

async function loadAdminUpdates(root){
  const [summary,updatePayload]=await Promise.all([api("/data/catalog-summary"),api("/market-dashboard/updates",{bypassCache:true})]);
  const updates=updatePayload.updates||{};state.marketEnvelope=state.marketEnvelope||{};state.marketEnvelope.updates={...(state.marketEnvelope.updates||{}),...updates};
  const counts=summary.counts||{},groups=summary.groups||{},allKeys=adminRefreshGroups.map(item=>item.key);
  const grouped=[
    ["Juros, inflação e agenda",["selic_current","selic_focus","macro","rates_calendar"]],
    ["Mercados, criptos e câmbio",["global_markets","crypto","fx"]],
    ["Notícias e comparador histórico",["headlines","comparison"]],
    ["Catálogo, fundamentos e técnica",["catalog","fundamentals","technical_daily","technical_intraday"]],
    ["Proventos, CVM, agenda e índices ANBIMA",["portfolio_dividends","cvm_relevant_facts","official_calendar","ima_history"]],
    ["Qualidade e filtro ALB",["alb_monitor","data_quality"]],
  ];
  root.innerHTML=`<div class="metric-grid">${metricCard("Ações",number(groups.stock||0,0),"Ativos ativos")}${metricCard("FIIs",number(groups.fii||0,0),"Fundos imobiliários")}${metricCard("ETFs",number(counts.etf||0,0),"Fundos de índice")}${metricCard("BDRs",number(counts.bdr||0,0),"Recibos negociados na B3")}</div><div class="admin-update-actions"><button class="button secondary" data-refresh-groups="catalog">Atualizar catálogo</button><button class="button secondary" data-refresh-groups="fundamentals">Atualizar fundamentos e notas</button>${grouped.map(([label,keys])=>`<button class="button secondary" data-refresh-groups="${keys.join(",")}">${esc(label)}</button>`).join("")}<button class="button primary" data-refresh-groups="${allKeys.join(",")}" data-confirm-all-updates>Atualizar todas as ${allKeys.length} rotinas</button></div>${sectionCard("Todas as atualizações automáticas",adminUpdateTable(updates),"As solicitações entram na fila e não bloqueiam o site")}${sectionCard("Monitor de alertas",`<div class="admin-monitor-row"><span><strong>B3: 5 minutos no pregão</strong><small>Demais mercados: 30 minutos, continuamente</small></span><button class="button secondary" data-run-alert-monitor>Executar verificação agora</button></div><div id="alert-monitor-result" class="notice info hidden"></div>`,`A execução manual respeita as mesmas regras e não envia alertas duplicados`)}`;
}

const jobTypeLabels={market_group_refresh:"Mercado e economia",economy_headlines_refresh:"Manchetes",historical_comparison_refresh:"Comparador histórico",market_catalog_refresh:"Catálogo",market_fundamentals_refresh:"Fundamentos",market_technicals_refresh:"Indicadores técnicos",market_intraday_refresh:"Cotações intradiárias",portfolio_prices_refresh:"Preços de carteira",user_news_refresh:"Notícias do usuário",personal_backtest_matrix:"Backtest pessoal",investor_dividends_refresh:"Proventos oficiais",cvm_relevant_facts_refresh:"Fatos relevantes CVM",official_calendar_refresh:"Agenda oficial",anbima_ima_history_refresh:"Histórico IMA-B/IRF-M",alb_universe_monitor:"Monitor do filtro ALB",data_quality_refresh:"Qualidade dos dados",noop:"Verificação interna"};
function jobStatusLabel(status){return ({queued:"Na fila",running:"Executando",succeeded:"Concluído",failed:"Falhou",cancelled:"Cancelado"})[status]||status;}
async function loadAdminJobs(root){
  const jobs=await api("/admin/jobs?limit=100",{bypassCache:true});
  const table=marketTable(jobs,[{label:"Trabalho",render:r=>`<strong>${esc(jobTypeLabels[r.job_type]||r.job_type)}</strong><br><small>${esc(r.id)}</small>`},{label:"Status",render:r=>`<span class="pill ${r.status==="failed"?"danger":r.status==="running"?"warning":""}">${esc(jobStatusLabel(r.status))}</span>`},{label:"Progresso",render:r=>r.progress_total?`${number(r.progress_current||0,0)} / ${number(r.progress_total,0)}`:"—"},{label:"Tentativas",render:r=>`${number(r.attempts||0,0)} / ${number(r.max_attempts||0,0)}`},{label:"Solicitado por",render:r=>esc(r.requested_by||"Sistema")},{label:"Atualização",render:r=>dateTime(r.updated_at)},{label:"Mensagem",render:r=>`${esc(r.message||"—")}${r.last_error_code?`<br><small>${esc(r.last_error_code)}</small>`:""}`},{label:"",render:r=>["failed","cancelled"].includes(r.status)?`<button class="button secondary compact" data-retry-admin-job="${esc(r.id)}">Reprocessar</button>`:""}]);
  root.innerHTML=`<div class="admin-monitor-row"><span><strong>Fila de trabalhos em segundo plano</strong><small>Atualizações de mercado, notícias, carteiras e backtests sem travar a navegação.</small></span><button class="button secondary" data-reload-admin-jobs>Atualizar lista</button></div>${sectionCard("100 trabalhos mais recentes",table,"Falhas podem ser reprocessadas; trabalhos ativos nunca são duplicados")}`;
}

function bytesLabel(value){
  const amount=Number(value);if(!Number.isFinite(amount)||amount<0)return "—";
  const units=["B","KB","MB","GB","TB"];let index=0,current=amount;
  while(current>=1024&&index<units.length-1){current/=1024;index+=1;}
  return `${number(current,current>=10||index===0?0:1)} ${units[index]}`;
}

function operationsResourceCards(resources){
  const item=(label,data)=>metricCard(label,nullable(data?.used_pct)?"—":`${number(data.used_pct,1)}%`,`${bytesLabel(data?.used_bytes)} de ${bytesLabel(data?.total_bytes)}`);
  return `<div class="metric-grid operations-resources">${item("Memória do contêiner",resources?.container_memory?.used_pct===null?resources?.memory:resources?.container_memory)}${item("Memória da máquina",resources?.memory)}${item("Swap",resources?.swap)}${item("Disco",resources?.disk)}</div>`;
}

async function loadAdminOperations(root){
  const payload=await api("/admin/operations",{bypassCache:true});
  const severityLabel={healthy:"Operacional",warning:"Atenção",critical:"Crítico"};
  const serviceRoleLabel={worker:"Processamento em segundo plano",web:"Aplicação web"};
  const routeLabel={health:"Saúde e disponibilidade",dashboard:"Painel de Mercado",screener_50:"Filtro com até 50 ativos",screener_100:"Filtro com até 100 ativos",asset_detail:"Detalhe do ativo"};
  const leaseLabel={"background-scheduler":"Agendador automático","price-alert-monitor-leader":"Monitor de alertas","price-alert-monitor-cycle":"Ciclo de verificação dos alertas"};
  const services=marketTable(payload.services||[],[
    {label:"Serviço",render:r=>`<strong>${esc(serviceRoleLabel[r.role]||r.role)}</strong><br><small>${esc(r.node_id)}</small>`},
    {label:"Ambiente",render:r=>esc(r.environment)},
    {label:"Versão",render:r=>`${esc(r.version)}${r.commit_sha?`<br><small>${esc(String(r.commit_sha).slice(0,10))}</small>`:""}`},
    {label:"Heartbeat",render:r=>`${dateTime(r.last_seen_at)}<br><small>há ${number(r.age_seconds,0)} s</small>`},
    {label:"Agendador",render:r=>r.scheduler_leader?'<span class="pill">Líder</span>':'<span class="pill warning">Espera</span>'},
    {label:"Alertas",render:r=>r.alert_monitor_leader?'<span class="pill">Líder</span>':'<span class="pill warning">Espera</span>'},
  ]);
  const latencies=marketTable(payload.route_metrics?.categories||[],[
    {label:"Rota medida",render:r=>`<strong>${esc(routeLabel[r.key]||r.key)}</strong><br><small>${number(r.count,0)} amostras</small>`},
    {label:"p50",render:r=>nullable(r.p50_ms)?"—":`${number(r.p50_ms,0)} ms`},
    {label:"p95",render:r=>nullable(r.p95_ms)?"—":`${number(r.p95_ms,0)} ms`},
    {label:"Máximo",render:r=>nullable(r.max_ms)?"—":`${number(r.max_ms,0)} ms`},
    {label:"Meta p95",render:r=>nullable(r.target_p95_ms)?"—":`${number(r.target_p95_ms,0)} ms`},
    {label:"Situação",render:r=>!r.sample_sufficient?'<span class="pill warning">Coletando</span>':r.within_target?'<span class="pill">Dentro da meta</span>':'<span class="pill danger">Acima da meta</span>'},
  ]);
  const openIncidents=(payload.incidents||[]).filter(item=>item.status==="open");
  const incidents=marketTable(openIncidents,[
    {label:"Gravidade",render:r=>`<span class="pill ${r.severity==="critical"?"danger":"warning"}">${r.severity==="critical"?"Crítico":"Atenção"}</span>`},
    {label:"Ocorrência",render:r=>`<strong>${esc(r.title)}</strong><br><small>${esc(r.code)}</small>`},
    {label:"Detalhe",render:r=>esc(r.message)},
    {label:"Desde",render:r=>dateTime(r.first_seen_at)},
    {label:"Última detecção",render:r=>dateTime(r.last_seen_at)},
  ]);
  const leaders=(payload.leases||[]).map(item=>`<span class="operations-lease"><strong>${esc(leaseLabel[item.lease_name]||item.lease_name)}</strong><small>${esc(item.holder_id)} • até ${dateTime(item.expires_at)}</small></span>`).join("")||'<span class="empty-state compact">Nenhuma liderança ativa registrada.</span>';
  root.innerHTML=`<div class="admin-monitor-row operations-summary ${esc(payload.status)}"><span><strong>Saúde operacional: ${esc(severityLabel[payload.status]||payload.status)}</strong><small>Leitura de ${dateTime(payload.generated_at)} • ${openIncidents.length} ocorrência(s) aberta(s)</small></span><button class="button secondary" data-reload-admin-operations>Atualizar diagnóstico</button></div><div class="metric-grid">${metricCard("Worker",payload.worker_health?.status==="ok"?"Ativo":"Indisponível",payload.worker_health?.last_seen_at?`Último sinal ${dateTime(payload.worker_health.last_seen_at)}`:"Sem heartbeat")}${metricCard("Na fila",number(payload.queue?.queued||0,0),`Mais antigo: ${number(payload.queue?.oldest_due_minutes||0,0)} min`)}${metricCard("Em execução",number(payload.queue?.running||0,0),`${number(payload.queue?.stale_running||0,0)} sem heartbeat`)}${metricCard("Ocorrências",number(openIncidents.length,0),openIncidents.some(i=>i.severity==="critical")?"Há item crítico":"Sem item crítico")}</div>${operationsResourceCards(payload.resources)}${sectionCard("Serviços e liderança",services,"O esperado é um único líder para o agendador e um único líder para o monitor de alertas")}${sectionCard("Leases distribuídas",`<div class="operations-leases">${leaders}</div>`,`A liderança expira automaticamente se uma VM deixar de responder`) }${sectionCard("Tempo de resposta p50/p95",latencies,`Janela de até ${number(payload.route_metrics?.window_size||0,0)} medições desde ${dateTime(payload.route_metrics?.since)}`)}${sectionCard("Ocorrências abertas",incidents||'<div class="empty-state compact"><strong>Nenhuma ocorrência aberta.</strong>Os limites monitorados estão normais.</div>',"Fila parada, falhas repetidas, dados vencidos, memória, swap, disco e latência")}`;
}

function dataQualityStatus(value){return ({updated:"Atualizado",partial:"Cobertura parcial",stale:"Desatualizado",unavailable:"Indisponível",failed:"Falhou",queued:"Na fila",running:"Atualizando"})[value]||value||"Aguardando";}
function dataQualityClass(value){return ["failed","unavailable"].includes(value)?"danger":["partial","stale"].includes(value)?"warning":"";}

async function loadAdminQuality(root){
  const payload=await api("/admin/data-quality",{bypassCache:true});
  const summary=payload.summary||{},alb=payload.alb||null,rows=payload.sources||[];
  const sourceRows=marketTable(rows,[
    {label:"Conjunto de dados",render:r=>`<strong>${esc(r.label||r.key)}</strong><br><small>${esc(r.category||"")}</small>`},
    {label:"Fonte",render:r=>r.source_url?`<a href="${esc(safeExternalUrl(r.source_url))}" target="_blank" rel="noopener noreferrer">${esc(r.source||"Fonte oficial")}</a>`:esc(r.source||"—")},
    {label:"Situação",render:r=>`<span class="pill ${dataQualityClass(r.status)}">${esc(dataQualityStatus(r.status))}</span>${r.last_error_code?`<br><small>${esc(r.last_error_code)}</small>`:""}`},
    {label:"Cobertura",render:r=>nullable(r.coverage_pct)?(nullable(r.item_count)?"—":`${number(r.item_count,0)} item(ns)`):`${pct(r.coverage_pct)}<br><small>${number(r.item_count,0)} de ${number(r.total_items,0)}</small>`},
    {label:"Última atualização",render:r=>dateTime(r.last_updated_at)},
    {label:"Próxima",render:r=>dateTime(r.next_update_at)},
  ]);
  const albBody=alb?`<div class="metric-grid summary-grid">${metricCard("Ativos no ALB",number(alb.asset_count,0),`Faixa esperada: ${number(alb.target_min,0)} a ${number(alb.target_max,0)}`)}${metricCard("Situação",alb.status==="within_range"?"Dentro da faixa":"Requer atenção","Critérios nunca são afrouxados automaticamente")}${metricCard("Referência",dateOnly(alb.reference_date),`Preset ${alb.preset_version||"—"}`)}</div>${(alb.tickers||[]).length?`<div class="tag-list">${alb.tickers.map(item=>`<span>${esc(item)}</span>`).join("")}</div>`:""}`:'<div class="empty-state compact"><strong>Primeira medição pendente</strong>O monitor será executado pela rotina diária, sem alterar o preset ALB.</div>';
  root.innerHTML=`<div class="admin-monitor-row operations-summary ${esc(payload.status)}"><span><strong>Qualidade dos dados: ${payload.status==="ok"?"normal":payload.status==="critical"?"crítica":"atenção"}</strong><small>Leitura em ${dateTime(payload.generated_at)} • somente metadados persistidos, sem bloquear o site</small></span><button class="button secondary" data-reload-admin-quality>Atualizar diagnóstico</button></div><div class="metric-grid">${metricCard("Fontes monitoradas",number(summary.total||0,0),"Séries, snapshots e cobertura por ativo")}${metricCard("Atualizadas",number(summary.updated||0,0),"Dentro do prazo esperado")}${metricCard("Parciais",number(summary.partial||0,0),"Cobertura abaixo de 80%")}${metricCard("Vencidas ou indisponíveis",number((summary.stale||0)+(summary.unavailable_or_failed||0),0),"Exigem atualização ou revisão")}</div>${sectionCard("Filtro ALB — controle diário",albBody,"A faixa esperada é de 5 a 20 ativos; um alerta operacional é aberto fora dela")}${sectionCard("Cobertura, frescor e proveniência",sourceRows,"Cada linha informa a fonte, a última atualização e eventuais falhas")}`;
}

function portalField(content,path,label,{textarea=false,wide=false,list=false}={}){
  const parts=path.split(".");let value=content;for(const part of parts)value=value?.[part];
  if(list)value=(value||[]).join("\n");
  const control=textarea?`<textarea rows="${wide?4:2}" data-portal-page-field="${esc(path)}" ${list?'data-portal-list="true"':""}>${esc(value||"")}</textarea>`:`<input data-portal-page-field="${esc(path)}" value="${esc(value||"")}">`;
  return `<div class="field ${wide?"wide-action":""}"><label>${esc(label)}</label>${control}</div>`;
}

function portalPageEditor(payload){
  const content=payload.content||{},purpose=content.purpose?.items||[];
  return `<form id="portal-page-form" class="portal-admin-sections" data-portal-revision="${Number(payload.revision||1)}">
    <details class="data-card" open><summary><strong>Título, marca e navegação</strong></summary><div class="filter-grid portal-edit-grid">
      ${portalField(content,"meta.title","Título da janela",{wide:true})}${portalField(content,"meta.description","Descrição para buscadores",{textarea:true,wide:true})}
      ${portalField(content,"brand.monogram","Monograma da marca")}${portalField(content,"brand.primary","Marca — linha principal")}${portalField(content,"brand.secondary","Marca — linha secundária")}
      ${portalField(content,"navigation.skip","Atalho de acessibilidade")}${portalField(content,"navigation.books","Menu dos livros")}${portalField(content,"navigation.purpose","Menu da proposta")}${portalField(content,"navigation.platform","Menu da plataforma")}${portalField(content,"navigation.admin","Link de ajustes")}
    </div></details>
    <details class="data-card"><summary><strong>Abertura da página</strong></summary><div class="filter-grid portal-edit-grid">
      ${portalField(content,"hero.eyebrow","Chamada curta")}${portalField(content,"hero.title","Título principal",{wide:true})}${portalField(content,"hero.intro","Texto de apresentação",{textarea:true,wide:true})}
      ${portalField(content,"hero.primary_action","Botão da plataforma")}${portalField(content,"hero.secondary_action","Botão dos livros")}${portalField(content,"hero.proof","Temas — um por linha",{textarea:true,wide:true,list:true})}
      ${portalField(content,"hero.collection_title","Título da coleção")}${portalField(content,"hero.collection_subtitle","Subtítulo da coleção")}
    </div></details>
    <details class="data-card"><summary><strong>Nossa proposta</strong></summary><div class="filter-grid portal-edit-grid">
      ${portalField(content,"purpose.eyebrow","Chamada curta")}${portalField(content,"purpose.title","Título",{wide:true})}
      ${purpose.map((item,index)=>`<fieldset class="portal-purpose-item wide-action"><legend>Bloco ${index+1}</legend><div class="field"><label>Número</label><input data-portal-purpose="${index}" data-portal-purpose-field="number" value="${esc(item.number)}"></div><div class="field"><label>Título</label><input data-portal-purpose="${index}" data-portal-purpose-field="title" value="${esc(item.title)}"></div><div class="field wide-action"><label>Texto</label><textarea rows="2" data-portal-purpose="${index}" data-portal-purpose-field="body">${esc(item.body)}</textarea></div></fieldset>`).join("")}
    </div></details>
    <details class="data-card"><summary><strong>Biblioteca e coleções</strong></summary><div class="filter-grid portal-edit-grid">
      ${portalField(content,"books.eyebrow","Chamada curta")}${portalField(content,"books.title","Título da biblioteca",{wide:true})}${portalField(content,"books.intro","Apresentação",{textarea:true,wide:true})}
      ${portalField(content,"books.primary_title","Coleção principal")}${portalField(content,"books.primary_subtitle","Subtítulo principal")}${portalField(content,"books.complementary_title","Coleção complementar")}${portalField(content,"books.complementary_subtitle","Subtítulo complementar")}${portalField(content,"books.details_label","Texto de abrir descrição")}
    </div></details>
    <details class="data-card"><summary><strong>Convite para a plataforma e rodapé</strong></summary><div class="filter-grid portal-edit-grid">
      ${portalField(content,"platform.eyebrow","Chamada curta")}${portalField(content,"platform.title","Título",{wide:true})}${portalField(content,"platform.body","Texto",{textarea:true,wide:true})}${portalField(content,"platform.button","Botão")}
      ${portalField(content,"footer.disclaimer","Aviso do rodapé",{textarea:true,wide:true})}${portalField(content,"footer.platform","Link da plataforma")}
    </div></details>
    <div class="portal-sticky-action"><span>Última alteração: ${dateTime(payload.updated_at)} por ${esc(payload.updated_by||"sistema")}</span><button class="button primary" type="submit">Salvar textos da página</button></div>
  </form>`;
}

function portalCoverUrl(book){return book.cover_media_id?`${BASE_PATH}/portal-media/${encodeURIComponent(book.cover_media_id)}`:`${BASE_PATH}${book.fallback_cover_path||"/portal-assets/books/formacao-investidor-fundamentos.webp"}`;}
function portalBookForm(book,index,total){
  const links=[...(book.sales_links||[])];while(links.length<3)links.push({label:"",url:""});
  const isNew=!book.id;
  return `<details class="access-level-card portal-book-card" data-portal-book-card="${esc(book.id||"new")}" ${isNew?"open":""}><summary><span><strong>${esc(book.title||"Adicionar novo livro")}</strong><small>${isNew?"Cadastre a obra, a capa e os links de venda":`${book.collection==="primary"?"Coleção principal":"Obra complementar"} • ${book.is_published?"Publicado":"Oculto"}`}</small></span>${isNew?"":`<img class="portal-book-thumb" src="${esc(portalCoverUrl(book))}" alt="">`}</summary><form class="portal-book-form filter-grid" data-portal-book-form="${esc(book.id||"")}">
    <div class="field"><label>Título</label><input name="title" required maxlength="255" value="${esc(book.title||"")}"></div><div class="field"><label>Identificador</label><input name="slug" required pattern="[a-z0-9]+(?:-[a-z0-9]+)*" value="${esc(book.slug||"")}" placeholder="nome-do-livro"></div>
    <div class="field"><label>Coleção</label><select name="collection"><option value="primary" ${book.collection==="primary"?"selected":""}>Coleção principal</option><option value="complementary" ${book.collection!=="primary"?"selected":""}>Obras complementares</option></select></div><div class="field"><label>Chamada curta</label><input name="kicker" maxlength="180" value="${esc(book.kicker||"")}"></div>
    <div class="field wide-action"><label>Resumo exibido</label><textarea name="summary" rows="2" maxlength="1500">${esc(book.summary||"")}</textarea></div><div class="field wide-action"><label>Descrição completa</label><textarea name="description" rows="3" maxlength="5000">${esc(book.description||"")}</textarea></div>
    <div class="field"><label>Descrição acessível da capa</label><input name="alt_text" required maxlength="500" value="${esc(book.alt_text||"")}"></div><div class="field"><label>Nova capa (PNG, JPG ou WebP; até 4 MB)</label><input name="cover_file" type="file" accept="image/png,image/jpeg,image/webp"></div>
    <div class="field"><label>Destaque no topo</label><select name="hero_position"><option value="">Não destacar</option>${[1,2,3].map(value=>`<option value="${value}" ${Number(book.hero_position)===value?"selected":""}>Posição ${value}</option>`).join("")}</select></div><label class="check portal-book-published"><input name="is_published" type="checkbox" ${book.is_published!==false?"checked":""}> Livro visível na página</label>
    <fieldset class="portal-sales-fieldset wide-action"><legend>Links de venda — até três</legend>${links.map((link,position)=>`<div class="portal-sales-row"><div class="field"><label>Descrição ${position+1}</label><input name="sales_label_${position}" maxlength="100" value="${esc(link.label||"")}" placeholder="Ex.: Comprar na Amazon"></div><div class="field"><label>Link HTTPS ${position+1}</label><input name="sales_url_${position}" type="url" value="${esc(link.url||"")}" placeholder="https://..."></div></div>`).join("")}</fieldset>
    <div class="portal-book-actions wide-action">${isNew?"":`<button type="button" class="button ghost" data-portal-book-move="up" data-portal-book-id="${esc(book.id)}" ${index===0?"disabled":""}>Subir</button><button type="button" class="button ghost" data-portal-book-move="down" data-portal-book-id="${esc(book.id)}" ${index===total-1?"disabled":""}>Descer</button><button type="button" class="button ghost danger" data-portal-book-delete="${esc(book.id)}">Excluir</button>`}<button class="button primary" type="submit">${isNew?"Adicionar livro":"Salvar livro"}</button></div>
  </form></details>`;
}

async function loadAdminPortal(root){
  const payload=await api("/admin/portal",{bypassCache:true});state.portalAdmin=payload;
  const books=payload.books||[];
  root.innerHTML=`<div class="notice info"><strong>Publicação segura:</strong> as alterações salvas aparecem na página inicial sem substituir a plataforma. Se o banco ficar indisponível, a versão estática atual permanece como reserva.</div>${sectionCard("Textos da página inicial",portalPageEditor(payload),"Edite os campos e salve ao final")}${sectionCard("Livros publicados e futuros",`<div class="portal-book-list">${books.map((book,index)=>portalBookForm(book,index,books.length)).join("")}</div>${portalBookForm({collection:"complementary",is_published:true,sales_links:[]},books.length,books.length+1)}`,`${books.length} livro(s) cadastrado(s); capas aceitas em PNG, JPG e WebP`)}`;
}

function setPortalPageValue(target,path,value){const parts=path.split(".");let cursor=target;parts.slice(0,-1).forEach(part=>cursor=cursor[part]);cursor[parts.at(-1)]=value;}
async function savePortalPage(form){
  const content=JSON.parse(JSON.stringify(state.portalAdmin.content||{}));
  form.querySelectorAll("[data-portal-page-field]").forEach(input=>setPortalPageValue(content,input.dataset.portalPageField,input.dataset.portalList?input.value.split(/\r?\n/).map(value=>value.trim()).filter(Boolean):input.value));
  form.querySelectorAll("[data-portal-purpose]").forEach(input=>{content.purpose.items[Number(input.dataset.portalPurpose)][input.dataset.portalPurposeField]=input.value;});
  const button=form.querySelector('button[type="submit"]');button.disabled=true;
  try{await api("/admin/portal/page",{method:"PUT",body:JSON.stringify({patch:content,expected_revision:Number(form.dataset.portalRevision)})});toast("Textos da página inicial atualizados.","success");await loadAdmin();}
  catch(error){toast(error.message,"error");button.disabled=false;}
}

function readPortalFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error("Não foi possível ler a imagem selecionada."));reader.readAsDataURL(file);});}
async function portalBookPayload(form){
  const values={title:form.elements.title.value,slug:form.elements.slug.value.trim().toLowerCase(),collection:form.elements.collection.value,kicker:form.elements.kicker.value,summary:form.elements.summary.value,description:form.elements.description.value,alt_text:form.elements.alt_text.value,hero_position:form.elements.hero_position.value||null,is_published:form.elements.is_published.checked};
  const file=form.elements.cover_file.files?.[0];if(file){if(file.size>4*1024*1024)throw new Error("A capa deve ter no máximo 4 MB.");const media=await api("/admin/portal/media",{method:"POST",body:JSON.stringify({filename:file.name,data_url:await readPortalFile(file)})});values.cover_media_id=media.id;}
  const sales_links=[];for(let index=0;index<3;index+=1){const label=form.elements[`sales_label_${index}`].value.trim(),url=form.elements[`sales_url_${index}`].value.trim();if(label||url){if(!label||!url)throw new Error(`Preencha a descrição e o link de venda ${index+1}.`);sales_links.push({label,url});}}
  return {values,sales_links};
}

async function savePortalBook(form){
  const button=form.querySelector('button[type="submit"]');button.disabled=true;
  try{const payload=await portalBookPayload(form),id=form.dataset.portalBookForm;await api(id?`/admin/portal/books/${encodeURIComponent(id)}`:"/admin/portal/books",{method:id?"PUT":"POST",body:JSON.stringify(payload)});toast(id?"Livro atualizado.":"Livro adicionado.","success");await loadAdmin();}
  catch(error){toast(error.message,"error");button.disabled=false;}
}

async function deletePortalBook(id){if(!window.confirm("Excluir este livro e seus links da página inicial? A capa será removida apenas se nenhum outro livro a utilizar."))return;try{await api(`/admin/portal/books/${encodeURIComponent(id)}`,{method:"DELETE"});toast("Livro excluído.","success");await loadAdmin();}catch(error){toast(error.message,"error");}}
async function movePortalBook(id,direction){const books=[...(state.portalAdmin?.books||[])],index=books.findIndex(book=>book.id===id),target=index+(direction==="up"?-1:1);if(index<0||target<0||target>=books.length)return;[books[index],books[target]]=[books[target],books[index]];try{await api("/admin/portal/books/order",{method:"PUT",body:JSON.stringify({ordered_ids:books.map(book=>book.id)})});toast("Ordem dos livros atualizada.","success");await loadAdmin();}catch(error){toast(error.message,"error");}}

async function loadAdmin() {
  const root=$("#admin-tab-content"); root.innerHTML=loadingCards(6);
  try {
    if(state.tabs.admin==="portal")await loadAdminPortal(root);
    else if(state.tabs.admin==="levels")await loadAccessLevels(root);
    else if(state.tabs.admin==="users")await loadAdminUsers(root);
    else if(state.tabs.admin==="data")await loadAdminUpdates(root);
    else if(state.tabs.admin==="quality")await loadAdminQuality(root);
    else if(state.tabs.admin==="jobs")await loadAdminJobs(root);
    else if(state.tabs.admin==="operations")await loadAdminOperations(root);
    else {
      const [health,db,counts]=await Promise.all([api("/health"),api("/health/db"),api("/debug/db-counts")]);
      root.innerHTML=`<div class="metric-grid">${metricCard("Aplicação",health.status==="ok"?"Operacional":"Atenção",`Versão ${health.version}`)}${metricCard("Banco de dados",db.status==="ok"?"Conectado":"Indisponível",db.database||"")}${metricCard("Hospedagem","Oracle Cloud",health.environment||"Produção")}${metricCard("Domínio","HTTPS ativo","Conexão segura")}</div>${sectionCard("Registros principais",`<div class="detail-list">${Object.entries(counts).map(([key,value])=>`<div><span>${esc(key.replaceAll("_"," "))}</span><strong>${number(value,0)}</strong></div>`).join("")}</div>`,`Consulta somente leitura`)}`;
    }
  } catch(error) { root.innerHTML=errorState(error); }
}

function dividendEventLabel(value){return ({dividend:"Dividendo",jcp:"Juros sobre capital próprio",income:"Rendimento",capital_return:"Restituição de capital",cash_distribution:"Provento em dinheiro"})[value]||value||"Provento";}

async function renderPortfolioDividends(root){
  const query=new URLSearchParams({portfolio_id:state.portfolioId,limit:"1000"});
  const payload=await api(`/investor-events/dividends?${query}`,{requestKey:`dividends-${state.portfolioId}`,cacheTtlMs:60000,bypassCache:true});
  const rows=payload.items||[],known=rows.filter(item=>!nullable(item.estimated_gross_amount));
  const estimated=known.reduce((sum,item)=>sum+Number(item.estimated_gross_amount||0),0);
  const table=rows.length?marketTable(rows,[
    {label:"Ativo",render:r=>`<strong>${esc(r.ticker)}</strong><br><small>${esc(r.portfolio_name||"")}</small>`},
    {label:"Tipo",render:r=>esc(dividendEventLabel(r.event_type))},
    {label:"Data-com",render:r=>dateOnly(r.last_cum_date)},{label:"Data-ex",render:r=>dateOnly(r.ex_date)},{label:"Pagamento",render:r=>dateOnly(r.payment_date)},
    {label:"Valor por unidade",render:r=>nullable(r.amount)?"—":money(r.amount,r.currency||"BRL")},
    {label:"Quantidade atual",render:r=>nullable(r.quantity)?"—":number(r.quantity,4)},
    {label:"Total indicativo",render:r=>nullable(r.estimated_gross_amount)?"—":money(r.estimated_gross_amount,r.currency||"BRL")},
    {label:"Fonte",render:r=>r.source_url?`<a href="${esc(safeExternalUrl(r.source_url))}" target="_blank" rel="noopener noreferrer">${esc(r.source)}</a>`:esc(r.source||"—")},
  ]):'<div class="empty-state"><strong>Nenhum provento confirmado no período</strong>A consulta usa somente eventos oficiais dos ativos desta carteira.</div>';
  const update=payload.update||{};
  root.innerHTML=`<div class="metric-grid summary-grid">${metricCard("Eventos",number(rows.length,0),"No período consultado")}${metricCard("Total indicativo",money(estimated),`${known.length} evento(s) com valor e posição`) }${metricCard("Fonte","B3","Empresas Listadas")}${metricCard("Última atualização",update.last_updated_at?dateTime(update.last_updated_at):"Preparando",update.status||"")}</div>${sectionCard("Calendário oficial de proventos",table,payload.gross_amount_note||"Valores brutos e indicativos; confirme na corretora.")}`;
}

async function saveAccessLevel(form){
  const permissions={};form.querySelectorAll("[data-level-permission]").forEach(input=>permissions[input.dataset.levelPermission]=input.checked);
  const limits={};form.querySelectorAll("[data-level-limit]").forEach(input=>limits[input.dataset.levelLimit]=Number(input.value));
  const payload={name:form.elements.name?.value,description:form.elements.description?.value||null,is_active:Boolean(form.elements.is_active?.checked),permissions,limits};
  const button=form.querySelector('button[type="submit"]');if(button){button.disabled=true;button.textContent="Salvando…";}
  try{const result=await api(`/access/levels/${encodeURIComponent(form.dataset.accessLevelForm)}`,{method:"PUT",body:JSON.stringify(payload)});toast(`Nível atualizado para ${result.member_count||0} usuário(s).`,"success");await loadAdmin();}
  catch(error){toast(error.message,"error");if(button){button.disabled=false;button.textContent="Salvar regras deste nível";}}
}

async function createAccessLevel(form){
  const values=Object.fromEntries(new FormData(form));
  try{await api("/access/levels",{method:"POST",body:JSON.stringify({slug:values.slug,name:values.name,description:values.description||null,is_active:true,permissions:{},limits:{}})});toast("Novo nível criado. Agora configure suas permissões.","success");await loadAdmin();}
  catch(error){toast(error.message,"error");}
}

async function saveUserLevel(email){
  const row=$(`[data-user-row="${CSS.escape(email)}"]`);if(!row)return;
  const level=row.querySelector("[data-user-level]")?.value,status=row.querySelector("[data-user-status]")?.value;
  const button=row.querySelector("[data-save-user-level]");button.disabled=true;
  try{
    if(level&&level!=="legacy"&&level!==row.dataset.currentLevel)await api(`/access/users/${encodeURIComponent(email)}/level`,{method:"PUT",body:JSON.stringify({level_slug:level,clear_overrides:true})});
    if(status&&status!==row.dataset.currentStatus)await api(`/access/users/${encodeURIComponent(email)}`,{method:"PUT",body:JSON.stringify({status})});
    toast("Usuário atualizado.","success");await loadAdmin();
  }catch(error){toast(error.message,"error");button.disabled=false;}
}

async function bulkAssignAccessLevel(){
  const emails=$$("[data-user-select]:checked").map(input=>input.dataset.userSelect),level=$("#bulk-access-level")?.value;
  if(!emails.length){toast("Selecione ao menos um usuário desta página.","error");return;}
  if(!window.confirm(`Atribuir o nível selecionado a ${emails.length} usuário(s)? Ajustes individuais anteriores serão removidos.`))return;
  try{const result=await api("/access/users/level/bulk",{method:"PUT",body:JSON.stringify({emails,level_slug:level,clear_overrides:true})});toast(`${result.updated_count||0} usuário(s) atualizado(s).`,"success");await loadAdmin();}
  catch(error){toast(error.message,"error");}
}

async function clearUserOverrides(email){
  if(!window.confirm("Remover os ajustes individuais e voltar a herdar somente as regras do nível?"))return;
  try{await api(`/access/users/${encodeURIComponent(email)}/overrides`,{method:"DELETE"});toast("Ajustes individuais removidos.","success");await loadAdmin();}
  catch(error){toast(error.message,"error");}
}

async function runAlertMonitorNow(button){
  button.disabled=true;const root=$("#alert-monitor-result");
  try{const result=await api("/alerts/monitor/run",{method:"POST"});if(root){root.classList.remove("hidden");root.textContent=`Verificação concluída: ${result.checked||0} alerta(s), ${result.triggered||0} disparado(s), ${result.delivered||0} e-mail(s) entregue(s) e ${result.quote_failures||0} cotação(ões) indisponível(is).`;}toast("Monitor de alertas executado.","success");}
  catch(error){toast(error.message,"error");}
  finally{button.disabled=false;}
}

async function retryAdminJob(button){
  button.disabled=true;
  try{await api(`/admin/jobs/${encodeURIComponent(button.dataset.retryAdminJob)}/retry`,{method:"POST"});toast("Trabalho reenfileirado.","success");setTimeout(()=>loadAdmin(),1200);}
  catch(error){toast(error.message,"error");button.disabled=false;}
}

function applyAdminUserFilters(form){
  const values=Object.fromEntries(new FormData(form));state.adminUsersQuery=String(values.q||"").trim();state.adminUsersLevel=values.level||"";state.adminUsersStatus=values.status||"";state.adminUsersOffset=0;loadAdmin();
}

function changeAdminUsersPage(direction){state.adminUsersOffset=Math.max(0,state.adminUsersOffset+(direction==="next"?100:-100));loadAdmin();}

async function syncMarketCatalog(assetType, includeTechnicals) {
  const status=$("#market-sync-status");
  const buttons=$$("[data-market-sync]");
  buttons.forEach(button=>button.disabled=true);
  if(status){status.classList.remove("hidden");status.textContent="Atualizando o catálogo…";}
  try {
    const result=await api("/data/sync-market",{method:"POST",body:JSON.stringify({asset_type:assetType,include_technicals:includeTechnicals})});
    state.analysisResultCache.clear();
    toast(`Catálogo atualizado: ${number(result.catalog_count||0,0)} ativo(s).`,"success");
    await loadAdmin();
  } catch(error) {
    if(status){status.textContent=error.message;status.classList.remove("hidden");}
    toast(error.message,"error");
    buttons.forEach(button=>button.disabled=false);
  }
}

async function saveUserAccess(email) {
  const row=$(`[data-user-row="${CSS.escape(email)}"]`);
  if(!row)return;
  const value=name=>row.querySelector(`[data-user-field="${name}"]`);
  const canRun=Boolean(value("can_run_backtests")?.checked);
  const canViewFinances=Boolean(value("can_view_finances")?.checked);
  const canWriteFinances=Boolean(value("can_write_finances")?.checked);
  const payload={
    status:value("status")?.value,
    can_use_fdi_analysis:Boolean(value("can_use_fdi_analysis")?.checked),
    can_use_alb_analysis:Boolean(value("can_use_alb_analysis")?.checked),
    can_use_graham_valuation:Boolean(value("can_use_graham_valuation")?.checked),
    can_use_dividend_ceiling:Boolean(value("can_use_dividend_ceiling")?.checked),
    can_use_relative_valuation:Boolean(value("can_use_relative_valuation")?.checked),
    can_use_economic_valuation:Boolean(value("can_use_economic_valuation")?.checked),
    can_view_finances:canViewFinances||canWriteFinances,
    can_write_finances:canWriteFinances,
    can_run_backtests:canRun,
    can_view_backtests:canRun,
    backtest_asset_limit:canRun?Number(value("backtest_asset_limit")?.value||1):0,
    backtest_daily_limit:canRun?Number(value("backtest_daily_limit")?.value||1):0,
    backtest_strategy_limit:canRun?Number(value("backtest_strategy_limit")?.value||1):0,
    backtest_cooldown_seconds:60,
  };
  try{await api(`/access/users/${encodeURIComponent(email)}`,{method:"PUT",body:JSON.stringify(payload)});toast("Permissões atualizadas.","success");loadAdmin();}
  catch(error){toast(error.message,"error");}
}

function loadCurrentView() {
  if(state.view==="dashboard") { renderDashboardTab(); if(!state.market) loadMarket(); }
  else if(state.view==="analysis") loadAnalysis();
  else if(state.view==="portfolio") loadPortfolios();
  else if(state.view==="finances") loadFinances();
  else if(state.view==="backtests") loadBacktests();
  else if(state.view==="admin") loadAdmin();
}

let searchTimer;
async function runSearch(query) {
  const root=$("#search-results");
  if(query.trim().length<1) { root.classList.add("hidden"); root.innerHTML=""; return; }
  try {
    const data=await api(`/search?q=${encodeURIComponent(query.trim())}`,{requestKey:"search"});
    const items=data.items||[];
    root.innerHTML=items.length?items.map(item=>`<button class="search-result" data-search-item='${esc(JSON.stringify(item))}'><strong>${esc(item.symbol)}</strong><span>${esc(item.label)}</span><small>${esc(item.asset_type)}</small></button>`).join(""):'<div class="empty-state" style="padding:18px"><strong>Nenhum resultado</strong>Revise o código ou nome.</div>';
    root.classList.remove("hidden");
  } catch(error) { if(error.name!=="AbortError") root.innerHTML=`<div class="error-state" style="padding:18px">${esc(error.message)}</div>`; }
}

function chooseSearchResult(item) {
  $("#search-results").classList.add("hidden"); $("#global-search").value="";
  if(item.area==="analysis") { setView("analysis",item.panel); openAsset(item.symbol); }
  else {
    setView("dashboard",item.target_tab||"overview");
    toast(`${item.label} aberto no Painel de Mercado.`,"success");
  }
}

function bindEvents() {
  $("#primary-nav").addEventListener("click", event=>{ const button=event.target.closest("[data-view]"); if(button) setView(button.dataset.view); });
  $("#collapse-sidebar").addEventListener("click",()=>document.body.classList.toggle("sidebar-collapsed"));
  $("#mobile-menu").addEventListener("click",()=>document.body.classList.toggle("mobile-nav-open"));
  $$(".tabs").forEach(tabs=>tabs.addEventListener("click",event=>{const button=event.target.closest(".tab");if(button){activateTab(tabs.dataset.tabs,button.dataset.tab);if(tabs.dataset.tabs==="analysis")updateFilterAvailability();}}));
  $("#refresh-market").addEventListener("click",()=>loadMarket(true));
  $("#logout-button").addEventListener("click",async()=>{try{await api("/logout",{method:"POST"});location.href=LANDING_PATH;}catch(error){toast(error.message,"error");}});
  $("#global-search").addEventListener("input",event=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>runSearch(event.target.value),220);});
  document.addEventListener("keydown",event=>{if(event.key==="/"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName)){event.preventDefault();$("#global-search").focus();}});
  document.addEventListener("click",event=>{
    const refreshGroupsButton=event.target.closest("[data-refresh-groups]");if(refreshGroupsButton){if(refreshGroupsButton.hasAttribute("data-confirm-all-updates")&&!window.confirm(`Enfileirar agora as ${adminRefreshGroups.length} rotinas de atualização? Os dados atuais continuarão disponíveis durante o processamento.`))return;refreshMarketGroups(refreshGroupsButton.dataset.refreshGroups);return;}
    const portfolioNewsButton=event.target.closest("[data-portfolio-news-refresh]");if(portfolioNewsButton){refreshPortfolioNews(portfolioNewsButton.dataset.portfolioNewsRefresh);return;}
    const newsMode=event.target.closest("[data-portfolio-news-mode]");if(newsMode){state.portfolioNewsMode=newsMode.dataset.portfolioNewsMode;renderPortfolioTab();return;}
    const recommendationCategory=event.target.closest("[data-recommendation-category]");if(recommendationCategory){state.recommendationCategory=recommendationCategory.dataset.recommendationCategory;renderPortfolioTab();return;}
    const recommendationRefresh=event.target.closest("[data-recommendation-news-refresh]");if(recommendationRefresh){refreshRecommendationNews(recommendationRefresh.dataset.recommendationNewsRefresh);return;}
    const alertSuggestion=event.target.closest("[data-alert-suggestion]");if(alertSuggestion){const input=$("#alert-symbol");if(input){input.value=alertSuggestion.dataset.alertSuggestion;$("#alert-symbol-suggestions")?.classList.add("hidden");}return;}
    const alertStatus=event.target.closest("[data-alert-status]");if(alertStatus){setAlertStatus(alertStatus);return;}
    const editAlert=event.target.closest("[data-edit-alert]");if(editAlert){editPriceAlert(editAlert.dataset.editAlert);return;}
    const alertTest=event.target.closest("[data-alert-test-email]");if(alertTest){sendAlertTestEmail(alertTest);return;}
    const saveUserLevelButton=event.target.closest("[data-save-user-level]");if(saveUserLevelButton){saveUserLevel(saveUserLevelButton.dataset.saveUserLevel);return;}
    const clearOverrides=event.target.closest("[data-clear-user-overrides]");if(clearOverrides){clearUserOverrides(clearOverrides.dataset.clearUserOverrides);return;}
    if(event.target.closest("[data-bulk-assign-level]")){bulkAssignAccessLevel();return;}
    const usersPage=event.target.closest("[data-admin-users-page]");if(usersPage){changeAdminUsersPage(usersPage.dataset.adminUsersPage);return;}
    const runMonitor=event.target.closest("[data-run-alert-monitor]");if(runMonitor){runAlertMonitorNow(runMonitor);return;}
    const retryJob=event.target.closest("[data-retry-admin-job]");if(retryJob){retryAdminJob(retryJob);return;}
    if(event.target.closest("[data-reload-admin-jobs]")){loadAdmin();return;}
    if(event.target.closest("[data-reload-admin-operations]")){loadAdmin();return;}
    if(event.target.closest("[data-reload-admin-quality]")){loadAdmin();return;}
    const deletePortal=event.target.closest("[data-portal-book-delete]");if(deletePortal){deletePortalBook(deletePortal.dataset.portalBookDelete);return;}
    const movePortal=event.target.closest("[data-portal-book-move]");if(movePortal){movePortalBook(movePortal.dataset.portalBookId,movePortal.dataset.portalBookMove);return;}
    const portfolioPricesButton=event.target.closest("[data-portfolio-prices-refresh]");if(portfolioPricesButton){refreshPortfolioPrices(portfolioPricesButton.dataset.portfolioPricesRefresh);return;}
    const updateCustom=event.target.closest("[data-update-custom-investment]");if(updateCustom){updateCustomInvestmentValue(updateCustom);return;}
    const deleteCustom=event.target.closest("[data-delete-custom-investment]");if(deleteCustom){deleteCustomInvestment(deleteCustom);return;}
    const deletePosition=event.target.closest("[data-delete-position]");if(deletePosition){deletePortfolioPosition(deletePosition);return;}
    if(event.target.closest("[data-close-custom-value]")){$("#custom-value-dialog").close();return;}
    const setFinance=event.target.closest("[data-set-finance-status]");if(setFinance){setFinanceStatus(setFinance);return;}
    const deleteFinance=event.target.closest("[data-delete-finance]");if(deleteFinance){archiveFinanceTransaction(deleteFinance);return;}
    const result=event.target.closest("[data-search-item]"); if(result){try{chooseSearchResult(JSON.parse(result.dataset.searchItem));}catch(_){}}
    const ticker=event.target.closest("tr[data-ticker]")?.dataset.ticker;if(ticker)openAsset(ticker);
    const retry=event.target.closest("[data-retry]")?.dataset.retry;if(retry){if(retry==="market")loadMarket(true);else loadCurrentView();}
    const linked=event.target.closest("[data-view-link]");if(linked)setView(linked.dataset.viewLink,linked.dataset.tabLink||null);
    const curve=event.target.closest("[data-curve-years]");if(curve){state.curveYears=Number(curve.dataset.curveYears);renderDashboardTab();}
    const curveHistory=event.target.closest("[data-curve-history-count]");if(curveHistory){state.curveHistoryCount=Number(curveHistory.dataset.curveHistoryCount);renderDashboardTab();}
    const comparisonPeriod=event.target.closest("[data-comparison-years]");if(comparisonPeriod){state.comparisonYears=Number(comparisonPeriod.dataset.comparisonYears);state.comparisonCustom=false;renderComparison();}
    const comparisonCustom=event.target.closest("[data-comparison-custom]");if(comparisonCustom){state.comparisonCustom=true;ensureComparisonCustomDates();renderComparison();}
    const comparisonBase=event.target.closest("[data-comparison-base]");if(comparisonBase){state.comparisonBaseMode=comparisonBase.dataset.comparisonBase;renderComparison();}
    const comparisonRefresh=event.target.closest("[data-comparison-refresh]");if(comparisonRefresh){loadComparison(true);}
    const saveUser=event.target.closest("[data-save-user]");if(saveUser)saveUserAccess(saveUser.dataset.saveUser);
    const marketSync=event.target.closest("[data-market-sync]");if(marketSync)syncMarketCatalog(marketSync.dataset.marketSync,marketSync.dataset.technicals==="true");
    const preset=event.target.closest("[data-preset-id]");if(preset)selectSystemPreset(preset.dataset.presetId);
    const customPreset=event.target.closest("[data-custom-filter-id]");if(customPreset)selectCustomFilter(customPreset.dataset.customFilterId);
    const studyStrategy=event.target.closest("[data-study-strategy]");if(studyStrategy)openStudyStrategy(studyStrategy.dataset.studyStrategy);
    const officialJob=event.target.closest("[data-official-job]");if(officialJob)openOfficialBacktestJob(officialJob.dataset.officialJob);
    const retryOfficial=event.target.closest("[data-retry-official-job]");if(retryOfficial)retryOfficialBacktestJob(retryOfficial.dataset.retryOfficialJob,retryOfficial);
    if(!event.target.closest(".global-search-wrap"))$("#search-results").classList.add("hidden");
  });
  $("#close-asset-dialog").addEventListener("click",()=>$("#asset-dialog").close());
  $("#asset-dialog").addEventListener("click",event=>{if(event.target===$("#asset-dialog"))$("#asset-dialog").close();});
  $("#apply-advanced-filters").addEventListener("click",applyAdvancedFilters);
  $("#save-custom-filter").addEventListener("click",saveCustomFilter);
  $("#delete-custom-filter").addEventListener("click",deleteCustomFilter);
  document.addEventListener("change",event=>{
    if(event.target.id==="alert-market-scope"){const input=$("#alert-symbol");if(input)input.value="";renderAlertSuggestions("");}
    if(event.target.id==="below-economic"&&event.target.checked&&analysisType()==="stock"){const details=$("#economic-assumptions");if(details){details.open=true;details.scrollIntoView({behavior:"smooth",block:"nearest"});}}
    if(event.target.matches('#finance-transaction-form [name="kind"]')){
      const kind=event.target.value,form=event.target.form;
      form.querySelectorAll("[data-finance-category-kind]").forEach(option=>{const active=option.dataset.financeCategoryKind===kind;option.hidden=!active;option.disabled=!active;});
      form.querySelector('[name="category"]').value=form.querySelector(`[data-finance-category-kind="${kind}"]`)?.value||"";
      form.querySelectorAll("[data-finance-status-kind]").forEach(option=>{const active=option.dataset.financeStatusKind===kind;option.hidden=!active;option.disabled=!active;});
      form.querySelector('[name="status"]').value="planned";
    }
    if(event.target.matches('#backtest-form [name="execution_mode"]')){
      const combined=event.target.value==="combined";
      const field=event.target.form?.querySelector("[data-combination-rule]");if(field)field.hidden=!combined;
    }
    if(event.target.matches('#backtest-form [name="strategy_ids"]'))renderBacktestStrategyParameters(event.target.form);
    if(event.target.matches('#backtest-form [name="period"]')){
      const custom=event.target.value==="custom";
      event.target.form?.querySelectorAll("[data-backtest-custom-date]").forEach(field=>field.hidden=!custom);
    }
    if(event.target.id==="portfolio-selector"){state.portfolioId=event.target.value;renderPortfolioTab();}
    if(event.target.id==="finance-month"){state.financeMonth=event.target.value;loadFinances();}
    if(event.target.id==="analysis-limit"){state.analysisLimit=Number(event.target.value);$("#analysis-limit-label").textContent=state.analysisLimit;}
    if(event.target.matches("[data-comparison-series]")){
      state.comparisonSelected=$$("[data-comparison-series]:checked").map(input=>input.dataset.comparisonSeries);
      renderComparison();
    }
    if(event.target.matches("[data-comparison-date]")){
      if(event.target.dataset.comparisonDate==="from")state.comparisonCustomFrom=event.target.value;
      else state.comparisonCustomTo=event.target.value;
      renderComparison();
    }
    if(event.target.matches("[data-column-id]")){
      const type=analysisType(),columns=analysisColumns(type).filter(column=>!column.always);
      state.visibleColumns[type]=columns.filter(column=>$(`[data-column-id="${column.id}"]`)?.checked).map(column=>column.id);
      localStorage.setItem("fdi-visible-columns",JSON.stringify(state.visibleColumns));renderAnalysisRows(state.analysisRows);
    }
  });
  document.addEventListener("input",event=>{if(event.target.id==="alert-symbol")renderAlertSuggestions(event.target.value);});
  document.addEventListener("submit",event=>{if(event.target.id==="email-login-request-form"){event.preventDefault();requestEmailLogin(event.target);}if(event.target.id==="email-login-verify-form"){event.preventDefault();verifyEmailLogin(event.target);}if(event.target.id==="backtest-form"){event.preventDefault();runBacktest(event.target);}if(event.target.id==="portfolio-position-form"){event.preventDefault();savePortfolioPosition(event.target);}if(event.target.id==="custom-investment-form"){event.preventDefault();saveCustomInvestment(event.target);}if(event.target.id==="custom-value-form"){event.preventDefault();saveCustomInvestmentValue(event.target);}if(event.target.id==="finance-transaction-form"){event.preventDefault();saveFinanceTransaction(event.target);}if(event.target.id==="finance-budget-form"){event.preventDefault();saveFinanceBudget(event.target);}if(event.target.id==="price-alert-form"){event.preventDefault();savePriceAlert(event.target);}if(event.target.id==="alert-preference-form"){event.preventDefault();saveAlertPreferences(event.target);}if(event.target.id==="portal-page-form"){event.preventDefault();savePortalPage(event.target);}if(event.target.matches("[data-portal-book-form]")){event.preventDefault();savePortalBook(event.target);}if(event.target.matches("[data-access-level-form]")){event.preventDefault();saveAccessLevel(event.target);}if(event.target.id==="create-access-level-form"){event.preventDefault();createAccessLevel(event.target);}if(event.target.id==="admin-user-filter-form"){event.preventDefault();applyAdminUserFilters(event.target);}});
}

async function initialize() {
  const login=$("#platform-login");
  if(login) login.href=`${BASE_PATH}/login?next=${encodeURIComponent(PLATFORM_PATH)}`;
  if(BASE_PATH){document.body.classList.add("staging-mode");document.body.insertAdjacentHTML("afterbegin",'<div class="staging-banner">AMBIENTE DE TESTE • nenhuma alteração será publicada na página oficial sem aprovação</div>');}
  renderFilterInputs(); bindEvents();
  try {
    const session=await api("/session/me");
    if(!session.authenticated){showLogin();return;}
    state.session=session; configureAccess(); showApp();
    const requested=new URLSearchParams(location.search);
    const requestedView=requested.get("view"),requestedTab=requested.get("tab");
    if(requestedView==="admin"&&(session.access?.is_owner||session.access?.can_manage_users||session.access?.can_sync_market||session.access?.can_manage_portal)){
      const requestedAdminTab=requestedTab?document.querySelector(`.tabs[data-tabs="admin"] [data-tab="${CSS.escape(requestedTab)}"]`):null;
      const safeAdminTab=requestedAdminTab&&!requestedAdminTab.classList.contains("hidden")?requestedTab:state.tabs.admin;
      setView("admin",safeAdminTab);
    }
    else loadMarket();
    if(session.access?.can_view_news_insights)api("/insights/news/refresh-daily",{method:"POST",invalidateCache:false}).catch(()=>{});
  } catch(error) { showLogin(); toast(error.message,"error"); }
}

document.addEventListener("DOMContentLoaded",initialize);
